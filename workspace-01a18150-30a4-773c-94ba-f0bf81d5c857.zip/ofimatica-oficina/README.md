# Oficina de Ofimática

Aplicación web para formar al personal de la oficina en **Windows 11 y Microsoft Office**,
pensada para gente que empieza desde cero (personas de unos 50 años, sin confianza con
el teclado, los atajos ni las capturas de pantalla).

Incluye:

| Pieza | Qué es |
|---|---|
| **Curso** | 10 módulos · 48 lecciones · de básico a intermedio, con atajos, errores frecuentes y prácticas. |
| **Prácticas interactivas** | 23 ejercicios: pulsar teclas de verdad, clic en la pantalla simulada, ordenar pasos, fórmulas de Excel en una mini-hoja… |
| **Exámenes** | Un examen por módulo (se aprueba con el 70 %), con corrección razonada pregunta a pregunta y nota mejor guardada. |
| **Manual** | 45 artículos consultables con buscador, editables desde el panel de administración. |
| **La Ayudante** | Asistente estilo Clippy con 4 personajes, motor de reglas **y** IA conversacional opcional. |
| **Panel de administración** | Alta de cuentas y contraseñas, progreso del aula, configuración de la IA, contenidos. |
| **Acceso directo** | Icono en el Escritorio y entrada en el menú Inicio de Windows 11 (+ instalable como app con Edge). |
| **Correo a dos bandas** | El módulo de correo tiene dos itinerarios: **Outlook** y **Thunderbird**. Cada alumna elige el suyo (o los dos) y el curso se adapta. |
| **Alta sin papeleo** | Se da de alta a una alumna con **solo su nombre**: el usuario se genera solo y el correo es opcional. |
| **Guardado automático** | Nada se pierde: las lecciones, los exámenes y los ejercicios se guardan solos mientras trabajas. |
| **Nube** | `Dockerfile`, `render.yaml` y `Procfile` para publicarlo en un servidor permanente y que funcione aunque el PC de la oficina esté apagado. |

---

## Arranque rápido (para probarlo ahora mismo)

```bash
cd ofimatica-oficina
pip install -r requirements.txt
python iniciar_servidor.py
```

- En este equipo: <http://localhost:8080>
- Desde la red de la oficina: `http://<IP-del-equipo>:8080`
- Administrador inicial: usuario **`admin`**, contraseña **`admin`** (cámbiala al entrar).

Para la instalación real en Windows 11, mira **[`instalador/LEEME.md`](instalador/LEEME.md)**.

---

## Cómo se organiza el curso

| # | Módulo | Contenido |
|---|---|---|
| 1 | 🖥️ Primeros pasos con Windows 11 | Escritorio, ratón, ventanas, menú Inicio, barra de tareas |
| 2 | ⌨️ Teclado y atajos esenciales | Las teclas que hay que conocer y los 15 atajos de Windows 11 |
| 3 | 📁 Archivos y carpetas | Explorador, copiar/mover/renombrar, buscar, guardar, OneDrive |
| 4 | 📸 Capturas de pantalla | Windows + Shift + S, Recortes, grabar vídeo, buenas prácticas |
| 5 | 📄 Microsoft Word | Pantalla, formato, párrafos, tablas, imágenes, PDF, plantillas |
| 6 | 📊 Microsoft Excel | Celdas, fórmulas, formato, filtros, gráficos, tablas dinámicas |
| 7 | ✉️ Correo (Outlook **o** Thunderbird) | 10 lecciones: 2 comunes + 4 de Outlook + 4 de Thunderbird. Cada alumna ve las suyas |
| 8 | 👥 Teams y reuniones | Chats, canales, compartir pantalla, grabarlo |
| 9 | 🖨️ Impresoras y PDF | Imprimir, dúplex, escanear, unir y firmar PDF |
| 10 | 🔐 Seguridad e IA | Contraseñas, phishing, copias de seguridad, Copilot |

Cada lección termina con **Marcar como completada** (+20 puntos) y enlaza con su práctica.
Al terminar un módulo, aparece el examen.

### El módulo de correo: cada una con su programa

El módulo 7 tiene **dos itinerarios** y las lecciones se filtran solas según lo que elija
cada alumna (en *Ajustes → Mi programa de correo* o en la propia página del módulo):

| Elección | Lecciones que ve |
|---|---|
| **Los dos** | 2 comunes + 4 de Outlook + 4 de Thunderbird (10) |
| **Solo Outlook** | 2 comunes + 4 de Outlook (6) |
| **Solo Thunderbird** | 2 comunes + 4 de Thunderbird (6) |

- Las **lecciones comunes** (qué es el correo, configurar una cuenta) se ven siempre.
- La **ayudante** también responde según el programa de la alumna: si pregunta «¿cómo
  reenvío?», le dará `Ctrl + F` si usa Outlook y `Ctrl + L` si usa Thunderbird.
- El manual tiene artículos de los dos programas, con sus diferencias (atajos, IMAP/SMTP,
  OAuth2 con Microsoft 365, reglas/filtros, adjuntos y firma).

### Guardado automático (no se pierde nada)

| Qué | Cómo se guarda |
|---|---|
| **Lección** | Cada 15 segundos se guarda por dónde vas; al llegar al final se marca como completada sola. |
| **Examen** | Las respuestas marcadas se guardan al instante; si se cierra la página, se recuperan. |
| **Ejercicio** | Lo que escribes o seleccionas se guarda y se restaura. |
| **Al salir** | Se guarda el último punto exacto (con `sendBeacon`, funciona incluso cerrando el navegador). |

Todo se guarda en la base de datos de la aplicación (`tabla drafts`), no en el navegador:
se puede recuperar desde **otro ordenador**. En la pantalla de inicio aparece la tarjeta
*«Tenías esto a medias»* para retomar la lección.

---

## La Ayudante (el «Clippy» de la oficina)

- Botón fijo en la esquina inferior derecha de todas las páginas, con **4 personajes** que la alumna elige:
  - 📌 **Chispita** — la más cercana, explica con ejemplos cotidianos.
  - ⌨️ **Don Atajo** — especialista en atajos de teclado.
  - ☁️ **Nubia** — archivos, carpetas y copias de seguridad.
  - 📊 **Sumia** — fórmulas de Excel y tablas.
- **Burbujas de consejos** como los «tips» del asistente de Office 2003/2007: aparecen solos con
  recordatorios útiles («pulsa Ctrl + S cada pocos minutos»).
- **Chat con IA** (opcional): si activas Ollama/LM Studio/OpenAI en *Administración → Configurar la IA*,
  las respuestas son conversacionales y tienen en cuenta la lección que la alumna está viendo.
  Sin IA, la ayudante funciona con un motor de 20 intenciones + búsqueda en el manual (siempre disponible).
- Las respuestas incluyen **atajos** y **enlaces al manual** con el artículo exacto.

---

## Arquitectura

```
ofimatica-oficina/
├── iniciar_servidor.py          # arranque (puerto, IP de red, aviso)
├── wsgi.py                      # arranque en producción (gunicorn / waitress)
├── Dockerfile                    # imagen de contenedor (nube)
├── render.yaml                   # despliegue automático en Render
├── Procfile                     # despliegue en Heroku / Railway / Fly.io
├── requirements.txt             # Flask + gunicorn (waitress en Windows)
├── app/
│   ├── config.py                # rutas, puerto, ajustes de la IA
│   ├── db.py                    # esquema SQLite (11 tablas)
│   ├── auth.py                  # login, roles, hashing, puntos e insignias
│   ├── views.py                 # rutas del alumno
│   ├── admin_views.py           # panel de administración
│   ├── api.py                   # /api/chat, /api/ejercicio/..., /api/progreso
│   ├── assistant.py             # personajes, intenciones, búsqueda, redacción
│   ├── ia.py                    # puente con Ollama/LM Studio/OpenAI
│   ├── formulas.py              # mini evaluador de fórmulas de Excel
│   ├── seed.py                  # carga de contenido (+ barajado de respuestas)
│   ├── content/                 # p1_basico · p2_ofimatica · p3_comunicacion
│   │                            # p4_correo (Outlook + Thunderbird)
│   │                            # manual.py · ejercicios.py · curso.py
│   ├── templates/               # 17 plantillas (alumno + administración)
│   └── static/                  # CSS sin dependencias, JS, manifest PWA, service worker
├── instalador/                  # scripts PowerShell/.bat para Windows 11
└── data/                        # base de datos SQLite (se crea sola)
```

**Sin dependencias externas en el navegador**: ni CDNs ni fuentes remotas.
Funciona en la red interna de la oficina, aunque no haya internet.

### Base de datos

SQLite en `data/ofimatica.db` (o en la ruta que marque `OFIMATICA_DB`), con tablas:
`users`, `modules`, `lessons`, `progress`, `exercises`, `exercise_progress`, `exams`,
`exam_attempts`, `user_stats`, `articles`, `activity`, `drafts`, `settings`.
Copia ese fichero para hacer una copia de seguridad de todo.

Las migraciones son automáticas: al arrancar se añade lo que falte (por ejemplo la
columna `email_client` de las usuarias o la tabla `drafts` del guardado automático)
sin perder ningún dato.

### IA: cualquier servidor compatible con la API de OpenAI

| Software | Dirección | Modelo |
|---|---|---|
| Ollama (local, gratis) | `http://localhost:11434/v1` | `llama3.1:8b`, `qwen2.5:7b`… |
| LM Studio (local, con interfaz) | `http://localhost:1234/v1` | el que descargues |
| llama.cpp server | `http://localhost:8080/v1` | el que compiles |
| OpenAI / Groq / vLLM | su URL `/v1` | el que uses |

La IA **nunca es obligatoria**: si está apagada o falla, la ayudante contesta con el manual.

---

## Detalles de diseño (pensados para el público)

- Letra base de 18 px y opción de **agrandar el texto** (Normal / Grande / Muy grande) desde Ajustes.
- Botones grandes, alto contraste, pasos numerados con círculos, avisos en recuadros de color.
- Se puede repetir cualquier práctica o examen tantas veces como haga falta: se guarda la mejor nota.
- Cada práctica da puntos, racha e insignias; el progreso se ve en el panel y en el del aula.
- Nada de mensajes técnico sin traducir: el vocabulario es el de la ofimática real.
- Avisos de seguridad específicos: no pegar datos de clientes en IA no autorizada, no compartir
  contraseñas, no borrar con Mayús+Supr, etc.

---

## Publicar en la nube (sin depender de ningún PC)

Si quieres que el curso esté disponible aunque el PC de la oficina esté apagado,
publica la carpeta en un servidor permanente:

```bash
docker build -t ofimatica .
docker run -d -p 8080:8080 -v ofimatica_datos:/data -e OFIMATICA_DB=/data/ofimatica.db ofimatica
```

O usa el botón de **Blueprint** de Render: el fichero `render.yaml` ya está preparado
(disco persistente, variables de entorno y comprobación de vida). La guía paso a paso,
pensada para quien no es informático, está en
**[`instalador/DEPLOY_EN_LA_NUBE.md`](instalador/DEPLOY_EN_LA_NUBE.md)**.

---

## Copias de seguridad

```bash
# Copia con fecha y hora, y listado de copias
python instalador/copia_de_seguridad.py
python instalador/copia_de_seguridad.py --listar

# Restaurar una copia
python instalador/copia_de_seguridad.py --restaurar copias/ofimatica_2026-10-28_1200.db
```

En Windows, el script `instalador/instalar_servidor.ps1` deja el puerto abierto en el cortafuegos
y crea la tarea de inicio automático; la copia se puede automatizar con `robocopy` (ver
[`instalador/LEEME.md`](instalador/LEEME.md)).

---

## Licencia y uso

Material interno de formación, listo para adaptar: el contenido está en
`app/content/*.py` (texto HTML sencillo) y los artículos del manual se editan también
desde *Administración → Contenidos*.

---

## Cuentas de prueba que dejan la instalación

| Usuario | Contraseña | Rol |
|---|---|---|
| `admin` | `admin` | Administrador (cámbiala al entrar) |
| `mgarcia` | `Ofi2026` | Alumna de ejemplo, para ver la vista del curso |

> Ambas son de prueba: **borra `mgarcia` y cambia la contraseña de `admin`** antes de
> encender el aula de verdad.
