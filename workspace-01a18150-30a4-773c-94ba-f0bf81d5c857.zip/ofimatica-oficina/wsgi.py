"""Punto de entrada para servidores de producción (gunicorn, uvicorn, Render, Railway...).

    gunicorn --workers 1 --threads 4 --bind 0.0.0.0:8080 wsgi:app

Prepara la base de datos (la crea si no existe) y carga el contenido del curso
antes de arrancar, para que la aplicación esté lista nada más desplegarse.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app                      # noqa: E402
from app.auth import crear_admin_inicial        # noqa: E402
from app.seed import seed_todo                  # noqa: E402

app = create_app()

with app.app_context():
    seed_todo()
    crear_admin_inicial()

if __name__ == "__main__":
    app.run(host=os.environ.get("OFIMATICA_HOST", "0.0.0.0"),
            port=int(os.environ.get("OFIMATICA_PORT", "8080")),
            threaded=True)
