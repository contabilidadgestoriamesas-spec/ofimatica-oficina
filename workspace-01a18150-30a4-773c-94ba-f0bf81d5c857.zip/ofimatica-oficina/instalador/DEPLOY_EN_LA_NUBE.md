# Poner el curso en la nube (para que esté disponible 24 horas)

Hasta ahora el curso se guardaba en el PC de la oficina y, si ese PC se apagaba,
el curso no estaba disponible. Con esta guía lo publicamos en un servidor
permanente (una "nube") y todas las máquinas de la oficina entrarán por
Internet, igual que entras en Gmail o en el banco.

**Ventajas:** funciona aunque el PC de la oficina esté apagado o estropeado;
cada alumna puede entrar desde su propio puesto; el progreso se guarda solo.

---

## 1. Qué vamos a hacer (resumen en 5 pasos)

| Paso | Qué haces | Dónde |
|------|-----------|-------|
| 1 | Subir la carpeta del curso a GitHub | github.com |
| 2 | Crear el servicio en Render | render.com |
| 3 | Copiar los datos actuales (cuentas y notas) | una sola vez, opcional |
| 4 | Cambiar la contraseña de administradora | dentro de la app |
| 5 | Poner la dirección nueva en los accesos directos | en cada PC |

Tiempo aproximado: **30 minutos la primera vez** (la segunda vez, 10 minutos).

---

## 2. Antes de empezar: qué necesitas

- Una cuenta de **GitHub** (gratuita): https://github.com
- Una cuenta de **Render** (gratuita): https://render.com
- La carpeta del curso completa (la que tiene `app/`, `data/`, `iniciar_servidor.py`...).

> **Aviso importante sobre el plan gratuito de Render:** el servicio se apaga solo
> tras 15 minutos sin actividad y tarda unos minutos en volver a encenderse.
> Está perfecto para probar. Si queréis que esté **siempre** disponible,
> contratad el plan de pago (7 USD/mes) o instaladlo en un servidor propio
> (mira la sección 7).

---

## 3. Paso 1 - Subir el curso a GitHub

1. Entra en https://github.com y pulsa **+** (esquina superior derecha) -> **New repository**.
2. Ponle un nombre, por ejemplo `ofimatica-oficina`, y pulsa **Create repository**.
3. En la página del repositorio, pulsa **uploading an existing file**.
4. Arrastra **todo el contenido** de la carpeta del curso y pulsa **Commit changes**.

> Si tu ordenador no te deja arrastrar la carpeta, comprime el contenido en un
> ZIP y súbelo con "Upload files" (GitHub lo descomprime solo).

---

## 4. Paso 2 - Crear el servicio en Render

1. Entra en https://render.com y crea una cuenta (o entra con GitHub).
2. Pulsa **New +** -> **Blueprint**.
3. Elige el repositorio `ofimatica-oficina`.
4. Render leerá el fichero `render.yaml` y lo configuré todo por ti:
   - crea el servidor web,
   - crea un disco de 1 GB para guardar los datos,
   - pone la variable `OFIMATICA_DB=/data/ofimatica.db`,
   - genera una clave secreta automática.
5. Pulsa **Apply** / **Create Blueprint**.
6. Espera a que el estado pase a **Live** (2-5 minutos).
7. Render te mostrará una dirección tipo:

   ```
   https://ofimatica-oficina.onrender.com
   ```

   **Copia esa dirección**: es la nueva dirección del curso.

### Comprobar que funciona

Abre esa dirección en el navegador. Debe aparecer la pantalla de entrada con el
logo de la Oficina de Ofimática. Entra con `admin` / `admin` y cambia la
contraseña inmediatamente (Administración -> tu cuenta -> Contraseña).

---

## 5. Paso 3 - Llevar las cuentas actuales (opcional)

Si ya tenías cuentas de alumnas con notas y progreso, puedes copiarlas:

1. En el PC de la oficina, copia el fichero `data/ofimatica.db`.
2. En Render, abre la pestaña **Shell** (la terminal del servicio).
3. Convierte el fichero a texto Base64 en tu PC (PowerShell):

   ```powershell
   [Convert]::ToBase64String([IO.File]::ReadAllBytes('data\ofimatica.db')) | Set-Content copia.txt
   ```

4. Copia el contenido de `copia.txt` en la Shell de Render y ejecuta:

   ```bash
   echo "AQUI_VA_EL_CODIGO_BASE64" | base64 -d > /data/ofimatica.db
   ```

5. Reinicia el servicio desde el panel de Render.

> Si prefieres empezar limpio (lo más sencillo para la primera puesta en marcha),
> **no hagas nada**: el servicio crea la base de datos él solo y ya puedes dar de
> alta las cuentas desde el panel de administración.

---

## 6. Paso 4 - Cambiar los accesos directos de los PCs

En cada PC de la oficina:

1. Ejecuta `instalador/crear_acceso_directo.ps1` y escribe la **direccion nueva**
   (`https://ofimatica-oficina.onrender.com`) en lugar de la del servidor local.
   El acceso directo se seguira creando en el **Escritorio** y en el **Menu Inicio**
   de Windows 11, y se abrira en una ventana propia (como una aplicacion).
2. Ya esta. Cuando abras el acceso directo, entraras a la nube.

> **Ventaja extra:** como la web se guarda en la nube, si un PC se estropea
> solo hay que crear el acceso directo en el PC nuevo. No hay que instalar nada.

---

## 7. Alternativas al plan gratuito

| Opcion | Cuando | Coste |
|--------|---------|-------|
| Render (gratis) | Para probar | 0 euros (se apaga tras 15 min sin uso) |
| Render (plan de pago) | Siempre disponible | ~7 euros/mes |
| Railway / Fly.io | Igual que Render | ~5-10 euros/mes |
| Servidor propio (VPS) | Maximo control | 5-15 euros/mes + configuracion |
| Tu propia nube corporativa (Azure, AWS...) | Si ya teneis | segun contrato |

### Instalar en un servidor propio (Linux)

En un servidor con Python 3.11 o superior:

```bash
pip install -r requirements.txt
export OFIMATICA_DB=/var/lib/ofimatica/ofimatica.db   # datos persistentes
export OFIMATICA_SECRET=una-clave-larga-y-aleatoria   # importante
gunicorn --workers 1 --threads 4 --bind 0.0.0.0:8080 wsgi:app
```

En Windows, si no quieres usar gunicorn:

```bat
set OFIMATICA_DB=C:\ofimatica\data\ofimatica.db
set OFIMATICA_SECRET=una-clave-larga-y-aleatoria
waitress-serve --host=0.0.0.0 --port=8080 wsgi:app
```

Despues, delante del servidor, pon un **servidor web** (Apache o Nginx) para
que la direccion sea `https://ofimatica.miempresa.com` con **certificado
HTTPS** (Let's Encrypt es gratuito). Sin HTTPS, los navegadores y el instalador
de Windows 11 no se fiaran de la web.

---

## 8. Copias de seguridad

Toda la informacion (cuentas, progreso, notas, borradores) vive en **un solo
fichero**: la base de datos `ofimatica.db`.

**Copia local (desde el PC):**

```bash
python instalador/copia_de_seguridad.py          # crea copias/ofimatica_AAAA-MM-DD_HHMMSS.db
python instalador/copia_de_seguridad.py --listar  # ver las copias
```

**Copia en la nube (Render):** el disco `/data` ya se guarda solo cada dia
(Render hace un snapshot). Aun asi, descarga una copia de vez en cuando desde
**Shell** o desde el panel.

**Restaurar una copia:**

```bash
python instalador/copia_de_seguridad.py --restaurar copias/ofimatica_2026-10-28_1200.db
```

> Guarda una copia en un sitio distinto (una carpeta de la red, un pendrive, un
> Drive compartido). Si el disco del servidor se estropea, la copia es tu
> seguro.

---

## 9. Variables de entorno (para los que saben)

| Variable | Para que | Valor por defecto |
|----------|----------|-------------------|
| `OFIMATICA_DB` | Ruta de la base de datos | `data/ofimatica.db` |
| `OFIMATICA_SECRET` | Clave de las sesiones (obligatoria en la nube) | se genera sola |
| `OFIMATICA_HOST` | Direccion de escucha | `0.0.0.0` |
| `OFIMATICA_PORT` | Puerto | `8080` |
| `OFIMATICA_ADMIN` | Usuario administradora inicial | `admin` |
| `OFIMATICA_ADMIN_PASSWORD` | Contrasena inicial | `admin` |
| `OFIMATICA_DATA` | Carpeta de datos | `data` |

> **Si cambias `OFIMATICA_SECRET`, todas las usuarias que tuvieran la sesion
> abierta tendran que entrar de nuevo.** En la nube esta variable es obligatoria
> (si no, al reiniciar el servidor todas las sesiones se perderian).

---

## 10. Lista de comprobacion final

- [ ] La direccion de la nube abre la pantalla de entrada.
- [ ] He cambiado la contrasena de `admin`.
- [ ] He dado de alta a las alumnas con **solo su nombre**.
- [ ] Les he indicado que programa de correo usan (Outlook, Thunderbird o los dos).
- [ ] He creado el acceso directo en el Menu Inicio de los Windows 11.
- [ ] He probado el autoguardado: abrir una leccion, escribir, recargar y comprobar
      que sigue ahi.
- [ ] Tengo una copia de seguridad de `ofimatica.db` guardada fuera del servidor.
