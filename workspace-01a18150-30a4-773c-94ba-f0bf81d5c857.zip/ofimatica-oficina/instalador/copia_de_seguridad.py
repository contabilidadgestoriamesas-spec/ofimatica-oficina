#!/usr/bin/env python3
"""Copia de seguridad de la Oficina de Ofimática.

Guarda una copia del fichero de base de datos (con las cuentas, el progreso,
las notas y los borradores) en la carpeta `copias/` con la fecha y la hora.

Uso:
    python instalador/copia_de_seguridad.py            # copia normal
    python instalador/copia_de_seguridad.py --listar   # ver las copias
    python instalador/copia_de_seguridad.py --restaurar copias/ofimatica_2026-10-28_1200.db
"""
import argparse
import datetime
import glob
import os
import shutil
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.environ.get("OFIMATICA_DB", os.path.join(BASE, "data", "ofimatica.db"))
CARPETA = os.path.join(BASE, "copias")


def listar():
    archivos = sorted(glob.glob(os.path.join(CARPETA, "ofimatica_*.db")))
    if not archivos:
        print("Todavía no hay copias de seguridad en:", CARPETA)
        return
    print("Copias guardadas (%d):" % len(archivos))
    for a in archivos:
        tam = os.path.getsize(a) / 1024.0
        fecha = datetime.datetime.fromtimestamp(os.path.getmtime(a)).strftime("%d/%m/%Y %H:%M")
        print("  %-45s %8.1f KB  %s" % (os.path.basename(a), tam, fecha))


def copia():
    if not os.path.exists(DB_PATH):
        print("No encuentro la base de datos en:", DB_PATH)
        return 1
    os.makedirs(CARPETA, exist_ok=True)
    sello = datetime.datetime.now().strftime("%Y-%m-%d_%H%M%S")
    destino = os.path.join(CARPETA, "ofimatica_%s.db" % sello)
    shutil.copy2(DB_PATH, destino)
    print("Copia de seguridad creada:")
    print("  ", destino)
    print("Tamaño: %.1f KB" % (os.path.getsize(destino) / 1024.0))
    return 0


def restaurar(origen):
    if not os.path.exists(origen):
        print("No encuentro el fichero:", origen)
        return 1
    respalda = DB_PATH + ".antes_de_restaurar"
    if os.path.exists(DB_PATH):
        shutil.copy2(DB_PATH, respalda)
        print("Copia del estado actual guardada en:", respalda)
    shutil.copy2(origen, DB_PATH)
    print("Copia restaurada. Reinicia el servidor para que se aplique.")
    return 0


def main():
    p = argparse.ArgumentParser(description="Copias de seguridad de la Oficina de Ofimática")
    p.add_argument("--listar", action="store_true", help="ver las copias existentes")
    p.add_argument("--restaurar", metavar="FICHERO", help="restaurar una copia concreta")
    args = p.parse_args()
    if args.restaurar:
        return restaurar(args.restaurar)
    if args.listar:
        listar()
        return 0
    return copia()


if __name__ == "__main__":
    sys.exit(main() or 0)
