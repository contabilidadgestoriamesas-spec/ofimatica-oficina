# ============================================================================
#  INSTALADOR DEL SERVIDOR (en el equipo de la oficina que hará de servidor)
#
#  Hace todo lo necesario para que el curso funcione:
#    1. Comprueba / instala Python
#    2. Instala las dependencias (Flask)
#    3. Crea la carpeta de datos y la cuenta de administrador
#    4. Abre el cortafuegos para el puerto 8080
#    5. Crea una tarea programada que arranca el servidor al iniciar sesión
#    6. Crea el acceso directo en el Escritorio y en el menú Inicio
#
#  Uso:  clic derecho -> "Ejecutar con PowerShell"  (o: powershell -ExecutionPolicy Bypass -File instalar_servidor.ps1)
# ============================================================================
$ErrorActionPreference = "Continue"
$raiz = Split-Path -Parent $PSScriptRoot
$carpeta = Join-Path $raiz "ofimatica-oficina"

Write-Host ""
Write-Host "  ============================================================" -ForegroundColor DarkCyan
Write-Host "   INSTALACIÓN DEL SERVIDOR - Oficina de Ofimática" -ForegroundColor Cyan
Write-Host "  ============================================================" -ForegroundColor DarkCyan
Write-Host ""

# --- 1) Python --------------------------------------------------------------
$python = (Get-Command python -ErrorAction SilentlyContinue).Source
if (-not $python) {
    $python = (Get-Command py -ErrorAction SilentlyContinue).Source
}
if (-not $python) {
    Write-Host "  [1/6] Python no está instalado." -ForegroundColor Yellow
    Write-Host "        Se abrirá la página de descarga de Python 3." -ForegroundColor Yellow
    Start-Process "https://www.python.org/downloads/"
    Write-Host "        Descárgalo, márcala 'Add Python to PATH' y vuelve a ejecutar este script." -ForegroundColor Yellow
    Read-Host "Pulsa Intro para salir"
    exit 1
}
Write-Host "  [1/6] Python encontrado: $python" -ForegroundColor Green

# --- 2) Dependencias --------------------------------------------------------
Write-Host "  [2/6] Instalando dependencias (Flask)..." -ForegroundColor Gray
& $python -m pip install --quiet --disable-pip-version-check -r (Join-Path $carpeta "requirements.txt")
if ($LASTEXITCODE -ne 0) {
    Write-Host "        No se pudo instalar Flask. Revisa la conexión a internet." -ForegroundColor Red
}

# --- 3) Datos y administrador ------------------------------------------------
Write-Host "  [3/6] Preparando la base de datos y la cuenta de administrador..." -ForegroundColor Gray
Push-Location $carpeta
& $python -c "import sys; sys.path.insert(0,'.'); from app.seed import seed_todo; from app.auth import crear_admin_inicial; from app import create_app; app=create_app(); ctx=app.app_context(); ctx.push(); seed_todo(); crear_admin_inicial(); print('  Base de datos lista.')"
Pop-Location

# --- 4) Cortafuegos ----------------------------------------------------------
Write-Host "  [4/6] Abriendo el cortafuegos para el puerto 8080..." -ForegroundColor Gray
try {
    $regla = Get-NetFirewallRule -DisplayName "Oficina de Ofimática" -ErrorAction SilentlyContinue
    if (-not $regla) {
        New-NetFirewallRule -DisplayName "Oficina de Ofimática" -Direction Inbound -Action Allow `
            -Protocol TCP -LocalPort 8080 -Profile Private -ErrorAction SilentlyContinue | Out-Null
        Write-Host "        Regla de cortafuegos creada." -ForegroundColor Green
    } else {
        Write-Host "        La regla ya existía." -ForegroundColor DarkGray
    }
} catch {
    Write-Host "        No se pudo crear la regla (puede hacer falta ejecutar como administrador)." -ForegroundColor Yellow
}

# --- 5) Inicio automático ----------------------------------------------------
Write-Host "  [5/6] Creando la tarea de inicio automático..." -ForegroundColor Gray
$bat = Join-Path $PSScriptRoot "iniciar_ofimatica.bat"
try {
    $accion = New-ScheduledTaskAction -Execute $bat
    $disparo = New-ScheduledTaskTrigger -AtLogOn
    $principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Limited
    Register-ScheduledTask -TaskName "Oficina de Ofimática (servidor)" -Action $accion -Trigger $disparo `
        -Principal $principal -Force -ErrorAction SilentlyContinue | Out-Null
    Write-Host "        El servidor arrancará solo al iniciar sesión." -ForegroundColor Green
} catch {
    Write-Host "        No se pudo crear la tarea programada (ejecuta como administrador si lo necesitas)." -ForegroundColor Yellow
}

# --- 6) Acceso directo -------------------------------------------------------
Write-Host "  [6/6] Creando el acceso directo..." -ForegroundColor Gray
$ip = (Get-NetIPAddress -AddressFamily IPv4 |
       Where-Object { $_.IPAddress -notlike "127.*" -and $_.PrefixOrigin -ne "WellKnown" } |
       Select-Object -First 1).IPAddress
& (Join-Path $PSScriptRoot "crear_acceso_directo.ps1") -Url "http://$ip`:8080"

Write-Host ""
Write-Host "  ============================================================" -ForegroundColor DarkCyan
Write-Host "   INSTALACIÓN COMPLETADA" -ForegroundColor Cyan
Write-Host "  ============================================================" -ForegroundColor DarkCyan
Write-Host "   Usuario administrador: admin" -ForegroundColor White
Write-Host "   Contraseña inicial    : admin   (cámbiala al entrar)" -ForegroundColor White
Write-Host "   Dirección para el aula: http://$ip`:8080" -ForegroundColor Green
Write-Host "  ============================================================" -ForegroundColor DarkCyan
Write-Host ""
Read-Host "Pulsa Intro para salir"
