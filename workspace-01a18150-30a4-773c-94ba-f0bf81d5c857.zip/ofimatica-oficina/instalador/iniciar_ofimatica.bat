@echo off
REM ===========================================================================
REM  Arranca el servidor del curso de ofimática (se usa también en la tarea
REM  programada de inicio automático de Windows).
REM ===========================================================================
setlocal
cd /d "%~dp0.."
title Oficina de Ofimatica - Servidor

echo.
echo   Iniciando el servidor del curso de ofimatica...
echo   Para detenerlo: cierra esta ventana o pulsa Ctrl + C
echo.

where python >nul 2>nul
if %errorlevel%==0 (
    python iniciar_servidor.py --host 0.0.0.0 --puerto 8080
) else (
    py -3 iniciar_servidor.py --host 0.0.0.0 --puerto 8080
)

echo.
echo   El servidor se ha detenido.
pause
