# Instalación en la oficina · Guía paso a paso

Este directorio contiene todo lo necesario para montar el curso en los equipos de la oficina.

---

## 1. En el EQUIPO SERVIDOR (el tuyo o el de un compañero de confianza)

1. Instala **Python 3.12 o superior** desde [python.org/downloads](https://www.python.org/downloads/).
   - **Importante:** marca la casilla **"Add Python to PATH"** durante la instalación.
2. Copia aquí la carpeta `ofimatica-oficina` (por ejemplo en `C:\ofimatica-oficina`).
3. Clic derecho en **`instalar_servidor.ps1`** → **Ejecutar con PowerShell**.
   - Si Windows lo bloquea: botón derecho → *Propiedades* → marca **"Desbloquear"** → *Ejecutar con PowerShell*.
   - Si sigue avisando, ejecuta en PowerShell:
     ```powershell
     powershell -ExecutionPolicy Bypass -File .\instalar_servidor.ps1
     ```
4. El script hace todo: instala Flask, crea la base de datos, abre el cortafuegos,
   crea la tarea de inicio automático y el acceso directo.
5. Anota la dirección que aparece al final (algo como `http://192.168.1.50:8080`).

> **Alternativa manual:** doble clic en `iniciar_ofimatica.bat`. Requiere tener Flask instalado
> (`pip install -r requirements.txt`).

### Cambiar el puerto

Si el 8080 está ocupado: `python iniciar_servidor.py --puerto 9000`.
Recuerda cambiar también la regla del cortafuegos y la dirección de los accesos directos.

### Si la red de la oficina tiene "zonas" o "redes de invitados"

Cambia el perfil de red del equipo servidor a **"Privada"**:
*Configuración → Red e Internet → Propiedades de red → Privada*.
Si no, Windows bloqueará el acceso de los demás equipos.

### ¿Y si el PC servidor se apaga?

Si quieres que el curso esté disponible **aunque el equipo servidor esté apagado**
(por ejemplo, en horario de tarde o si se estropea), publícalo en la nube.
Mira la guía **[`DEPLOY_EN_LA_NUBE.md`](DEPLOY_EN_LA_NUBE.md)**: son 5 pasos y
se hace una sola vez. A partir de ahí, los accesos directos de los equipos del
aula apuntan a la dirección de Internet y todo funciona igual (el progreso se
guarda en el servidor, no en los PCs).

---

## 2. En cada EQUIPO DEL AULA

1. Copia la carpeta `ofimatica-oficina` (o solo la carpeta `instalador`) al equipo.
2. Ejecuta **`instalar_en_este_equipo.bat`** e indica la dirección del curso.
   (o: `crear_acceso_directo.ps1 -Url "http://192.168.1.50:8080"`)
3. Se creará:
   - un icono **en el Escritorio**,
   - una entrada en el **menú Inicio** (búscala escribiendo «Ofimática»).
4. Opcional: abre *Configuración → Aplicaciones → Inicio* y **ancla** la aplicación
   a la primera pantalla de Windows 11.

### Instalarla como aplicación de verdad (recomendado)

Con **Microsoft Edge**:

1. Abre Edge y ve a la dirección del curso.
2. Clic en **⋯ (tres puntos)** → *Más herramientas* → *Aplicaciones* → **Instalar este sitio como una aplicación**.
3. En el diálogo, marca **Anclar a la barra de tareas** y **Anclar al inicio**.
4. *Instalar*.

A partir de ahí se abre en su propia ventana, sin barra de navegador, y aparece en Inicio
y en la barra de tareas como cualquier otro programa. Si prefieres que Edge lo abra
automáticamente en modo aplicación, el acceso directo que crea el script ya lo hace
(`msedge --app=http://...`).

---

## 3. Poner en marcha la IA (opcional pero muy recomendable)

La ayudante **ya funciona sin IA** (usa el manual y un motor de reglas). Si quieres
respuestas más conversacionales:

1. En el equipo servidor, instala [Ollama](https://ollama.com) (gratuito).
2. En PowerShell:
   ```powershell
   ollama pull llama3.1:8b
   ```
   (o `qwen2.5:7b`, que habla español muy bien)
3. En la aplicación: *Administración → Configurar la IA*:
   - Dirección: `http://localhost:11434/v1`
   - Modelo: `llama3.1:8b`
   - Marca **Activar la IA** y pulsa **Probar la conexión**.

> Si quieres que la IA la usen todos los equipos del aula, instala Ollama en el servidor
> y pon en la dirección `http://192.168.1.50:11434/v1`, arrancando Ollama con
> `OLLAMA_HOST=0.0.0.0` para que escuche en la red. **Consulta antes con la dirección de la
> empresa** qué IA está autorizada para tratar datos de trabajo.

---

## 4. Copias de seguridad (importante)

La carpeta `data` contiene todo: cuentas, notas, progreso y borradores.

```powershell
# Copia con fecha y hora (script incluido)
python .\copia_de_seguridad.py

# Ver las copias que hay
python .\copia_de_seguridad.py --listar

# Restaurar una copia concreta
python .\copia_de_seguridad.py --restaurar .\copias\ofimatica_2026-10-28_1200.db
```

Alternativa rápida con robocopy:

```powershell
robocopy "C:\ofimatica-oficina\data" "D:\Copias\ofimatica" /MIR /R:1 /W:1
```

Opcionalmente, crea una tarea programada de Windows que la ejecute cada noche.
En OneDrive de la empresa puedes dejar la carpeta `data` sincronizada.

> Si el curso está en la nube, la copia se descarga desde el panel del servidor
> (Render → Shell) y se guarda en un Drive de la empresa.

---

## 5. Problemas frecuentes

| Síntoma | Solución |
|---|---|
| Los demás equipos no pueden entrar | Cortafuegos, perfil de red «Privada» o IP equivocada. |
| «El acceso está bloqueado» en Edge | Es un aviso de PWA: usa el acceso directo del Escritorio. |
| El icono del Escritorio no abre nada | Comprueba que la dirección del atajo sea correcta (clic derecho → Propiedades). |
| El puerto 8080 está ocupado | Arranca con otro puerto y actualiza accesos y cortafuegos. |
| Se ha olvidado la contraseña de una alumna | Panel de administración → la cuenta → *Cambiar contraseña*. |
| La alumna no encuentra su lección de correo | En *Ajustes → Mi programa de correo* puede cambiar a Outlook, Thunderbird o los dos. |
| ¿Dónde está lo que estaba haciendo? | Se guarda solo. En *Mi curso* aparece «Tenías esto a medias»; en los exámenes, las respuestas se recuperan solas. |
| Quiero empezar de cero | Borra `data\ofimatica.db` y reinicia el servidor. |

---

## 6. Archivos de esta carpeta

| Archivo | Para qué sirve |
|---|---|
| `instalar_servidor.ps1` | Instala y configura el equipo servidor (todo en uno). |
| `crear_acceso_directo.ps1` | Crea el icono del Escritorio y la entrada del menú Inicio. |
| `instalar_en_este_equipo.bat` | Atajo para los equipos del aula. |
| `iniciar_ofimatica.bat` | Arranca el servidor a mano (o desde la tarea programada). |
| `ofimatica.ico` | Icono de la aplicación. |
| `copia_de_seguridad.py` | Copias y restauración de la base de datos (sin dependencias). |
| `DEPLOY_EN_LA_NUBE.md` | Guía para publicar el curso en un servidor permanente. |
