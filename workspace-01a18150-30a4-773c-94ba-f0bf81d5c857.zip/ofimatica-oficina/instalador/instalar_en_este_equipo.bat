@echo off
REM ===========================================================================
REM  Atajo para el ALUMNO: instala el acceso directo en este equipo.
REM  (Equivalente a ejecutar crear_acceso_directo.ps1 con la direccion correcta)
REM ===========================================================================
echo.
echo   ============================================================
echo    ACCESO DIRECTO - Oficina de Ofimatica
echo   ============================================================
echo.
set /p URL="Escribe la direccion del curso que te ha dado tu responsable (ej: http://192.168.1.50:8080): "
if "%URL%"=="" (
  set URL=http://localhost:8080
)

powershell -ExecutionPolicy Bypass -File "%~dp0crear_acceso_directo.ps1" -Url "%URL%" -Nombre "Oficina de Ofimática"

echo.
echo   Listo. Busca 'Ofimatica' en el menu Inicio de Windows.
pause
