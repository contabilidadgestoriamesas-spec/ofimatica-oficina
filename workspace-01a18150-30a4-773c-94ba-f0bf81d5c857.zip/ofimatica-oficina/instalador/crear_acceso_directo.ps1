# ============================================================================
#  Crea el acceso directo de "Oficina de Ofimática" en el ESCITORIO y en el
#  MENÚ INICIO de Windows 11 (para cada computadora del aula).
#
#  Uso (doble clic con clic derecho -> "Ejecutar con PowerShell"):
#     .\crear_acceso_directo.ps1 -Url "http://192.168.1.50:8080"
#
#  O bien, si lo ejecutas desde la carpeta del servidor:
#     .\crear_acceso_directo.ps1
# ============================================================================
param(
    [string]$Url = "",
    [string]$Nombre = "Oficina de Ofimática",
    [switch]$SinModoApp
)

$ErrorActionPreference = "Stop"

if ([string]::IsNullOrWhiteSpace($Url)) {
    $propio = $PSScriptRoot
    $Url = "http://localhost:8080"
    Write-Host ""
    Write-Host "  ----------------------------------------------------------" -ForegroundColor DarkCyan
    Write-Host "   INSTALADOR DEL ACCESO DIRECTO - Oficina de Ofimática" -ForegroundColor Cyan
    Write-Host "  ----------------------------------------------------------" -ForegroundColor DarkCyan
    Write-Host ""
    $esServidor = Read-Host "¿Este equipo es el SERVIDOR del curso? (S/N)"
    if ($esServidor -eq "S" -or $esServidor -eq "s") {
        $ip = (Get-NetIPAddress -AddressFamily IPv4 |
               Where-Object { $_.IPAddress -notlike "127.*" -and $_.PrefixOrigin -ne "WellKnown" } |
               Select-Object -First 1).IPAddress
        Write-Host ""
        Write-Host "  Dirección detectada para la red de la oficina: http://$ip`:8080" -ForegroundColor Green
        $confirmar = Read-Host "¿La usamos? (S/N)"
        if ($confirmar -eq "S" -or $confirmar -eq "s") { $Url = "http://$ip`:8080" }
    } else {
        $Url = Read-Host "Escribe la dirección del curso que te ha dado tu responsable"
    }
}

Write-Host ""
Write-Host "  Dirección del curso: $Url" -ForegroundColor Yellow

# --- Icono propio -----------------------------------------------------------
$icono = Join-Path $PSScriptRoot "ofimatica.ico"
if (-not (Test-Path $icono)) { $icono = "" }

# --- Buscar Microsoft Edge (para el modo aplicación: sin barra de navegador) -
$edge = @(
    "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
    "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"
) | Where-Object { Test-Path $_ } | Select-Object -First 1

$shell = New-Object -ComObject WScript.Shell

function Crear-Acceso($rutaCarpeta, $nombre, $destino, $argumentos) {
    if (-not (Test-Path $rutaCarpeta)) { New-Item -ItemType Directory -Path $rutaCarpeta -Force | Out-Null }
    $atajo = $shell.CreateShortcut((Join-Path $rutaCarpeta $nombre))
    $atajo.TargetPath = $destino
    $atajo.Arguments = $argumentos
    $atajo.WorkingDirectory = $rutaCarpeta
    $atajo.Description = "Curso de ofimática de la oficina"
    $atajo.WindowStyle = 1
    if ($icono -ne "") { $atajo.IconLocation = "$icono,0" }
    $atajo.Save()
    Write-Host "  [OK] $rutaCarpeta\$nombre" -ForegroundColor Green
}

# 1) Escritorio
$escritorio = [Environment]::GetFolderPath("Desktop")
if ($edge -and -not $SinModoApp) {
    Crear-Acceso $escritorio "$Nombre.lnk" $edge "--app=$Url --window-size=1280,860"
} else {
    # Acceso directo .url (funciona con cualquier navegador)
    $rutaUrl = Join-Path $escritorio "$Nombre.url"
    @"
[InternetShortcut]
URL=$Url
IconFile=$icono
IconIndex=0
"@ | Set-Content -Path $rutaUrl -Encoding UTF8
    Write-Host "  [OK] $rutaUrl" -ForegroundColor Green
}

# 2) Menú Inicio (todos las aplicaciones) - para todas las cuentas del equipo
$inicio = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs"
if ($edge -and -not $SinModoApp) {
    Crear-Acceso $inicio "$Nombre.lnk" $edge "--app=$Url --window-size=1280,860"
} else {
    Crear-Acceso $inicio "$Nombre.lnk" "$env:WINDIR\system32\rundll32.exe" "url.dll,FileProtocolHandler $Url"
}

# 3) Acceso rápido en la barra de tareas (Windows 11 lo permite con un .lnk)
try {
    $barra = Join-Path $env:APPDATA "Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar"
    if (Test-Path $barra) {
        Copiedor = $null
        if ($edge -and -not $SinModoApp) {
            Copiar-Item (Join-Path $escritorio "$Nombre.lnk") (Join-Path $barra "$Nombre.lnk") -Force -ErrorAction SilentlyContinue
            Write-Host "  [OK] Anclado en la barra de tareas (si Windows lo permite)" -ForegroundColor Green
        }
    }
} catch { }

Write-Host ""
Write-Host "  ----------------------------------------------------------" -ForegroundColor DarkCyan
Write-Host "   LISTO. Ya puedes abrir el curso desde el Escritorio" -ForegroundColor Cyan
Write-Host "   o buscándolo en el menú Inicio (escribe 'Ofimática')." -ForegroundColor Cyan
Write-Host "  ----------------------------------------------------------" -ForegroundColor DarkCyan
Write-Host ""
Start-Process -FilePath "ms-settings:startapps" -ErrorAction SilentlyContinue
Write-Host "  Se ha abierto 'Configuración > Aplicaciones > Inicio' para que puedas" -ForegroundColor DarkGray
Write-Host "  anclar la aplicación a la primera pantalla de Windows 11." -ForegroundColor DarkGray
Write-Host ""
Read-Host "Pulsa Intro para salir"
