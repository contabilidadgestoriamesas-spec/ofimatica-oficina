"""Panel de administración: alta de usuarias, progreso, IA y contenidos."""
import json

from flask import (Blueprint, flash, redirect, render_template, request, url_for)

from . import db
from .assistant import PERSONAJES
from .auth import admin_requerido, hash_password, usuario_actual, validar_password
from .ia import configuracion_ia, guardar_configuracion_ia, probar_conexion
from .programa import CLIENTES_CORREO

bp = Blueprint("admin", __name__, url_prefix="/admin")


def _generar_username(nombre, forzar=None):
    """Crea un nombre de usuario a partir del nombre de la persona (mgarcia, jlopez...)."""
    import re
    import unicodedata

    base = (forzar or nombre or "").strip()
    if base:
        plano = unicodedata.normalize("NFKD", base.lower())
        plano = "".join(c for c in plano if not unicodedata.combining(c))
        palabras = re.findall(r"[a-z0-9]+", plano)
    else:
        palabras = []
    if not palabras:
        palabras = ["usuario"]
    if len(palabras) == 1:
        raiz = palabras[0][:20]
    else:
        raiz = (palabras[0][:1] + palabras[-1][:19])[:20]
    raiz = raiz or "usuario"
    candidato = raiz
    n = 2
    while db.q1("SELECT id FROM users WHERE lower(username) = ?", (candidato,)):
        candidato = "%s%d" % (raiz, n)
        n += 1
        if n > 200:
            break
    return candidato


def _modulos_validos(seleccionados):
    """Deja solo los módulos que existen realmente y los guarda separados por comas."""
    if not seleccionados:
        return "todos"
    validos = {m["slug"] for m in db.q("SELECT slug FROM modules")}
    limpios = [s.strip() for s in seleccionados if s.strip() in validos]
    return ",".join(limpios) if limpios else "todos"


@bp.route("/")
@admin_requerido
def panel():
    total = db.q1("SELECT COUNT(*) AS n FROM users")["n"]
    alumnos = db.q1("SELECT COUNT(*) AS n FROM users WHERE role = 'alumno'")["n"]
    activos = db.q1(
        "SELECT COUNT(*) AS n FROM users WHERE last_login IS NOT NULL AND last_login > ?",
        ((__import__("datetime").datetime.now() - __import__("datetime").timedelta(days=30)).isoformat(timespec="seconds"),),
    )["n"]
    lecciones = db.q1("SELECT COUNT(*) AS n FROM lessons")["n"]
    completadas = db.q1("SELECT COUNT(*) AS n FROM progress WHERE completado = 1")["n"]
    intentos = db.q1("SELECT COUNT(*) AS n FROM exam_attempts")["n"]
    actividad = db.q("SELECT * FROM activity ORDER BY id DESC LIMIT 15")
    ultimos = db.q(
        """SELECT u.id, u.username, u.nombre, u.last_login,
                  (SELECT COUNT(*) FROM progress p WHERE p.user_id = u.id AND p.completado = 1) AS lec,
                  (SELECT COALESCE(MAX(ea.score),0) FROM exam_attempts ea WHERE ea.user_id = u.id) AS nota,
                  (SELECT COALESCE(s.puntos,0) FROM user_stats s WHERE s.user_id = u.id) AS puntos
           FROM users u WHERE u.role = 'alumno' ORDER BY u.last_login DESC NULLS LAST LIMIT 10"""
    )
    return render_template(
        "admin/panel.html", total=total, alumnos=alumnos, activos=activos,
        lecciones=lecciones, completadas=completadas, intentos=intentos,
        actividad=actividad, ultimos=ultimos, ia=configuracion_ia(),
    )


# --------------------------------------------------------------------------- #
# Usuarias
# --------------------------------------------------------------------------- #
@bp.route("/usuarios")
@admin_requerido
def usuarios():
    filas = db.q(
        """SELECT u.*,
                  (SELECT COUNT(*) FROM progress p WHERE p.user_id = u.id AND p.completado = 1) AS lec,
                  (SELECT COUNT(*) FROM lessons) AS lec_tot,
                  (SELECT COALESCE(MAX(ea.score),0) FROM exam_attempts ea WHERE ea.user_id = u.id) AS nota,
                  (SELECT COALESCE(s.puntos,0) FROM user_stats s WHERE s.user_id = u.id) AS puntos
           FROM users u ORDER BY u.role, u.username"""
    )
    modulos = db.q("SELECT slug, titulo FROM modules ORDER BY orden")
    return render_template("admin/usuarios.html", filas=filas, modulos=modulos,
                           clientes_correo=CLIENTES_CORREO)


@bp.route("/usuarios/nuevo", methods=["GET", "POST"])
@admin_requerido
def usuario_nuevo():
    modulos = db.q("SELECT slug, titulo FROM modules ORDER BY orden")
    if request.method == "POST":
        nombre = (request.form.get("nombre") or "").strip()
        username_manual = (request.form.get("username") or "").strip().lower()
        email = (request.form.get("email") or "").strip()
        password = request.form.get("password") or ""
        repetir = request.form.get("repetir") or ""
        role = request.form.get("role") or "alumno"
        modulos_sel = request.form.getlist("modulos")
        assistant = request.form.get("assistant") or "chispita"
        email_client = request.form.get("email_client") or "ambos"
        if email_client not in CLIENTES_CORREO:
            email_client = "ambos"

        # El nombre de usuario se genera solo a partir del nombre, salvo que se escriba a mano.
        if username_manual:
            if not username_manual.replace("_", "").replace(".", "").replace("-", "").isalnum():
                flash("El nombre de usuario solo puede tener letras, números, punto, guion y guion bajo.", "error")
                return render_template("admin/usuario_form.html", modulos=modulos, nuevo=True, datos={},
                                       clientes_correo=CLIENTES_CORREO, personajes=PERSONAJES)
            username = username_manual
            if db.q1("SELECT id FROM users WHERE lower(username) = ?", (username,)):
                flash("Ese nombre de usuario ya existe.", "error")
                return render_template("admin/usuario_form.html", modulos=modulos, nuevo=True, datos={},
                                       clientes_correo=CLIENTES_CORREO, personajes=PERSONAJES)
        else:
            username = _generar_username(nombre)

        if not nombre:
            flash("Escribe el nombre de la persona (con el nombre basta).", "error")
        elif password != repetir:
            flash("La contraseña y su repetición no coinciden.", "error")
        else:
            ok, msg = validar_password(password)
            if not ok:
                flash(msg, "error")
            else:
                permisos = _modulos_validos(modulos_sel)
                db.execute(
                    """INSERT INTO users(username, nombre, email, password_hash, role, activo,
                                       assistant, modulos, email_client, debe_cambiar)
                       VALUES(?,?,?,?,?,1,?,?,?,?)""",
                    (username, nombre, email, hash_password(password), role, assistant,
                     permisos, email_client, 1),
                )
                db.log(None, "admin", "alta", "Nueva cuenta: %s (%s)" % (username, nombre))
                flash("Cuenta creada para %s. Usuario: %s · Contraseña: %s"
                      % (nombre, username, password), "ok")
                return redirect(url_for("admin.usuarios"))
    return render_template("admin/usuario_form.html", modulos=modulos, nuevo=True, datos={},
                           clientes_correo=CLIENTES_CORREO, personajes=PERSONAJES)


@bp.route("/usuarios/<int:uid>", methods=["GET", "POST"])
@admin_requerido
def usuario_editar(uid):
    u = db.q1("SELECT * FROM users WHERE id = ?", (uid,))
    if not u:
        flash("Cuenta no encontrada.", "error")
        return redirect(url_for("admin.usuarios"))
    modulos = db.q("SELECT slug, titulo FROM modules ORDER BY orden")
    if request.method == "POST":
        accion = request.form.get("accion")
        if accion == "password":
            nueva = request.form.get("password") or ""
            repetir = request.form.get("repetir") or ""
            if nueva != repetir:
                flash("La contraseña y su repetición no coinciden.", "error")
            else:
                ok, msg = validar_password(nueva)
                if not ok:
                    flash(msg, "error")
                else:
                    db.execute(
                        "UPDATE users SET password_hash = ?, debe_cambiar = ? WHERE id = ?",
                        (hash_password(nueva), 1 if request.form.get("debe_cambiar") else 0, uid),
                    )
                    flash("Contraseña actualizada: %s" % nueva, "ok")
        elif accion == "perfil":
            modulos_sel = request.form.getlist("modulos")
            permisos = _modulos_validos(modulos_sel)
            email_client = request.form.get("email_client") or "ambos"
            if email_client not in CLIENTES_CORREO:
                email_client = "ambos"
            nuevo_username = (request.form.get("username") or "").strip().lower()
            campos = ["nombre = ?", "email = ?", "role = ?", "activo = ?", "modulos = ?",
                      "assistant = ?", "email_client = ?"]
            valores = [
                (request.form.get("nombre") or "").strip(),
                (request.form.get("email") or "").strip(),
                request.form.get("role") or "alumno",
                1 if request.form.get("activo") else 0,
                permisos,
                request.form.get("assistant") or "chispita",
                email_client,
            ]
            if nuevo_username and nuevo_username != u["username"]:
                if not nuevo_username.replace("_", "").replace(".", "").replace("-", "").isalnum():
                    flash("El nombre de usuario solo puede tener letras, números, punto, guion y guion bajo.", "error")
                    return redirect(url_for("admin.usuario_editar", uid=uid))
                if db.q1("SELECT id FROM users WHERE lower(username) = ? AND id != ?", (nuevo_username, uid)):
                    flash("Ese nombre de usuario ya existe.", "error")
                    return redirect(url_for("admin.usuario_editar", uid=uid))
                campos.append("username = ?")
                valores.append(nuevo_username)
            valores.append(uid)
            db.execute(
                "UPDATE users SET %s WHERE id = ?" % ", ".join(campos), valores
            )
            db.log(None, "admin", "editar", "Cuenta %s modificada" % u["username"])
            flash("Datos actualizados.", "ok")
        elif accion == "eliminar":
            if u["role"] == "admin" and db.q1(
                "SELECT COUNT(*) AS n FROM users WHERE role = 'admin'"
            )["n"] <= 1:
                flash("No puedes eliminar la última cuenta de administrador.", "error")
            else:
                db.execute("DELETE FROM users WHERE id = ?", (uid,))
                db.log(None, "admin", "eliminar", "Cuenta %s eliminada" % u["username"])
                flash("Cuenta eliminada.", "ok")
                return redirect(url_for("admin.usuarios"))
        return redirect(url_for("admin.usuario_editar", uid=uid))

    progreso = db.q(
        """SELECT l.titulo, m.titulo AS modulo, p.completado, p.updated_at
           FROM progress p JOIN lessons l ON l.id = p.lesson_id
           JOIN modules m ON m.id = l.module_id
           WHERE p.user_id = ? ORDER BY m.orden, l.orden""",
        (uid,),
    )
    intentos = db.q(
        """SELECT ea.*, e.titulo FROM exam_attempts ea JOIN exams e ON e.id = ea.exam_id
           WHERE ea.user_id = ? ORDER BY ea.id DESC""",
        (uid,),
    )
    st = db.q1("SELECT * FROM user_stats WHERE user_id = ?", (uid,))
    return render_template(
        "admin/usuario_form.html", modulos=modulos, nuevo=False, u=u,
        progreso=progreso, intentos=intentos, stats=st,
        clientes_correo=CLIENTES_CORREO, personajes=PERSONAJES,
    )


# --------------------------------------------------------------------------- #
# Progreso global
# --------------------------------------------------------------------------- #
@bp.route("/progreso")
@admin_requerido
def progreso():
    filas = db.q(
        """SELECT u.id, u.username, u.nombre, u.last_login, u.activo,
                  (SELECT COUNT(*) FROM progress p WHERE p.user_id = u.id AND p.completado = 1) AS lec,
                  (SELECT COUNT(*) FROM lessons) AS lec_tot,
                  (SELECT COUNT(*) FROM exam_attempts ea WHERE ea.user_id = u.id AND ea.aprobado = 1) AS ex_ok,
                  (SELECT COALESCE(MAX(ea.score),0) FROM exam_attempts ea WHERE ea.user_id = u.id) AS nota,
                  (SELECT COALESCE(s.puntos,0) FROM user_stats s WHERE s.user_id = u.id) AS puntos,
                  (SELECT COALESCE(s.racha,0) FROM user_stats s WHERE s.user_id = u.id) AS racha
           FROM users u WHERE u.role = 'alumno' ORDER BY u.nombre"""
    )
    detalle = {}
    for f in filas:
        detalle[f["id"]] = db.q(
            """SELECT m.titulo, m.icono,
                      (SELECT COUNT(*) FROM lessons l WHERE l.module_id = m.id) AS tot,
                      (SELECT COUNT(*) FROM progress p JOIN lessons l ON l.id = p.lesson_id
                        WHERE p.user_id = ? AND l.module_id = m.id AND p.completado = 1) AS hec
               FROM modules m ORDER BY m.orden""",
            (f["id"],),
        )
    return render_template("admin/progreso.html", filas=filas, detalle=detalle)


# --------------------------------------------------------------------------- #
# Configuración de la IA
# --------------------------------------------------------------------------- #
@bp.route("/ia", methods=["GET", "POST"])
@admin_requerido
def ia():
    conf = configuracion_ia()
    mensaje = None
    tipo = None
    if request.method == "POST":
        accion = request.form.get("accion")
        if accion == "guardar":
            guardar_configuracion_ia(request.form)
            flash("Configuración de la IA guardada.", "ok")
            return redirect(url_for("admin.ia"))
        if accion == "probar":
            conf = guardar_configuracion_ia(request.form)
            ok, msg = probar_conexion()
            tipo = "ok" if ok else "error"
            mensaje = msg
    return render_template("admin/ia.html", ia=configuracion_ia(), mensaje=mensaje,
                           tipo_tipo=tipo, personajes=PERSONAJES)


# --------------------------------------------------------------------------- #
# Contenidos: manual editable
# --------------------------------------------------------------------------- #
@bp.route("/contenido")
@admin_requerido
def contenido():
    articulos = db.q("SELECT * FROM articles ORDER BY categoria, titulo")
    categorias = db.q("SELECT DISTINCT categoria FROM articles ORDER BY categoria")
    modulos = db.q(
        """SELECT m.*, (SELECT COUNT(*) FROM lessons l WHERE l.module_id = m.id) AS lecciones
           FROM modules m ORDER BY m.orden"""
    )
    ejercicios = db.q(
        """SELECT e.*, m.titulo AS modulo FROM exercises e LEFT JOIN modules m ON m.id = e.module_id
           ORDER BY e.id"""
    )
    return render_template("admin/contenido.html", articulos=articulos, categorias=categorias,
                           modulos=modulos, ejercicios=ejercicios)


@bp.route("/contenido/articulo/nuevo", methods=["GET", "POST"])
@admin_requerido
def articulo_nuevo():
    categorias = db.q("SELECT DISTINCT categoria FROM articles ORDER BY categoria")
    if request.method == "POST":
        titulo = (request.form.get("titulo") or "").strip()
        if not titulo:
            flash("El título es obligatorio.", "error")
        else:
            slug = _slug(titulo)
            if db.q1("SELECT id FROM articles WHERE slug = ?", (slug,)):
                slug = slug + "-" + db.q1("SELECT COUNT(*) AS n FROM articles")["n"]
            db.execute(
                """INSERT INTO articles(slug, titulo, categoria, tags, cuerpo, fuente)
                   VALUES(?,?,?,?,?,?)""",
                (slug, titulo, request.form.get("categoria") or "General",
                 request.form.get("tags") or "", request.form.get("cuerpo") or "",
                 request.form.get("fuente") or ""),
            )
            db.log(None, "admin", "contenido", "Artículo creado: %s" % titulo)
            flash("Artículo añadido al manual.", "ok")
            return redirect(url_for("admin.contenido"))
    return render_template("admin/articulo_form.html", categorias=categorias, nuevo=True, art={})


@bp.route("/contenido/articulo/<int:aid>", methods=["GET", "POST"])
@admin_requerido
def articulo_editar(aid):
    art = db.q1("SELECT * FROM articles WHERE id = ?", (aid,))
    if not art:
        flash("Artículo no encontrado.", "error")
        return redirect(url_for("admin.contenido"))
    categorias = db.q("SELECT DISTINCT categoria FROM articles ORDER BY categoria")
    if request.method == "POST":
        if request.form.get("accion") == "eliminar":
            db.execute("DELETE FROM articles WHERE id = ?", (aid,))
            flash("Artículo eliminado.", "ok")
            return redirect(url_for("admin.contenido"))
        db.execute(
            """UPDATE articles SET titulo = ?, categoria = ?, tags = ?, cuerpo = ?, fuente = ?,
                                   updated_at = CURRENT_TIMESTAMP WHERE id = ?""",
            ((request.form.get("titulo") or art["titulo"]).strip(),
             request.form.get("categoria") or art["categoria"],
             request.form.get("tags") or art["tags"],
             request.form.get("cuerpo") or art["cuerpo"],
             request.form.get("fuente") or art["fuente"],
             aid),
        )
        flash("Artículo actualizado.", "ok")
        return redirect(url_for("admin.contenido"))
    return render_template("admin/articulo_form.html", categorias=categorias, nuevo=False, art=art)


def _slug(texto):
    import re
    import unicodedata

    t = unicodedata.normalize("NFKD", texto.lower())
    t = "".join(c for c in t if not unicodedata.combining(c))
    t = re.sub(r"[^a-z0-9]+", "-", t).strip("-")
    return t[:90] or "articulo"


# --------------------------------------------------------------------------- #
# Registro de actividad
# --------------------------------------------------------------------------- #
@bp.route("/actividad")
@admin_requerido
def actividad():
    filas = db.q("SELECT * FROM activity ORDER BY id DESC LIMIT 300")
    return render_template("admin/actividad.html", filas=filas)
