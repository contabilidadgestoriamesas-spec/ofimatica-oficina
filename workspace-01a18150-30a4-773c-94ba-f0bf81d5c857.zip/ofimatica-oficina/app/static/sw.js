/* Service worker mínimo: permite que la aplicación se instale como app de Windows 11
   y cachea la capa estática para que abra rápido. */
const CACHE = "ofimatica-v2";
const RECURSOS = [
  "/static/css/estilos.css",
  "/static/js/ayudante.js",
  "/static/js/ejercicio.js",
  "/static/js/autoguardado.js",
  "/static/img/logo.svg",
  "/static/manifest.webmanifest"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE).then((cache) => cache.addAll(RECURSOS)).catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((claves) =>
      Promise.all(claves.filter((c) => c !== CACHE).map((c) => caches.delete(c)))
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);
  if (event.request.method !== "GET" || url.origin !== self.location.origin) return;
  // Solo cacheamos recursos estáticos; las páginas siempre se piden al servidor
  // (las notas y el progreso deben estar siempre al día).
  if (!url.pathname.startsWith("/static/")) return;
  event.respondWith(
    caches.match(event.request).then((guardado) =>
      guardado || fetch(event.request).then((respuesta) => {
        const copia = respuesta.clone();
        caches.open(CACHE).then((cache) => cache.put(event.request, copia)).catch(() => {});
        return respuesta;
      })
    )
  );
});
