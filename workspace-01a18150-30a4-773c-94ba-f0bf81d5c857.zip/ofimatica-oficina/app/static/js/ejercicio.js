/* ==========================================================================
   Motor de ejercicios interactivos
   ========================================================================== */
(function () {
  "use strict";

  var zona = document.getElementById("zona-ejercicio");
  if (!zona) { return; }

  var tipo = zona.getAttribute("data-tipo");
  var ejercicioId = zona.getAttribute("data-ejercicio");
  var cfg = JSON.parse(zona.getAttribute("data-config") || "{}");
  var cont = document.getElementById("contenido-interactivo");
  var resultado = document.getElementById("resultado");
  var btnComprobar = document.getElementById("btn-comprobar");
  var btnReiniciar = document.getElementById("btn-reiniciar");

  var estado = { respuestas: {}, orden: [], teclas: [], acierto: false, formula: "", texto: "", negrita: false };

  // Avisa al módulo de guardado automático de que han cambiado las respuestas.
  function notificar() {
    try {
      document.dispatchEvent(new CustomEvent("ofimatica:respuestas", { detail: estado }));
    } catch (e) { }
  }

  // ------------------------------------------------------------------ //
  function construir() {
    cont.innerHTML = "";
    estado = { respuestas: {}, orden: [], teclas: [], acierto: false, formula: "", texto: "", negrita: false };
    resultado.innerHTML = "";

    notificar();
    if (tipo === "opcion") { construirOpcion(); }
    else if (tipo === "orden") { construirOrden(); }
    else if (tipo === "teclas") { construirTeclas(); }
    else if (tipo === "raton") { construirRaton(); }
    else if (tipo === "celdas") { construirCeldas(); }
    else if (tipo === "texto") { construirTexto(); }
  }

  // ---------- Opción múltiple ----------
  function construirOpcion() {
    var preguntas = cfg.preguntas || [];
    preguntas.forEach(function (pr, idx) {
      var bloque = document.createElement("div");
      bloque.className = "tarjeta";
      bloque.style.marginBottom = "1rem";
      var h = document.createElement("h4");
      h.textContent = (idx + 1) + ". " + pr.pregunta;
      h.style.marginTop = "0";
      bloque.appendChild(h);
      (pr.opciones || []).forEach(function (op, oi) {
        var lab = document.createElement("label");
        lab.className = "opcion";
        var radio = document.createElement("input");
        radio.type = "radio";
        radio.name = "p" + idx;
        radio.value = String(oi);
        radio.addEventListener("change", function () {
          estado.respuestas[String(idx)] = String(oi);
          notificar();
          var cajas = bloque.querySelectorAll(".opcion");
          for (var i = 0; i < cajas.length; i++) { cajas[i].classList.remove("seleccionada"); }
          lab.classList.add("seleccionada");
        });
        var span = document.createElement("span");
        span.textContent = op;
        lab.appendChild(radio);
        lab.appendChild(span);
        bloque.appendChild(lab);
      });
      cont.appendChild(bloque);
    });
  }

  // ---------- Pasos en orden ----------
  function construirOrden() {
    var pasos = (cfg.pasos || []).slice();
    // barajado determinista pero distinto del orden original
    pasos = pasos.map(function (p, i) { return { p: p, k: (i * 7 + 3) % 11 }; })
                 .sort(function (a, b) { return a.k - b.k; })
                 .map(function (o) { return o.p; });
    var ul = document.createElement("ul");
    ul.className = "pasos-ordenables";
    ul.id = "lista-pasos";
    pasos.forEach(function (p) {
      var li = document.createElement("li");
      li.innerHTML = '<span class="num"></span><span class="txt"></span>';
      li.querySelector(".txt").textContent = p;
      li.addEventListener("click", function () {
        var sel = ul.querySelector(".seleccionado");
        if (sel) { sel.classList.remove("seleccionado"); sel.querySelector(".num").textContent = ""; }
        li.classList.add("seleccionado");
        li.querySelector(".num").textContent = String(estado.orden.length + 1);
        estado.orden.push(p);
      });
      ul.appendChild(li);
    });
    cont.appendChild(ul);
    var pista = document.createElement("p");
    pista.className = "meta";
    pista.textContent = "Haz clic en los pasos en el orden correcto. Puedes corregirlo: vuelve a hacer clic en uno ya elegido.";
    cont.appendChild(pista);
  }

  // ---------- Pulsar teclas ----------
  var NOMBRES = {
    "Control": ["Control", "ControlLeft", "ControlRight"],
    "Ctrl": ["Control", "ControlLeft", "ControlRight"],
    "Shift": ["Shift", "ShiftLeft", "ShiftRight"],
    "Alt": ["Alt", "AltLeft", "AltRight"],
    "Windows": ["Meta", "OSLeft", "OSRight"],
    "Escape": ["Escape"], "Enter": ["Enter", "NumpadEnter"], "Tab": ["Tab"],
    "Backspace": ["Backspace"], "Delete": ["Delete"], "CapsLock": ["CapsLock"]
  };

  function construirTeclas() {
    var seq = cfg.secuencia || [];
    var info = document.createElement("p");
    info.className = "meta";
    info.textContent = "Pulsa la combinación que te pide el ejercicio, en el orden indicado. Usa tu teclado.";
    cont.appendChild(info);
    var caja = document.createElement("div");
    caja.style.cssText = "display:flex;gap:1rem;align-items:center;flex-wrap:wrap;margin:1rem 0";
    var display = document.createElement("div");
    display.className = "tecla-pulsada";
    display.id = "tecla-actual";
    display.textContent = "Pulsa aquí";
    caja.appendChild(display);
    cont.appendChild(caja);

    var restantes = seq.length;
    var indice = 0;

    function normalizar(evento) {
      var partes = [];
      if (evento.ctrlKey) partes.push("Control");
      if (evento.altKey) partes.push("Alt");
      if (evento.shiftKey) partes.push("Shift");
      if (evento.metaKey) partes.push("Windows");
      var c = evento.code || "";
      if (/^Key[A-Z]$/.test(c)) { partes.push(c.replace("Key", "")); }
      else if (/^Digit/.test(c)) { partes.push(c.replace("Digit", "")); }
      else if (/^Numpad/.test(c)) { partes.push(c.replace("Numpad", "")); }
      else {
        var mapa = { ControlLeft: "Control", ControlRight: "Control", ShiftLeft: "Shift", ShiftRight: "Shift",
                     AltLeft: "Alt", AltRight: "Alt", MetaLeft: "Windows", MetaRight: "Windows", OSLeft: "Windows", OSRight: "Windows",
                     Escape: "Escape", Enter: "Enter", NumpadEnter: "Enter", Tab: "Tab", Backspace: "Backspace",
                     Delete: "Delete", CapsLock: "CapsLock", Space: "Espacio" };
        if (mapa[c]) partes.push(mapa[c]);
      }
      return partes.join("+");
    }

    function esperado(actual) {
      var objetivo = (seq[indice] || {}).tecla || "";
      var partesObjetivo = objetivo.split("+");
      var partesActuales = actual.split("+");
      if (partesActuales.length !== partesObjetivo.length) { return false; }
      return partesObjetivo.every(function (p) {
        return partesActuales.indexOf(p) !== -1;
      });
    }

    document.addEventListener("keydown", function (ev) {
      if (indice >= seq.length) { return; }
      if (ev.target && /^(INPUT|TEXTAREA)$/.test(ev.target.tagName)) { return; }
      ev.preventDefault();
      var combo = normalizar(ev);
      if (!combo) { return; }
      var ok = esperado(combo);
      estado.teclas.push((seq[indice] || {}).tecla || combo);
      notificar();
      display.className = "tecla-pulsada " + (ok ? "ok" : "no");
      display.textContent = combo;
      setTimeout(function () {
        indice++;
        if (indice < seq.length) {
          display.className = "tecla-pulsada";
          display.textContent = (seq[indice].tecla || "").replace("Control", "Ctrl");
        } else {
          display.className = "tecla-pulsada ok";
          display.textContent = "¡Hecho!";
        }
      }, 450);
    });

    // Muestra la primera tecla
    if (seq.length) {
      display.textContent = (seq[0].tecla || "").replace("Control", "Ctrl");
    }
  }

  // ---------- Ratón en pantalla simulada ----------
  function construirRaton() {
    var pantalla = document.createElement("div");
    pantalla.className = "pantalla-simulada";

    if (cfg.pantalla === "ventana") {
      var v = document.createElement("div");
      v.className = "ps-ventana";
      v.style.cssText = "left:14%;top:16%;width:70%;height:68%";
      v.innerHTML = '<div class="ps-barra"><span style="background:#e8734a"></span>' +
                    '<span style="background:#f2c14e"></span><span style="background:#6fbf73"></span></div>' +
                    '<div class="ps-cuerpo"><b>Documento1 - Word</b><br><br>' +
                    'Este es el contenido de tu documento.<br>Escribe aquí…</div>';
      pantalla.appendChild(v);
    }

    var tarea = document.createElement("div");
    tarea.className = "ps-tarea";
    pantalla.appendChild(tarea);

    (cfg.elementos || []).forEach(function (el) {
      var b = document.createElement("div");
      b.className = "ps-boton";
      b.textContent = el.etiqueta;
      b.style.left = el.x + "%";
      b.style.top = el.y + "%";
      b.style.width = el.w + "%";
      b.style.height = el.h + "%";
      b.addEventListener("click", function (ev) {
        ev.stopPropagation();
        var acertado = !!el.correcto;
        estado.acierto = acertado;
        Array.prototype.forEach.call(pantalla.querySelectorAll(".ps-boton"), function (x) {
          x.classList.remove("acierto", "fallo");
        });
        b.classList.add(acertado ? "acierto" : "fallo");
        if (!acertado && el.pista) {
          var p = document.createElement("p");
          p.className = "meta";
          p.style.color = "#fff";
          p.style.marginTop = ".6rem";
          p.textContent = "Pista: " + el.pista;
          cont.appendChild(p);
        }
      });
      pantalla.appendChild(b);
    });

    cont.appendChild(pantalla);
    var pista = document.createElement("p");
    pista.className = "meta";
    pista.textContent = "Haz clic en la zona que creas correcta.";
    cont.appendChild(pista);
  }

  // ---------- Mini hoja de cálculo ----------
  function construirCeldas() {
    var hoja = cfg.hoja || {};
    var filas = {};
    var ref = Object.keys(hoja);
    ref.forEach(function (r) {
      var fila = parseInt(r.replace(/[A-Z]/g, ""), 10);
      filas[fila] = true;
    });
    var numsFila = Object.keys(filas).map(Number).sort(function (a, b) { return a - b; });
    var maxFila = numsFila.length ? numsFila[numsFila.length - 1] : 1;
    var maxCol = 2;

    var tabla = document.createElement("table");
    tabla.className = "mini-hoja";
    var thead = document.createElement("thead");
    var trh = document.createElement("tr");
    trh.innerHTML = "<th></th><th>A</th><th>B</th>";
    thead.appendChild(trh);
    tabla.appendChild(thead);
    var tbody = document.createElement("tbody");

    for (var f = 1; f <= maxFila; f++) {
      var tr = document.createElement("tr");
      var th = document.createElement("th");
      th.textContent = String(f);
      tr.appendChild(th);
      for (var c = 0; c < maxCol; c++) {
        var letra = String.fromCharCode(65 + c);
        var td = document.createElement("td");
        var refCelda = letra + f;
        td.textContent = hoja[refCelda] !== undefined ? hoja[refCelda] : "";
        if (refCelda === cfg.celda_objetivo) {
          td.className = "editable objetivo";
          td.setAttribute("contenteditable", "true");
          td.addEventListener("input", function (ev) {
            estado.formula = ev.target.textContent.trim();
            notificar();
          });
          td.addEventListener("keydown", function (ev) {
            if (ev.key === "Enter") { ev.preventDefault(); ev.target.blur(); }
          });
        } else if (f === 1) {
          td.style.background = "#e8f1fa";
          td.style.fontWeight = "700";
        }
        tr.appendChild(td);
      }
      tbody.appendChild(tr);
    }
    tabla.appendChild(tbody);
    cont.appendChild(tabla);

    var pista = document.createElement("p");
    pista.className = "meta";
    pista.textContent = cfg.pista || "";
    cont.appendChild(pista);

    var ayuda = document.createElement("p");
    ayuda.className = "meta";
    ayuda.innerHTML = "Escribe en la celda amarilla la fórmula (empieza por <code>=</code>) y comprueba con el botón.";
    cont.appendChild(ayuda);
  }

  // ---------- Texto libre ----------
  function construirTexto() {
    var area = document.createElement("textarea");
    area.id = "texto-libre";
    area.placeholder = "Escribe aquí tu texto…";
    area.addEventListener("input", function () { estado.texto = area.value; notificar(); });
    area.addEventListener("keydown", function (ev) {
      if ((ev.ctrlKey || ev.metaKey) && (ev.key === "b" || ev.key === "B")) {
        ev.preventDefault();
        estado.negrita = !estado.negrita;
        area.style.fontWeight = estado.negrita ? "700" : "400";
        var info = document.getElementById("info-negrita");
        if (info) { info.textContent = estado.negrita ? "Negrita: SÍ ✓" : "Negrita: no"; }
      }
    });
    cont.appendChild(area);
    var info = document.createElement("p");
    info.id = "info-negrita";
    info.className = "meta";
    info.textContent = "Negrita: no";
    cont.appendChild(info);
  }

  // ---------- Comprobación ----------
  function comprobar() {
    var cuerpo = { respuestas: {} };
    if (tipo === "opcion") { cuerpo.respuestas = estado.respuestas; }
    else if (tipo === "orden") { cuerpo.respuestas = { orden: estado.orden }; }
    else if (tipo === "teclas") { cuerpo.respuestas = { teclas: estado.teclas }; }
    else if (tipo === "raton") { cuerpo.respuestas = { acierto: estado.acierto }; }
    else if (tipo === "celdas") { cuerpo.respuestas = { formula: estado.formula }; }
    else if (tipo === "texto") { cuerpo.respuestas = { texto: estado.texto, negrita: estado.negrita }; }

    btnComprobar.disabled = true;
    btnComprobar.textContent = "Comprobando…";
    fetch("/api/ejercicio/" + ejercicioId + "/resultado", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(cuerpo)
    })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        btnComprobar.disabled = false;
        btnComprobar.textContent = "Comprobar mis respuestas";
        if (!d.ok) { resultado.innerHTML = '<div class="aviso aviso-error">' + d.mensaje + "</div>"; return; }
        var html = '<div class="aviso aviso-' + (d.superado ? "ok" : "info") + '"><strong>' +
                   (d.superado ? "¡Enhorabuena! " : "Casi lo tienes. ") + d.pct + "%</strong><br>" +
                   d.mensaje + "</div>";
        if (d.detalle && d.detalle.length) {
          html += '<div class="tarjeta"><h4>Revisión</h4>';
          d.detalle.forEach(function (x) {
            html += "<p>" + (x.ok ? "✅ " : "❌ ") + "<strong>" + x.pregunta + "</strong><br>" +
                    '<span class="meta">' + (x.explicacion || "") + "</span></p>";
          });
          html += "</div>";
        }
        resultado.innerHTML = html;
        resultado.scrollIntoView({ behavior: "smooth", block: "nearest" });
      })
      .catch(function () {
        btnComprobar.disabled = false;
        btnComprobar.textContent = "Comprobar mis respuestas";
        resultado.innerHTML = '<div class="aviso aviso-error">No hemos podido comprobarlo. Revisa la conexión y vuelve a intentarlo.</div>';
      });
  }

  // ---------- Restaurar lo que quedó guardado ----------
  function restaurar(datos) {
    if (!datos) { return; }
    if (tipo === "opcion" && datos.respuestas) {
      Object.keys(datos.respuestas).forEach(function (idx) {
        var radio = cont.querySelector('input[name="p' + idx + '"][value="' + datos.respuestas[idx] + '"]');
        if (radio) {
          radio.checked = true;
          var etiqueta = radio.closest(".opcion");
          if (etiqueta) { etiqueta.classList.add("seleccionada"); }
        }
      });
    } else if (tipo === "texto") {
      var area = document.getElementById("texto-libre");
      if (area && datos.texto) {
        area.value = datos.texto;
        estado.texto = datos.texto;
      }
      if (datos.negrita) {
        estado.negrita = true;
        if (area) { area.style.fontWeight = "700"; }
        var info = document.getElementById("info-negrita");
        if (info) { info.textContent = "Negrita: SÍ ✓"; }
      }
    } else if (tipo === "celdas" && datos.formula) {
      var celda = cont.querySelector(".editable.objetivo");
      if (celda) { celda.textContent = datos.formula; }
      estado.formula = datos.formula;
    } else if (tipo === "orden" && datos.orden && datos.orden.length) {
      var lista = document.getElementById("lista-pasos");
      if (lista) {
        var elementos = lista.querySelectorAll("li");
        datos.orden.forEach(function (paso) {
          for (var i = 0; i < elementos.length; i++) {
            var txt = elementos[i].querySelector(".txt");
            if (txt && txt.textContent === paso && !elementos[i].classList.contains("seleccionado")) {
              elementos[i].click();
              break;
            }
          }
        });
      }
    }
  }

  document.addEventListener("ofimatica:restaurar", function (ev) { restaurar(ev.detail); });

  btnComprobar.addEventListener("click", comprobar);
  btnReiniciar.addEventListener("click", construir);
  construir();
})();
