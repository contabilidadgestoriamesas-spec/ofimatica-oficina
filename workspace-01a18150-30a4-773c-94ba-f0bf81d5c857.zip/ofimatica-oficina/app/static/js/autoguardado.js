/* ==========================================================================
   Guardado automático
   --------------------------------------------------------------------------
   - Las lecciones guardan por dónde vas (cada 15 segundos y al salir).
   - Los exámenes guardan las respuestas marcadas.
   - Los ejercicios guardan lo que has escrito o seleccionado.
   Todo se guarda en la propia aplicación (base de datos), así que si cierras
   la página, se reinicias el ordenador o se corta la luz, no pierdes nada.
   ========================================================================== */
(function () {
  "use strict";

  var URL_BASE = "/api/autoguardado";
  var indicador = null;
  var temporizadorOcultar = null;
  var ultimoAviso = 0;

  // ------------------------------------------------------------------ //
  // Indicador "Guardado automático"
  // ------------------------------------------------------------------ //
  function crearIndicador() {
    if (indicador) { return indicador; }
    indicador = document.createElement("div");
    indicador.id = "indicador-guardado";
    indicador.setAttribute("role", "status");
    indicador.setAttribute("aria-live", "polite");
    indicador.innerHTML = '<span class="punto"></span><span class="texto">Guardado automático</span>';
    document.body.appendChild(indicador);
    return indicador;
  }

  function avisar(texto, estado) {
    var ind = crearIndicador();
    ind.className = estado || "";
    var t = ind.querySelector(".texto");
    if (t) { t.textContent = texto; }
    ind.classList.add("visible");
    clearTimeout(temporizadorOcultar);
    temporizadorOcultar = setTimeout(function () {
      ind.classList.remove("visible");
    }, 2600);
  }

  function sinConexion() {
    avisar("Sin conexión: se guardará al recuperar internet", "error");
  }

  // ------------------------------------------------------------------ //
  // API
  // ------------------------------------------------------------------ //
  function guardar(clave, datos, silencioso) {
    return fetch(URL_BASE, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "same-origin",
      body: JSON.stringify({ clave: clave, datos: datos })
    }).then(function (r) {
      if (!r.ok) { throw new Error("Error " + r.status); }
      if (!silencioso) { avisar("Guardado automático ✓"); }
      return r.json();
    }).catch(function () {
      sinConexion();
    });
  }

  function cargar(clave) {
    return fetch(URL_BASE + "/" + encodeURIComponent(clave), {
      credentials: "same-origin"
    }).then(function (r) { return r.json(); })
      .catch(function () { return { ok: false, datos: null }; });
  }

  function borrar(clave) {
    return fetch(URL_BASE + "/" + encodeURIComponent(clave), {
      method: "DELETE", credentials: "same-origin"
    }).catch(function () { });
  }

  // ------------------------------------------------------------------ //
  // Lección: por dónde vas + marcar al llegar al final
  // ------------------------------------------------------------------ //
  function montarLeccion(slug) {
    var clave = "leccion:" + slug;
    var cuerpo = document.querySelector(".contenido-leccion") || document.body;
    var ultimaPos = 0;
    var ultimoEnvio = Date.now();
    var marcado = false;

    function porcentajeActual() {
      var alto = document.documentElement.scrollHeight - window.innerHeight;
      if (alto <= 0) { return 100; }
      return Math.max(0, Math.min(100, Math.round((window.scrollY / alto) * 100)));
    }

    function enviar(completada) {
      var ahora = Date.now();
      var segundos = Math.round((ahora - ultimoEnvio) / 1000);
      ultimoEnvio = ahora;
      var pct = porcentajeActual();
      fetch("/api/leccion/" + encodeURIComponent(slug) + "/autoguardado", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify({
          porcentaje: pct,
          segundos: segundos,
          completada: !!completada
        })
      }).catch(sinConexion);
      guardar(clave, { posicion: window.scrollY, porcentaje: pct, completado: !!completada }, true);
    }

    // Latido: cada 15 segundos se guarda por dónde va
    setInterval(function () { enviar(false); }, 15000);

    // Al llegar al final se da por completada
    function alDesplazar() {
      var pct = porcentajeActual();
      if (pct >= 98 && !marcado) {
        marcado = true;
        enviar(true);
        avisar("Lección guardada como completada ✓");
        var aviso = document.getElementById("aviso-autoguardado");
        if (!aviso) {
          aviso = document.createElement("div");
          aviso.id = "aviso-autoguardado";
          aviso.className = "aviso aviso-ok";
          aviso.textContent = "✅ Lección guardada. Puedes volver cuando quieras: tu progreso está a salvo.";
          cuerpo.appendChild(aviso);
          aviso.scrollIntoView({ behavior: "smooth", block: "nearest" });
        }
      }
    }
    window.addEventListener("scroll", function () {
      window.clearTimeout(alDesplazar.__t);
      alDesplazar.__t = window.setTimeout(alDesplazar, 800);
    });

    // Al salir de la página se guarda lo último
    window.addEventListener("beforeunload", function () {
      var cuerpoEnvio = JSON.stringify({
        clave: clave,
        datos: { posicion: window.scrollY, porcentaje: porcentajeActual() }
      });
      if (navigator.sendBeacon) {
        navigator.sendBeacon(URL_BASE, new Blob([cuerpoEnvio], { type: "application/json" }));
      } else {
        guardar(clave, { posicion: window.scrollY, porcentaje: porcentajeActual() }, true);
      }
    });

    // Recuperar donde lo dejó
    cargar(clave).then(function (r) {
      if (r && r.datos && r.datos.posicion && !marcado) {
        ultimaPos = r.datos.posicion;
        setTimeout(function () {
          window.scrollTo({ top: ultimaPos, behavior: "auto" });
          avisar("Retomamos donde lo dejaste ✓");
        }, 600);
      }
    });

    // Aviso fijo de que todo se guarda
    var pie = document.createElement("p");
    pie.className = "meta";
    pie.style.textAlign = "center";
    pie.textContent = "💾 Guardado automático activo: puedes cerrar la página sin perder nada.";
    cuerpo.appendChild(pie);
  }

  // ------------------------------------------------------------------ //
  // Examen: respuestas marcadas
  // ------------------------------------------------------------------ //
  function montarExamen(slug, form) {
    var clave = "examen:" + slug;

    function leer() {
      var datos = {};
      var radios = form.querySelectorAll("input[type=radio]");
      for (var i = 0; i < radios.length; i++) {
        if (radios[i].checked) { datos[radios[i].name] = radios[i].value; }
      }
      return datos;
    }

    function escribir(datos) {
      if (!datos) { return; }
      Object.keys(datos).forEach(function (nombre) {
        var radio = form.querySelector('input[name="' + nombre + '"][value="' + datos[nombre] + '"]');
        if (radio) {
          radio.checked = true;
          var etiqueta = radio.closest(".opcion");
          if (etiqueta) { etiqueta.classList.add("seleccionada"); }
        }
      });
    }

    form.addEventListener("change", function () { guardar(clave, leer()); });
    setInterval(function () {
      var d = leer();
      if (Object.keys(d).length) { guardar(clave, d, true); }
    }, 15000);

    form.addEventListener("submit", function () { borrar(clave); });

    cargar(clave).then(function (r) {
      if (r && r.datos && Object.keys(r.datos).length) {
        escribir(r.datos);
        avisar("Recuperamos tus respuestas ✓");
      }
    });
  }

  // ------------------------------------------------------------------ //
  // Ejercicio: lo que escribes o seleccionas
  // ------------------------------------------------------------------ //
  function montarEjercicio(slug) {
    var clave = "ejercicio:" + slug;

    document.addEventListener("ofimatica:respuestas", function (ev) {
      guardar(clave, ev.detail, true);
    });

    cargar(clave).then(function (r) {
      if (r && r.datos) {
        document.dispatchEvent(new CustomEvent("ofimatica:restaurar", { detail: r.datos }));
      }
    });
  }

  // ------------------------------------------------------------------ //
  // Arranque
  // ------------------------------------------------------------------ //
  document.addEventListener("DOMContentLoaded", function () {
    var cuerpo = document.body;
    var modo = cuerpo.getAttribute("data-guardado") || "";
    if (modo === "leccion") {
      montarLeccion(cuerpo.getAttribute("data-leccion") || "");
    } else if (modo === "examen") {
      var form = document.querySelector("form[data-examen]");
      montarExamen(cuerpo.getAttribute("data-examen") || "", form || document.querySelector("form"));
    } else if (modo === "ejercicio") {
      montarEjercicio(cuerpo.getAttribute("data-ejercicio-slug") || "");
    }
  });

  window.Guardado = { guardar: guardar, cargar: cargar, borrar: borrar, avisar: avisar };
})();
