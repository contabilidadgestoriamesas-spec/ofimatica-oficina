/* ==========================================================================
   La ayudante de ofimática (estilo Clippy) con IA integrada
   ========================================================================== */
(function () {
  "use strict";

  var PERSONAJES = {
    chispita: {
      nombre: "Chispita",
      rol: "Tu compañera virtual",
      color: "#f4b942",
      oscuro: "#c98a12",
      saludo: "¡Hola! Soy Chispita 👋 Dime en qué te has quedado atascada y te lo explico paso a paso.",
      sugerencias: ["¿Cómo hago un pantallazo?", "No encuentro un archivo", "¿Qué es la tecla Windows?"],
      svg: '<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Chispita">' +
        '<ellipse cx="50" cy="52" rx="26" ry="30" fill="#f4b942" stroke="#c98a12" stroke-width="3"/>' +
        '<path d="M36 70 L60 30" stroke="#c98a12" stroke-width="7" stroke-linecap="round" fill="none"/>' +
        '<path d="M36 70 L36 34" stroke="#c98a12" stroke-width="7" stroke-linecap="round" fill="none"/>' +
        '<circle cx="42" cy="46" r="5" fill="#3b2c05"/><circle cx="60" cy="46" r="5" fill="#3b2c05"/>' +
        '<circle cx="43.5" cy="44.5" r="1.8" fill="#fff"/><circle cx="61.5" cy="44.5" r="1.8" fill="#fff"/>' +
        '<path d="M42 60 Q51 68 60 60" stroke="#3b2c05" stroke-width="3" fill="none" stroke-linecap="round"/>' +
        '<ellipse cx="33" cy="56" rx="4" ry="2.6" fill="#e8734a" opacity=".75"/>' +
        '<ellipse cx="69" cy="56" rx="4" ry="2.6" fill="#e8734a" opacity=".75"/>' +
        '</svg>'
    },
    donatajo: {
      nombre: "Don Atajo",
      rol: "Especialista en atajos",
      color: "#4a90d9",
      oscuro: "#2c6cb0",
      saludo: "¡Hola! Soy Don Atajo ⌨️ Todo lo que se pueda con el teclado, te lo doy con su combinación exacta.",
      sugerencias: ["¿Qué atajo abro el Explorador?", "Atajo para guardar", "Cómo cambio de ventana"],
      svg: '<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Don Atajo">' +
        '<rect x="10" y="24" width="80" height="54" rx="10" fill="#4a90d9" stroke="#2c6cb0" stroke-width="3"/>' +
        '<rect x="20" y="34" width="60" height="14" rx="5" fill="#eaf3fc"/>' +
        '<rect x="20" y="54" width="14" height="14" rx="4" fill="#eaf3fc"/>' +
        '<rect x="38" y="54" width="14" height="14" rx="4" fill="#eaf3fc"/>' +
        '<rect x="56" y="54" width="14" height="14" rx="4" fill="#eaf3fc"/>' +
        '<rect x="74" y="54" width="6" height="14" rx="3" fill="#eaf3fc"/>' +
        '<circle cx="34" cy="45" r="3.6" fill="#1b3c60"/><circle cx="50" cy="45" r="3.6" fill="#1b3c60"/>' +
        '<circle cx="66" cy="45" r="3.6" fill="#1b3c60"/>' +
        '<circle cx="35.2" cy="43.8" r="1.3" fill="#fff"/><circle cx="51.2" cy="43.8" r="1.3" fill="#fff"/>' +
        '<circle cx="67.2" cy="43.8" r="1.3" fill="#fff"/>' +
        '<path d="M40 52 Q50 58 60 52" stroke="#1b3c60" stroke-width="2.4" fill="none" stroke-linecap="round"/>' +
        '</svg>'
    },
    nubia: {
      nombre: "Nubia",
      rol: "Especialista en archivos y nube",
      color: "#38b6a0",
      oscuro: "#22897a",
      saludo: "¡Hola! Soy Nubia ☁️ Todo lo que guardas, se guarda bien: archivos, carpetas y copias de seguridad.",
      sugerencias: ["No encuentro un archivo", "¿Dónde guardo mis documentos?", "¿Cómo comparto un archivo?"],
      svg: '<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Nubia">' +
        '<path d="M30 70 A18 18 0 0 1 30 34 A24 24 0 0 1 74 40 A16 16 0 0 1 72 70 Z" ' +
        'fill="#38b6a0" stroke="#22897a" stroke-width="3"/>' +
        '<circle cx="40" cy="50" r="4.4" fill="#0d3b34"/><circle cx="60" cy="50" r="4.4" fill="#0d3b34"/>' +
        '<circle cx="41.4" cy="48.6" r="1.6" fill="#fff"/><circle cx="61.4" cy="48.6" r="1.6" fill="#fff"/>' +
        '<path d="M42 60 Q50 66 58 60" stroke="#0d3b34" stroke-width="2.8" fill="none" stroke-linecap="round"/>' +
        '<ellipse cx="30" cy="58" rx="4" ry="2.6" fill="#e8734a" opacity=".55"/>' +
        '<ellipse cx="70" cy="58" rx="4" ry="2.6" fill="#e8734a" opacity=".55"/>' +
        '</svg>'
    },
    sumia: {
      nombre: "Sumia",
      rol: "Especialista en Excel",
      color: "#7c5cd6",
      oscuro: "#543ba0",
      saludo: "¡Hola! Soy Sumia 📊 Si es una fórmula, una tabla o un gráfico, lo resolvemos juntas.",
      sugerencias: ["¿Cómo sumo una columna?", "¿Qué hago con los filtros?", "Cómo creo un gráfico"],
      svg: '<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Sumia">' +
        '<rect x="14" y="18" width="72" height="66" rx="9" fill="#7c5cd6" stroke="#543ba0" stroke-width="3"/>' +
        '<rect x="22" y="26" width="56" height="13" rx="4" fill="#efeaff"/>' +
        '<rect x="22" y="43" width="17" height="13" rx="4" fill="#efeaff"/>' +
        '<rect x="43" y="43" width="17" height="13" rx="4" fill="#efeaff"/>' +
        '<rect x="64" y="43" width="14" height="13" rx="4" fill="#efeaff"/>' +
        '<rect x="22" y="60" width="17" height="13" rx="4" fill="#efeaff"/>' +
        '<rect x="43" y="60" width="17" height="13" rx="4" fill="#efeaff"/>' +
        '<text x="71" y="72" font-family="Georgia,serif" font-size="18" font-weight="bold" fill="#3f2a80">Σ</text>' +
        '<circle cx="34" cy="48" r="3.4" fill="#2c1a52"/><circle cx="51" cy="48" r="3.4" fill="#2c1a52"/>' +
        '<circle cx="35.2" cy="46.8" r="1.2" fill="#fff"/><circle cx="52.2" cy="46.8" r="1.2" fill="#fff"/>' +
        '<path d="M36 54 Q43 59 50 54" stroke="#2c1a52" stroke-width="2.2" fill="none" stroke-linecap="round"/>' +
        '</svg>'
    }
  };

  function el(id) { return document.getElementById(id); }

  var boton = el("boton-ayudante");
  if (!boton) { return; }  // usuario no identificado

  var panel = el("panel-ayudante");
  var burbuja = el("burbuja-ayudante");
  var cuerpoBurbuja = el("burbuja-cuerpo");
  var mensajes = el("panel-mensajes");
  var entrada = el("entrada-chat");
  var form = el("form-chat");
  var sugerenciasBox = el("panel-sugerencias");
  var nombreAyudante = el("nombre-ayudante");
  var rolAyudante = el("rol-ayudante");
  var avatarMini = el("avatar-mini");
  var avatarGrande = el("avatar-ayudante");
  var estadoIa = el("estado-ia");

  var idPersonaje = document.body.getAttribute("data-personaje") || "chispita";
  var per = PERSONAJES[idPersonaje] || PERSONAJES.chispita;

  // Pintar avatares
  if (avatarGrande) avatarGrande.innerHTML = per.svg;
  if (avatarMini) avatarMini.innerHTML = per.svg;
  if (nombreAyudante) nombreAyudante.textContent = per.nombre;
  if (rolAyudante) rolAyudante.textContent = per.rol;

  // ---------------- Burbuja de consejos (estilo tips de Clippy) ----------------
  var CONSEJOS = [
    "Pulsa <strong>Ctrl + S</strong> cada pocos minutos: es el hábito que más tiempo te ahorra.",
    "¿Sabías que <strong>Windows + Shift + S</strong> hace una captura de la zona que elijas?",
    "Con <strong>Windows + E</strong> abres el Explorador de archivos sin tocar el ratón.",
    "En Word, <strong>Ctrl + H</strong> cambia un nombre repetido en dos segundos.",
    "<strong>Windows + L</strong> bloquea el ordenador: hazlo al levantarte de la mesa.",
    "En Excel, <strong>Alt + =</strong> suma la columna de al lado automáticamente.",
    "Si algo no te sale, haz un <strong>pantallazo</strong> antes de pedir ayuda: explica mejor.",
    "El <strong>doble clic</strong> abre un archivo; un solo clic solo lo selecciona.",
    "<strong>Windows + flecha izquierda</strong> y <strong>flecha derecha</strong> ponen dos ventanas en paralelo.",
    "En Outlook, <strong>Ctrl + Mayús + R</strong> responde a todos. Úsalo con cuidado.",
    "Puedes preguntarme lo que sea: «¿cómo imprimo a dos caras?» o «¿qué hago si no me entra el wifi?»",
    "Estoy aquí para explicarte paso a paso. No hay pregunta tonta."
  ];
  var indiceConsejo = Math.floor(Math.random() * CONSEJOS.length);
  var temporizadorBurbuja = null;

  function mostrarBurbuja(html, duracion) {
    if (!burbuja || !cuerpoBurbuja) return;
    cuerpoBurbuja.innerHTML = html;
    burbuja.hidden = false;
    if (temporizadorBurbuja) clearTimeout(temporizadorBurbuja);
    if (duracion !== 0) {
      temporizadorBurbuja = setTimeout(function () { burbuja.hidden = true; }, duracion || 14000);
    }
  }

  function rotarConsejo() {
    indiceConsejo = (indiceConsejo + 1) % CONSEJOS.length;
    mostrarBurbuja("<p><strong>💡 Consejo de " + per.nombre + "</strong></p><p>" + CONSEJOS[indiceConsejo] + "</p>");
  }

  // Primera burbuja de bienvenida + consejos periódicos
  setTimeout(function () {
    mostrarBurbuja("<p>" + per.saludo + "</p>");
  }, 4000);
  setInterval(function () {
    if (!panel || panel.hidden) { rotarConsejo(); }
  }, 75000);

  var cerrarBurbuja = el("cerrar-burbuja");
  if (cerrarBurbuja) {
    cerrarBurbuja.addEventListener("click", function () { burbuja.hidden = true; });
  }

  // ---------------- Panel de chat ----------------
  function abrirPanel() {
    panel.hidden = false;
    burbuja.hidden = true;
    if (!mensajes.dataset.saludo) {
      anadirMensaje("ayudante", "<p>" + per.saludo + "</p>");
      mensajes.dataset.saludo = "1";
      pintarSugerencias(per.sugerencias);
      pedirConsejoIA();
    }
    entrada.focus();
  }

  function cerrarPanel() { panel.hidden = true; }

  boton.addEventListener("click", function () {
    if (panel.hidden) { abrirPanel(); } else { cerrarPanel(); }
  });
  var cerrar = el("cerrar-panel");
  if (cerrar) cerrar.addEventListener("click", cerrarPanel);

  var irAlChat = el("ir-al-chat");
  if (irAlChat) {
    irAlChat.addEventListener("click", function (ev) {
      ev.preventDefault();
      abrirPanel();
      entrada.focus();
    });
  }

  function pintarSugerencias(lista) {
    if (!sugerenciasBox) return;
    sugerenciasBox.innerHTML = "";
    (lista || []).forEach(function (s) {
      var b = document.createElement("button");
      b.type = "button";
      b.textContent = s;
      b.addEventListener("click", function () { entrada.value = s; form.dispatchEvent(new Event("submit", { cancelable: true })); });
      sugerenciasBox.appendChild(b);
    });
  }

  function anadirMensaje(quien, html, extra) {
    var div = document.createElement("div");
    div.className = "msg " + quien;
    var txt = document.createElement("div");
    txt.className = "texto";
    txt.innerHTML = html;
    div.appendChild(txt);
    if (extra) {
      var f = document.createElement("div");
      f.className = "fuente";
      f.innerHTML = extra;
      div.appendChild(f);
    }
    if (quien === "ayudante") {
      var firma = document.createElement("div");
      firma.className = "firma";
      firma.textContent = per.nombre + " · ahora";
      div.appendChild(firma);
    }
    mensajes.appendChild(div);
    mensajes.scrollTop = mensajes.scrollHeight;
  }

  function pedirConsejoIA() {
    fetch("/api/consejo").then(function (r) { return r.json(); }).then(function (d) {
      if (estadoIa) estadoIa.textContent = "";
    }).catch(function () { });
  }

  form.addEventListener("submit", function (ev) {
    ev.preventDefault();
    var texto = (entrada.value || "").trim();
    if (!texto) return;
    anadirMensaje("alumna", "<p>" + escapar(texto) + "</p>");
    entrada.value = "";
    var esperando = document.createElement("div");
    esperando.className = "msg ayudante";
    esperando.innerHTML = '<div class="texto"><p>Escribiendo…</p></div>';
    mensajes.appendChild(esperando);
    mensajes.scrollTop = mensajes.scrollHeight;

    fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        mensaje: texto,
        personaje: idPersonaje,
        contexto: contextoPagina()
      })
    })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        esperando.remove();
        var extra = "";
        if (d.articulos && d.articulos.length) {
          extra = "<strong>En el manual:</strong> " + d.articulos.map(function (a) {
            return '<a href="/manual/' + a.slug + '">' + escapar(a.titulo) + "</a>";
          }).join(" · ");
        }
        anadirMensaje("ayudante", d.texto || "<p>Pensándolo…</p>", extra);
        if (d.atajos && d.atajos.length) {
          var atajos = "<p style='margin-top:.4rem'><strong>Atajos:</strong> " +
            d.atajos.map(function (a) { return "<kbd>" + escapar(a) + "</kbd>"; }).join(" ") + "</p>";
          var ult = mensajes.lastChild;
          var t = ult.querySelector(".texto");
          t.insertAdjacentHTML("beforeend", atajos);
        }
        if (d.sugerencias && d.sugerencias.length) { pintarSugerencias(d.sugerencias); }
      })
      .catch(function () {
        esperando.remove();
        anadirMensaje("ayudante", "<p>No he podido conectarme en este momento. ¿Puedes intentarlo otra vez?</p>");
      });
  });

  function escapar(s) {
    return (s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }

  function contextoPagina() {
    var ctx = {};
    var mod = document.querySelector("[data-modulo]");
    if (mod) ctx.modulo = mod.getAttribute("data-modulo");
    var lec = document.querySelector("[data-leccion]");
    if (lec) ctx.leccion = lec.getAttribute("data-leccion");
    return ctx;
  }

  // Menú hamburguesa
  var botonMenu = el("boton-menu");
  var menu = el("menu-principal");
  if (botonMenu && menu) {
    botonMenu.addEventListener("click", function () { menu.classList.toggle("abierto"); });
  }

  // Tamaño de texto (preferencia guardada)
  try {
    var tam = localStorage.getItem("tamanoTexto");
    if (tam === "grande") document.body.classList.add("texto-grande");
    if (tam === "maximo") document.body.classList.add("texto-maximo");
  } catch (e) { }

  // Service worker: permite instalar la aplicación en Windows 11 (funciona
  // solo en localhost o con https; si falla, no pasa nada).
  if ("serviceWorker" in navigator &&
      (location.protocol === "https:" || location.hostname === "localhost" ||
       location.hostname === "127.0.0.1")) {
    navigator.serviceWorker.register("/sw.js").catch(function () { });
  }
})();
