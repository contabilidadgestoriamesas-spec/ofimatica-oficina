"""Autenticación, roles y gestión de usuarios."""
import datetime
import functools

from flask import Blueprint, flash, g, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

from . import db
from .config import ADMIN_EMAIL, ADMIN_INICIAL, ADMIN_PASSWORD_INICIAL

bp = Blueprint("auth", __name__)

MAX_FALLIDOS = 5
BLOQUEO_MINUTOS = 10


# --------------------------------------------------------------------------- #
# Utilidades
# --------------------------------------------------------------------------- #
def hash_password(raw):
    return generate_password_hash(raw, method="pbkdf2:sha256:600000")


def check_password(pw_hash, raw):
    try:
        return check_password_hash(pw_hash, raw)
    except Exception:
        return False


def validar_password(password):
    """Devuelve (ok, mensaje). Reglas sencillas y explicitas para principiantes."""
    if len(password or "") < 6:
        return False, "La contraseña debe tener al menos 6 caracteres."
    if not any(c.isalpha() for c in password):
        return False, "La contraseña debe incluir al menos una letra."
    if not any(c.isdigit() for c in password):
        return False, "La contraseña debe incluir al menos un número."
    return True, ""


def usuario_actual():
    if "user_id" not in session:
        return None
    uid = session["user_id"]
    user = db.q1("SELECT * FROM users WHERE id = ?", (uid,))
    if not user or not user["activo"]:
        session.pop("user_id", None)
        return None
    return user


def login_requerido(f):
    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        if usuario_actual() is None:
            return redirect(url_for("auth.login", next=request.path))
        return f(*args, **kwargs)

    return wrapper


def admin_requerido(f):
    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        u = usuario_actual()
        if u is None:
            return redirect(url_for("auth.login", next=request.path))
        if u["role"] != "admin":
            flash("Esta zona es solo para el administrador del curso.", "error")
            return redirect(url_for("curso.dashboard"))
        return f(*args, **kwargs)

    return wrapper


def cargar_usuario():
    g.usuario = usuario_actual()
    if g.usuario is not None:
        mods = g.usuario["modulos"] or "todos"
        g.modulos_permitidos = None if mods == "todos" else [
            m.strip() for m in mods.split(",") if m.strip()
        ]


def subir_puntos(user_id, puntos, motivo=""):
    row = db.q1("SELECT * FROM user_stats WHERE user_id = ?", (user_id,))
    hoy = db.hoy()
    if row:
        puntos_tot = row["puntos"] + puntos
        racha = row["racha"]
        if row["ultimo_dia"] != hoy:
            ayer = (datetime.date.today() - datetime.timedelta(days=1)).isoformat()
            racha = row["racha"] + 1 if row["ultimo_dia"] == ayer else 1
        db.execute(
            "UPDATE user_stats SET puntos = ?, racha = ?, ultimo_dia = ? WHERE user_id = ?",
            (puntos_tot, racha, hoy, user_id),
        )
    else:
        db.execute(
            "INSERT INTO user_stats(user_id, puntos, racha, ultimo_dia) VALUES(?,?,?,?)",
            (user_id, puntos, 1, hoy),
        )
    db.log(user_id, "", "puntos", f"+{puntos} {motivo}".strip())


def insignias_del_usuario(user_id):
    """Calcula insignias de achievements en función de progreso."""
    from . import db as dbm

    row = dbm.q1(
        """SELECT COUNT(*) AS n FROM progress p JOIN users u ON u.id = p.user_id
           WHERE p.user_id = ? AND p.completado = 1""",
        (user_id,),
    )
    lecciones = row["n"] if row else 0
    st = dbm.q1("SELECT * FROM user_stats WHERE user_id = ?", (user_id,))
    puntos = st["puntos"] if st else 0
    racha = st["racha"] if st else 0
    exams = dbm.q1(
        "SELECT COUNT(DISTINCT exam_id) AS n FROM exam_attempts WHERE user_id = ? AND aprobado = 1",
        (user_id,),
    )
    aprobados = exams["n"] if exams else 0

    lista = []
    if lecciones >= 1:
        lista.append(("primera", "Primer paso", "Completaste tu primera lección 🎉"))
    if lecciones >= 5:
        lista.append(("exploradora", "Exploradora", "5 lecciones completadas"))
    if lecciones >= 15:
        lista.append(("constante", "Constancia", "15 lecciones completadas"))
    if lecciones >= 30:
        lista.append(("maestra", "Maestra ofimática", "30 lecciones completadas"))
    if puntos >= 300:
        lista.append(("puntos300", "300 puntos", "Has alcanzado 300 puntos de práctica"))
    if racha >= 3:
        lista.append(("racha3", "Racha de 3 días", "Tres días seguidos practicando"))
    if racha >= 7:
        lista.append(("racha7", "Racha de 7 días", "Una semana entera practicando"))
    if aprobados >= 1:
        lista.append(("examen1", "Primer examen superado", "Aprobaste tu primer examen"))
    if aprobados >= 5:
        lista.append(("examen5", "5 exámenes", "Has aprobado 5 exámenes"))
    return lista


def normalizar_insignias(user_id, insignias):
    import json

    prev = db.q1("SELECT insignias FROM user_stats WHERE user_id = ?", (user_id,))
    actual = json.loads(prev["insignias"]) if prev and prev["insignias"] else []
    nuevas = [i for i in insignias if i[0] not in [a[0] for a in actual]]
    if nuevas:
        actual = actual + nuevas
        if prev:
            db.execute("UPDATE user_stats SET insignias = ? WHERE user_id = ?", (json.dumps(actual), user_id))
        else:
            db.execute(
                "INSERT INTO user_stats(user_id, puntos, insignias) VALUES(?,?,?)",
                (user_id, 0, json.dumps(actual)),
            )
    return nuevas


# --------------------------------------------------------------------------- #
# Rutas
# --------------------------------------------------------------------------- #
@bp.route("/login", methods=["GET", "POST"])
def login():
    if usuario_actual():
        return redirect(url_for("curso.dashboard"))
    error = None
    username = ""
    if request.method == "POST":
        username = (request.form.get("username") or "").strip().lower()
        password = request.form.get("password") or ""
        user = db.q1("SELECT * FROM users WHERE lower(username) = ?", (username,))
        if not user:
            error = "No existe ninguna cuenta con ese nombre de usuario."
        elif not user["activo"]:
            error = "Esta cuenta está desactivada. Avisa a tu responsible de formación."
        elif user["bloqueado_hasta"] and user["bloqueado_hasta"] > db.ahora():
            error = "Demasiados intentos fallidos. Espera unos minutos e inténtalo de nuevo."
        elif check_password(user["password_hash"], password):
            db.execute(
                "UPDATE users SET intentos_fallidos = 0, bloqueado_hasta = '', last_login = ? WHERE id = ?",
                (db.ahora(), user["id"]),
            )
            session.clear()
            session["user_id"] = user["id"]
            db.log(user["id"], user["username"], "login", "Inicio de sesión")
            nxt = request.args.get("next")
            if user["role"] == "admin" and not nxt:
                return redirect(url_for("admin.panel"))
            return redirect(nxt or url_for("curso.dashboard"))
        else:
            fallidos = (user["intentos_fallidos"] or 0) + 1
            bloqueo = ""
            if fallidos >= MAX_FALLIDOS:
                bloqueo = (datetime.datetime.now() + datetime.timedelta(minutes=BLOQUEO_MINUTOS)).isoformat(
                    timespec="seconds"
                )
                fallidos = 0
            db.execute(
                "UPDATE users SET intentos_fallidos = ?, bloqueado_hasta = ? WHERE id = ?",
                (fallidos, bloqueo, user["id"]),
            )
            error = "Contraseña incorrecta. Fíjate si las mayúsculas están activadas."
    return render_template("login.html", error=error, username=username)


@bp.route("/salir")
def logout():
    u = usuario_actual()
    if u:
        db.log(u["id"], u["username"], "logout", "Cierre de sesión")
    session.clear()
    flash("Has cerrado sesión. ¡Hasta luego!", "ok")
    return redirect(url_for("auth.login"))


@bp.route("/mi-cuenta/cambiar-password", methods=["POST"])
@login_requerido
def cambiar_password():
    u = usuario_actual()
    actual = request.form.get("actual") or ""
    nueva = request.form.get("nueva") or ""
    repetir = request.form.get("repetir") or ""
    if not check_password(u["password_hash"], actual):
        flash("La contraseña actual no es correcta.", "error")
    elif nueva != repetir:
        flash("La contraseña nueva y su repetición no coinciden.", "error")
    else:
        ok, msg = validar_password(nueva)
        if not ok:
            flash(msg, "error")
        else:
            db.execute(
                "UPDATE users SET password_hash = ?, debe_cambiar = 0 WHERE id = ?",
                (hash_password(nueva), u["id"]),
            )
            db.log(u["id"], u["username"], "password", "Contraseña modificada")
            flash("¡Contraseña actualizada correctamente!", "ok")
    return redirect(url_for("curso.configuracion"))


def crear_admin_inicial():
    existe = db.q1("SELECT id FROM users WHERE role = 'admin'")
    if existe:
        return
    db.execute(
        """INSERT INTO users(username, nombre, email, password_hash, role, activo, modulos)
           VALUES(?,?,?,?,?,?,?)""",
        (
            ADMIN_INICIAL,
            "Administrador",
            ADMIN_EMAIL,
            hash_password(ADMIN_PASSWORD_INICIAL),
            "admin",
            1,
            "todos",
        ),
    )
    db.log(None, ADMIN_INICIAL, "setup", "Creación del administrador inicial")
