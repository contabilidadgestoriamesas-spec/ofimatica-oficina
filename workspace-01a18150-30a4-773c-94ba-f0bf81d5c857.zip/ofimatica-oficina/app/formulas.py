"""Mini evaluador de fórmulas de Excel para los ejercicios prácticos."""
import re

FUNCIONES = {
    "SUMA": "SUM", "SUM": "SUM",
    "PROMEDIO": "AVERAGE", "AVERAGE": "AVERAGE",
    "MAX": "MAX", "MIN": "MIN",
    "CONTAR": "COUNT", "COUNT": "COUNT",
    "CONTARA": "COUNTA", "COUNTA": "COUNTA",
    "REDONDEAR": "ROUND", "ROUND": "ROUND",
}

PATRON_RANGO = re.compile(r"([A-Z]{1,2})(\d+)\s*:\s*([A-Z]{1,2})(\d+)")


def _columna_a_numero(col):
    num = 0
    for ch in col:
        num = num * 26 + (ord(ch) - 64)
    return num


def _numero_a_columna(num):
    col = ""
    while num > 0:
        num, resto = divmod(num - 1, 26)
        col = chr(65 + resto) + col
    return col


def _celdas_rango(hoja, c1, f1, c2, f2):
    valores = []
    col1, col2 = _columna_a_numero(c1), _columna_a_numero(c2)
    f1, f2 = int(f1), int(f2)
    for col in range(min(col1, col2), max(col1, col2) + 1):
        for fila in range(min(f1, f2), max(f1, f2) + 1):
            ref = "%s%d" % (_numero_a_columna(col), fila)
            valores.append(hoja.get(ref, ""))
    return valores


def _numeros(valores):
    salida = []
    for v in valores:
        try:
            salida.append(float(str(v).replace(",", ".")))
        except (TypeError, ValueError):
            continue
    return salida


def evaluar_formula(formula, hoja):
    """Devuelve (ok, valor_float, mensaje_error)."""
    if not formula:
        return False, None, "No has escrito nada."
    f = formula.strip()
    if not f.startswith("="):
        return False, None, "Una fórmula tiene que empezar por el signo igual (=)."
    cuerpo = f[1:].strip()
    if not cuerpo:
        return False, None, "La fórmula está vacía."

    # Rango único
    m = PATRON_RANGO.fullmatch(cuerpo)
    if m:
        valores = _celdas_rango(hoja, m.group(1), m.group(2), m.group(3), m.group(4))
        return False, None, "La función necesita paréntesis: =%s(%s:%s)" % (
            "SUMA", m.group(1) + m.group(2), m.group(3) + m.group(4))

    # Función con argumentos
    m = re.match(r"^([A-Za-zÁÉÍÓÚáéíóú]+)\s*\((.*)\)$", cuerpo)
    if m:
        nombre = m.group(1).upper()
        clave = FUNCIONES.get(nombre)
        if not clave:
            return False, None, "No conozco la función %s. Las más usadas: SUMA, PROMEDIO, MAX, MIN, CONTAR." % nombre
        argumentos = [a.strip() for a in m.group(2).split(";")] if ";" in m.group(2) \
            else [a.strip() for a in m.group(2).split(",")]
        numeros = []
        for arg in argumentos:
            rm = PATRON_RANGO.fullmatch(arg)
            if rm:
                numeros.extend(_numeros(_celdas_rango(hoja, rm.group(1), rm.group(2),
                                                      rm.group(3), rm.group(4))))
            else:
                cm = re.match(r"^([A-Z]{1,2})(\d+)$", arg.upper())
                if cm:
                    numeros.extend(_numeros([hoja.get(arg.upper(), "")]))
                else:
                    try:
                        numeros.append(float(arg.replace(",", ".")))
                    except ValueError:
                        pass
        if clave == "SUM":
            return True, sum(numeros), ""
        if clave == "AVERAGE":
            if not numeros:
                return False, None, "No hay números en el rango."
            return True, sum(numeros) / len(numeros), ""
        if clave == "MAX":
            return (True, max(numeros), "") if numeros else (False, None, "El rango está vacío.")
        if clave == "MIN":
            return (True, min(numeros), "") if numeros else (False, None, "El rango está vacío.")
        if clave == "COUNT":
            return True, float(len(numeros)), ""
        if clave == "COUNTA":
            total = 0
            for arg in argumentos:
                rm = PATRON_RANGO.fullmatch(arg)
                if rm:
                    total += len([v for v in _celdas_rango(hoja, rm.group(1), rm.group(2),
                                                          rm.group(3), rm.group(4)) if str(v).strip() != ""])
                elif arg:
                    total += 1
            return True, float(total), ""
        if clave == "ROUND":
            return True, round(numeros[0], int(numeros[1]) if len(numeros) > 1 else 0), ""
        return False, None, "Función no soportada en la práctica."

    # Referencia o número simple
    cm = re.match(r"^([A-Z]{1,2})(\d+)$", cuerpo.upper())
    if cm:
        valor = hoja.get(cuerpo.upper(), "")
        try:
            return True, float(str(valor).replace(",", ".")), ""
        except (TypeError, ValueError):
            return False, None, "Esa celda no contiene un número."
    try:
        return True, float(cuerpo.replace(",", ".")), ""
    except ValueError:
        return False, None, "No entiendo esa fórmula. Ejemplo: =SUMA(B2:B7)"
