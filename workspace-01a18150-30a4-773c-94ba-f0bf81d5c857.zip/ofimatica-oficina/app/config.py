"""Configuración central de la aplicación de ofimática."""
import os
import secrets

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
os.makedirs(DATA_DIR, exist_ok=True)

DB_PATH = os.environ.get("OFIMATICA_DB", os.path.join(DATA_DIR, "ofimatica.db"))
SECRET_FILE = os.path.join(DATA_DIR, "secret.key")

def _secret():
    if os.environ.get("OFIMATICA_SECRET"):
        return os.environ["OFIMATICA_SECRET"]
    if os.path.exists(SECRET_FILE):
        with open(SECRET_FILE, "r", encoding="utf-8") as fh:
            val = fh.read().strip()
            if val:
                return val
    val = secrets.token_hex(32)
    with open(SECRET_FILE, "w", encoding="utf-8") as fh:
        fh.write(val)
    try:
        os.chmod(SECRET_FILE, 0o600)
    except OSError:
        pass
    return val

SECRET_KEY = _secret()

# Red
HOST = os.environ.get("OFIMATICA_HOST", "0.0.0.0")
PORT = int(os.environ.get("OFIMATICA_PORT", "8080"))

# Nombre visible de la aplicación
APP_NAME = "Oficina de Ofimática"
APP_TAGLINE = "Aprende a manejarte con el ordenador, paso a paso"

# Ajustes pedagógicos por defecto
PUNTOS_POR_LECCION = 20
PUNTOS_POR_EJERCICIO = 15
PUNTOS_POR_EXAMEN = 100

# Nombre y correo del administrador inicial (creado en el primer arranque)
ADMIN_INICIAL = os.environ.get("OFIMATICA_ADMIN", "admin")
ADMIN_PASSWORD_INICIAL = os.environ.get("OFIMATICA_ADMIN_PASSWORD", "admin")
ADMIN_EMAIL = os.environ.get("OFIMATICA_ADMIN_EMAIL", "admin@ofimatica.local")

# Agente de IA (compatible con API OpenAI: Ollama, LM Studio, llama.cpp, vLLM, OpenAI...)
IA_POR_DEFECTO = {
    "activada": "0",
    "base_url": "http://localhost:11434/v1",
    "modelo": "llama3.1:8b",
    "api_key": "",
    "temperatura": "0.4",
    "max_tokens": "700",
    "prompt_sistema": (
        "Eres 'la ayudante de ofimática' de una empresa. Ayudas a oficeras de unos 50 años "
        "que están aprendiendo Windows 11 y Microsoft Office desde cero. Responde SIEMPRE en español "
        "de España, con tono amable, cercano y paciente. Usa frases cortas y pasos numerados. "
        "No des respuestas técnicas esotericas: explica cada clic y cada tecla. Si no sabes algo, "
        "di que lo compruebes en el manual. Máximo 250 palabras por respuesta."
    ),
}
