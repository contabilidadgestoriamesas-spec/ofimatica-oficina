"""Fábrica de la aplicación Flask."""
import json
import os

from flask import Flask, g, render_template, session

from .config import APP_NAME, APP_TAGLINE
from . import db


def create_app():
    app = Flask(__name__)
    app.config.from_object("app.config")
    app.secret_key = app.config["SECRET_KEY"]
    app.jinja_env.globals["app_name"] = APP_NAME
    app.jinja_env.globals["app_tagline"] = APP_TAGLINE

    from .auth import bp as auth_bp
    from .views import bp as main_bp
    from .api import bp as api_bp
    from .admin_views import bp as admin_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(api_bp)
    app.register_blueprint(admin_bp)

    @app.before_request
    def _cargar_usuario():
        from .auth import cargar_usuario as _cu

        _cu()

    @app.context_processor
    def _globales():
        from .assistant import PERSONAJES, PERSONAJES_POR_DEFECTO

        usuario = getattr(g, "usuario", None)
        personaje = (usuario["assistant"] if usuario and usuario["assistant"] in PERSONAJES
                     else PERSONAJES_POR_DEFECTO)
        return {
            "usuario": usuario,
            "personaje": personaje,
            "personajes": PERSONAJES,
            "es_admin": bool(usuario and usuario["role"] == "admin"),
        }

    @app.teardown_appcontext
    def _cerrar(_exc=None):
        pass

    @app.errorhandler(404)
    def _404(e):
        return render_template("error.html", codigo=404, mensaje="Esta página no existe."), 404

    @app.errorhandler(500)
    def _500(e):
        return render_template("error.html", codigo=500, mensaje="Ha ocurrido un error inesperado."), 500

    return app
