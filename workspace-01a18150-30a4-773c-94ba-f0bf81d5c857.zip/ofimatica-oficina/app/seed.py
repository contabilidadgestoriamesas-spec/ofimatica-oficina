"""Carga inicial del contenido: módulos, lecciones, ejercicios, manual y exámenes."""
import hashlib
import json
import random

from . import db
from .content.curso import MODULOS
from .content.ejercicios import EJERCICIOS
from .content.manual import MANUAL


def _slug_modulo(titulo):
    return titulo


def _barajar_opciones(pregunta):
    """Baraja las opciones de forma determinista (la correcta no siempre es la A).

    La semilla depende del texto de la pregunta, así que el orden es estable
    entre reinicios y no cambia lo que ya han visto las alumnas.
    """
    opciones = list(pregunta.get("opciones") or [])
    if len(opciones) < 2:
        return pregunta
    semilla = int(hashlib.sha1(pregunta.get("pregunta", "").encode("utf-8")).hexdigest()[:8], 16)
    rnd = random.Random(semilla)
    indices = list(range(len(opciones)))
    rnd.shuffle(indices)
    nueva_correcta = indices.index(pregunta["correcta"]) if pregunta["correcta"] in indices else pregunta["correcta"]
    pregunta = dict(pregunta)
    pregunta["opciones"] = [opciones[i] for i in indices]
    pregunta["correcta"] = nueva_correcta
    return pregunta


def seed_modulos():
    for orden, mod in enumerate(MODULOS, start=1):
        db.execute(
            """INSERT INTO modules(slug, titulo, nivel, orden, descripcion, icono, duracion)
               VALUES(?,?,?,?,?,?,?)
               ON CONFLICT(slug) DO UPDATE SET
                 titulo=excluded.titulo, nivel=excluded.nivel, orden=excluded.orden,
                 descripcion=excluded.descripcion, icono=excluded.icono, duracion=excluded.duracion""",
            (mod["slug"], mod["titulo"], mod["nivel"], orden, mod["descripcion"],
             mod.get("icono", "📘"), mod.get("duracion", 30)),
        )
        mod_id = db.q1("SELECT id FROM modules WHERE slug = ?", (mod["slug"],))["id"]
        for orden_lec, lec in enumerate(mod["lecciones"], start=1):
            db.execute(
                """INSERT INTO lessons(slug, module_id, titulo, objetivo, duracion, contenido,
                                      atajos, trampas, practica, ruta, orden)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?)
                   ON CONFLICT(slug) DO UPDATE SET
                     module_id=excluded.module_id, titulo=excluded.titulo, objetivo=excluded.objetivo,
                     duracion=excluded.duracion, contenido=excluded.contenido, atajos=excluded.atajos,
                     trampas=excluded.trampas, practica=excluded.practica, ruta=excluded.ruta,
                     orden=excluded.orden""",
                (
                    lec["slug"], mod_id, lec["titulo"], lec.get("objetivo", ""),
                    lec.get("duracion", 10), lec.get("contenido", ""),
                    json.dumps(lec.get("atajos", []), ensure_ascii=False),
                    json.dumps(lec.get("trampas", []), ensure_ascii=False),
                    lec.get("practica", ""), lec.get("ruta", "comun"), orden_lec,
                ),
            )


def seed_ejercicios():
    for ej in EJERCICIOS:
        mod_id = None
        if ej.get("module"):
            fila = db.q1("SELECT id FROM modules WHERE slug = ?", (ej["module"],))
            mod_id = fila["id"] if fila else None
        cfg = dict(ej.get("config", {}))
        if cfg.get("preguntas"):
            cfg["preguntas"] = [_barajar_opciones(p) for p in cfg["preguntas"]]
        db.execute(
            """INSERT INTO exercises(slug, module_id, titulo, tipo, descripcion, nivel, config)
               VALUES(?,?,?,?,?,?,?)
               ON CONFLICT(slug) DO UPDATE SET
                 module_id=excluded.module_id, titulo=excluded.titulo, tipo=excluded.tipo,
                 descripcion=excluded.descripcion, nivel=excluded.nivel, config=excluded.config""",
            (
                ej["slug"], mod_id, ej["titulo"], ej["tipo"], ej.get("descripcion", ""),
                ej.get("nivel", 1), json.dumps(cfg, ensure_ascii=False),
            ),
        )


def seed_manual():
    for art in MANUAL:
        slug = _slug_para(art["titulo"])
        db.execute(
            """INSERT INTO articles(slug, titulo, categoria, tags, cuerpo, fuente)
               VALUES(?,?,?,?,?,?)
               ON CONFLICT(slug) DO UPDATE SET
                 titulo=excluded.titulo, categoria=excluded.categoria, tags=excluded.tags,
                 cuerpo=excluded.cuerpo, fuente=excluded.fuente""",
            (slug, art["titulo"], art["categoria"], art.get("tags", ""),
             art.get("cuerpo", ""), art.get("fuente", "")),
        )


def _slug_para(titulo):
    import re
    import unicodedata

    t = unicodedata.normalize("NFKD", titulo.lower())
    t = "".join(c for c in t if not unicodedata.combining(c))
    t = re.sub(r"[^a-z0-9]+", "-", t).strip("-")
    return t[:90]


def seed_examenes():
    """Crea un examen por módulo a partir de los ejercicios de opción múltiple."""
    for mod in MODULOS:
        mod_id = db.q1("SELECT id FROM modules WHERE slug = ?", (mod["slug"],))["id"]
        preguntas = []
        for ej in EJERCICIOS:
            if ej.get("module") != mod["slug"]:
                continue
            if ej["tipo"] != "opcion":
                continue
            cfg = ej.get("config", {})
            grupos = [("preguntas", "ambos")]
            if cfg.get("preguntas_outlook"):
                grupos.append(("preguntas_outlook", "outlook"))
            if cfg.get("preguntas_thunderbird"):
                grupos.append(("preguntas_thunderbird", "thunderbird"))
            for clave, programa in grupos:
                for pr in cfg.get(clave, []):
                    pr = _barajar_opciones(pr)
                    preguntas.append({
                        "pregunta": pr["pregunta"],
                        "opciones": pr["opciones"],
                        "correcta": pr["correcta"],
                        "explicacion": pr.get("explicacion", ""),
                        "programa": programa,
                    })
        # Añadimos la evaluación final al examen del último módulo
        if mod["slug"] == MODULOS[-1]["slug"]:
            for ej in EJERCICIOS:
                if ej["slug"] == "ej-evaluacion-final":
                    for pr in ej["config"].get("preguntas", []):
                        pr = _barajar_opciones(pr)
                        preguntas.append({
                            "pregunta": pr["pregunta"],
                            "opciones": pr["opciones"],
                            "correcta": pr["correcta"],
                            "explicacion": pr.get("explicacion", ""),
                        })
        if not preguntas:
            continue
        existente = db.q1("SELECT id FROM exams WHERE module_id = ?", (mod_id,))
        payload = json.dumps(preguntas, ensure_ascii=False)
        if existente:
            db.execute(
                "UPDATE exams SET titulo = ?, preguntas = ?, aprobado = 70, intentos_max = 10 WHERE id = ?",
                ("Examen de %s" % mod["titulo"], payload, existente["id"]),
            )
        else:
            db.execute(
                "INSERT INTO exams(module_id, titulo, preguntas, aprobado, intentos_max) VALUES(?,?,?,?,?)",
                (mod_id, "Examen de %s" % mod["titulo"], payload, 70, 10),
            )


def seed_todo():
    db.init_db()
    seed_modulos()
    seed_ejercicios()
    seed_manual()
    seed_examenes()
