"""API interna (JSON) para la ayudante, los ejercicios y el progreso."""
import json
import time

from flask import Blueprint, jsonify, request, session

from . import db
from .assistant import (PERSONAJES, construir_respuesta, formatear, consejo_del_dia)
from .auth import login_requerido, subir_puntos, usuario_actual
from .config import PUNTOS_POR_EJERCICIO
from .formulas import evaluar_formula
from .programa import cliente_de, preguntas_ejercicio

bp = Blueprint("api", __name__, url_prefix="/api")


# --------------------------------------------------------------------------- #
# Ayudante
# --------------------------------------------------------------------------- #
@bp.post("/chat")
@login_requerido
def chat():
    u = usuario_actual()
    data = request.get_json(silent=True) or {}
    mensaje = (data.get("mensaje") or "").strip()
    contexto = data.get("contexto") or {}
    personaje = data.get("personaje") or u["assistant"] or "chispita"
    if personaje not in PERSONAJES:
        personaje = "chispita"
    t0 = time.time()
    resultado = construir_respuesta(mensaje, u["id"], personaje, contexto)
    resultado["personaje"] = personaje
    resultado["ms"] = int((time.time() - t0) * 1000)
    return jsonify(resultado)


@bp.get("/consejo")
@login_requerido
def consejo():
    return jsonify({"texto": formatear(consejo_del_dia())})


# --------------------------------------------------------------------------- #
# Ejercicios
# --------------------------------------------------------------------------- #
def _evaluar(tipo, cfg, respuestas):
    """Devuelve (pct, detalle_texto, detalle_lista)."""
    if tipo == "opcion":
        preguntas = cfg.get("preguntas", [])
        if not preguntas:
            return 0, "No hay preguntas en este ejercicio.", []
        aciertos = 0
        detalle = []
        for idx, pr in enumerate(preguntas):
            elegida = respuestas.get(str(idx))
            elegida = int(elegida) if str(elegida).lstrip("-").isdigit() else -1
            ok = elegida == pr["correcta"]
            if ok:
                aciertos += 1
            detalle.append({
                "pregunta": pr["pregunta"], "ok": ok, "elegida": elegida,
                "correcta": pr["correcta"], "explicacion": pr.get("explicacion", ""),
                "opciones": pr["opciones"],
            })
        pct = round(100 * aciertos / len(preguntas))
        return pct, "Has acertado %d de %d preguntas." % (aciertos, len(preguntas)), detalle

    if tipo == "orden":
        pasos = cfg.get("pasos", [])
        orden = respuestas.get("orden") or []
        ok = [p.strip() for p in orden] == [p.strip() for p in pasos]
        pct = 100 if ok else 0
        detalle = [{"pregunta": "Orden de los pasos", "ok": ok, "explicacion":
                    "El orden correcto es: " + " → ".join(pasos)}]
        return pct, "¡Perfecto!" if ok else "Ese no es el orden correcto.", detalle

    if tipo == "teclas":
        seq = cfg.get("secuencia", [])
        pulsadas = respuestas.get("teclas") or []
        aciertos = sum(1 for i, s in enumerate(seq) if i < len(pulsadas) and pulsadas[i] == s["tecla"])
        pct = round(100 * aciertos / len(seq)) if seq else 0
        detalle = []
        for i, s in enumerate(seq):
            ok = i < len(pulsadas) and pulsadas[i] == s["tecla"]
            detalle.append({"pregunta": s["texto"], "ok": ok, "explicacion":
                            "Se pulsaba: %s" % s["tecla"], "opciones": []})
        return pct, "Has pulsado bien %d de %d combinaciones." % (aciertos, len(seq)), detalle

    if tipo == "raton":
        ok = bool(respuestas.get("acierto"))
        elementos = cfg.get("elementos", [])
        pista = ""
        for el in elementos:
            if el.get("correcto"):
                pista = el.get("pista", "")
        detalle = [{"pregunta": cfg.get("instruccion", ""), "ok": ok,
                    "explicacion": pista or "Vuelve a intentarlo mirando bien la pantalla.",
                    "opciones": []}]
        return (100 if ok else 0), ("¡Muy bien!" if ok else "Casi."), detalle

    if tipo == "celdas":
        hoja = cfg.get("hoja", {})
        celda = cfg.get("celda_objetivo", "")
        formula = (respuestas.get("formula") or "").strip()
        ok, valor, error = evaluar_formula(formula, hoja)
        detalle = []
        pct = 0
        mensaje = ""
        if not ok:
            mensaje = error
            detalle.append({"pregunta": "La fórmula no es correcta", "ok": False,
                            "explicacion": error, "opciones": []})
        else:
            esperado = float(cfg.get("resultado_esperado", 0))
            tolerancia = float(cfg.get("tolerancia", 0.01))
            rango = (cfg.get("rango_esperado") or "").replace(" ", "").upper()
            usa_rango = rango and rango in formula.upper().replace(" ", "")
            funciones = [f.upper() for f in cfg.get("funciones_aceptadas", [])]
            usa_funcion = any(f in formula.upper().replace(" ", "") for f in funciones)
            coincide_valor = abs(valor - esperado) <= tolerancia
            pct = 100 if (coincide_valor and usa_rango and usa_funcion) else (60 if coincide_valor else 0)
            if coincide_valor and usa_rango and usa_funcion:
                mensaje = "¡Exacto! La fórmula %s es correcta." % formula
            elif coincide_valor:
                mensaje = "El resultado es correcto, pero revisa la fórmula: usa %s sobre %s." % (
                    funciones[0] if funciones else "la función", rango)
            else:
                mensaje = "El resultado no es el esperado. Comprueba el rango y la función."
            detalle.append({"pregunta": "Fórmula en %s" % celda, "ok": pct == 100,
                            "explicacion": mensaje, "opciones": []})
        return pct, mensaje, detalle

    if tipo == "texto":
        texto = (respuestas.get("texto") or "")
        palabras = len([p for p in texto.split() if p.strip()])
        minimo = cfg.get("min_palabras", 10)
        con_negrita = bool(respuestas.get("negrita"))
        ok = palabras >= minimo and (con_negrita or not cfg.get("requiere_bold"))
        pct = 100 if ok else (60 if palabras >= minimo else 0)
        msg = ("¡Bien hecho! %d palabras y formato aplicado." % palabras if ok
               else "Has escrito %d palabras (mínimo %d). %s" % (
                   palabras, minimo,
                   "Pon el texto en negrita con Ctrl + B." if cfg.get("requiere_bold") and not con_negrita else ""))
        detalle = [{"pregunta": cfg.get("instruccion", ""), "ok": ok, "explicacion": msg, "opciones": []}]
        return pct, msg, detalle

    return 0, "Tipo de ejercicio no soportado.", []


@bp.post("/ejercicio/<int:ejercicio_id>/resultado")
@login_requerido
def resultado_ejercicio(ejercicio_id):
    u = usuario_actual()
    ej = db.q1("SELECT * FROM exercises WHERE id = ?", (ejercicio_id,))
    if not ej:
        return jsonify({"ok": False, "mensaje": "Ejercicio no encontrado."}), 404
    cfg = json.loads(ej["config"] or "{}")
    cfg["preguntas"] = preguntas_ejercicio(cfg, cliente_de(u))
    data = request.get_json(silent=True) or {}
    respuestas = data.get("respuestas") or {}
    pct, mensaje, detalle = _evaluar(ej["tipo"], cfg, respuestas)
    superado = pct >= 70

    prev = db.q1(
        "SELECT * FROM exercise_progress WHERE user_id = ? AND exercise_id = ?", (u["id"], ej["id"])
    )
    if prev:
        nuevo_intentos = prev["intentos"] + 1
        mejor = max(prev["mejor_pct"], pct)
        db.execute(
            """UPDATE exercise_progress SET intentos = ?, superado = ?, mejor_pct = ?, updated_at = ?
               WHERE user_id = ? AND exercise_id = ?""",
            (nuevo_intentos, 1 if superado else 0, mejor, db.ahora(), u["id"], ej["id"]),
        )
        if superado and not prev["superado"]:
            subir_puntos(u["id"], PUNTOS_POR_EJERCICIO, "ejercicio «%s»" % ej["titulo"])
    else:
        db.execute(
            """INSERT INTO exercise_progress(user_id, exercise_id, intentos, superado, mejor_pct, updated_at)
               VALUES(?,?,?,?,?,?)""",
            (u["id"], ej["id"], 1, 1 if superado else 0, pct, db.ahora()),
        )
        if superado:
            subir_puntos(u["id"], PUNTOS_POR_EJERCICIO, "ejercicio «%s»" % ej["titulo"])
    db.log(u["id"], u["username"], "ejercicio", "%s: %d%%" % (ej["titulo"], pct))

    return jsonify({
        "ok": True, "pct": pct, "superado": superado, "mensaje": mensaje,
        "detalle": detalle, "titulo": ej["titulo"],
    })


@bp.get("/progreso")
@login_requerido
def progreso():
    u = usuario_actual()
    total = db.q1("SELECT COUNT(*) AS n FROM lessons")["n"]
    hechas = db.q1(
        "SELECT COUNT(*) AS n FROM progress WHERE user_id = ? AND completado = 1", (u["id"],)
    )["n"]
    st = db.q1("SELECT * FROM user_stats WHERE user_id = ?", (u["id"],))
    return jsonify({
        "lecciones": hechas, "total": total,
        "pct": round(100 * hechas / total) if total else 0,
        "puntos": st["puntos"] if st else 0,
        "racha": st["racha"] if st else 0,
    })


# --------------------------------------------------------------------------- #
# Autoguardado: nada de lo que hace la alumna se pierde
# --------------------------------------------------------------------------- #
@bp.post("/autoguardado")
@login_requerido
def autoguardado():
    """Guarda un borrador (lección, examen o ejercicio) y devuelve la hora del guardado."""
    u = usuario_actual()
    data = request.get_json(silent=True) or {}
    clave = (data.get("clave") or "").strip()[:120]
    if not clave:
        return jsonify({"ok": False, "mensaje": "Falta la clave del borrador."}), 400
    try:
        contenido = json.dumps(data.get("datos"), ensure_ascii=False)
    except (TypeError, ValueError):
        contenido = json.dumps(str(data.get("datos")))
    ahora = db.ahora()
    db.execute(
        """INSERT INTO drafts(user_id, clave, datos, updated_at) VALUES(?,?,?,?)
           ON CONFLICT(user_id, clave) DO UPDATE SET
             datos = excluded.datos, updated_at = excluded.updated_at""",
        (u["id"], clave, contenido, ahora),
    )
    return jsonify({"ok": True, "actualizado": ahora})


@bp.get("/autoguardado/<path:clave>")
@login_requerido
def leer_autoguardado(clave):
    """Recupera el borrador guardado de esa clave (lección, examen o ejercicio)."""
    u = usuario_actual()
    fila = db.q1(
        "SELECT datos, updated_at FROM drafts WHERE user_id = ? AND clave = ?", (u["id"], clave)
    )
    if not fila:
        return jsonify({"ok": True, "datos": None, "actualizado": None})
    try:
        datos = json.loads(fila["datos"] or "null")
    except (TypeError, ValueError):
        datos = None
    return jsonify({"ok": True, "datos": datos, "actualizado": fila["updated_at"]})


@bp.delete("/autoguardado/<path:clave>")
@login_requerido
def borrar_autoguardado(clave):
    """Borra el borrador (por ejemplo, cuando el examen se entrega)."""
    u = usuario_actual()
    db.execute("DELETE FROM drafts WHERE user_id = ? AND clave = ?", (u["id"], clave))
    return jsonify({"ok": True})


@bp.post("/leccion/<slug>/autoguardado")
@login_requerido
def autoguardado_leccion(slug):
    """Guarda por dónde va la alumna en la lección y, si llega al final, la da por completada."""
    u = usuario_actual()
    lec = db.q1("SELECT * FROM lessons WHERE slug = ?", (slug,))
    if not lec:
        return jsonify({"ok": False, "mensaje": "Lección no encontrada."}), 404
    data = request.get_json(silent=True) or {}
    porcentaje = int(data.get("porcentaje") or 0)
    porcentaje = max(0, min(100, porcentaje))
    completada = bool(data.get("completada"))
    segundos = int(data.get("segundos") or 0)
    ahora = db.ahora()

    fila = db.q1(
        "SELECT * FROM progress WHERE user_id = ? AND lesson_id = ?", (u["id"], lec["id"])
    )
    if fila:
        db.execute(
            """UPDATE progress SET en_curso = ?, completado = ?, tiempo_seg = tiempo_seg + ?,
                                updated_at = ? WHERE user_id = ? AND lesson_id = ?""",
            (
                0 if completada else 1,
                1 if completada else fila["completado"],
                max(0, segundos),
                ahora,
                u["id"],
                lec["id"],
            ),
        )
    else:
        db.execute(
            """INSERT INTO progress(user_id, lesson_id, completado, en_curso, score, tiempo_seg, updated_at)
               VALUES(?,?,?,?,?,?,?)""",
            (u["id"], lec["id"], 1 if completada else 0, 0 if completada else 1,
             100 if completada else 0, max(0, segundos), ahora),
        )
    return jsonify({"ok": True, "actualizado": ahora, "porcentaje": porcentaje,
                    "completada": completada})
