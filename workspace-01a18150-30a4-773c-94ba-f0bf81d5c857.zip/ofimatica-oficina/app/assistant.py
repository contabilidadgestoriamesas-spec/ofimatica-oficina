"""La ayudante de ofimática: motor de intenciones, buscador del manual y puente con la IA.

Inspirado en el Asistente de Office de Windows XP (Clippy), pero con IA conversacional.
"""
import json
import re
import unicodedata

from . import db

# --------------------------------------------------------------------------- #
# Personajes (la alumna elige con quién quiere hablar)
# --------------------------------------------------------------------------- #
PERSONAJES = {
    "chispita": {
        "id": "chispita",
        "nombre": "Chispita",
        "rol": "Tu compañera virtual",
        "descripcion": "La más cercana. Explica las cosas con ejemplos del día a día y sin palabras técnicas.",
        "tono": "cercana, breve, animosa, con ejemplos cotidianos",
        "color": "#f4b942",
        "color_oscuro": "#c98a12",
        "emoji": "📌",
        "saludo": "¡Hola! Soy Chispita. Dime en qué te has quedado atascada y te lo explico paso a paso. 📌",
        "consejos": [
            "Si no sabes por dónde empezar, escribe «ayúdame con Word» y te doy el primer paso.",
            "¿Necesitas un atajo? Pregúntame: «¿qué atajo abro el explorador?»",
            "Puedes escribirme el error tal cual te sale en pantalla.",
        ],
    },
    "donatajo": {
        "id": "donatajo",
        "nombre": "Don Atajo",
        "rol": "Especialista en atajos",
        "descripcion": "Experto en teclado. Te da el atajo más rápido para cada tarea y te lo hace practicar.",
        "tono": "técnico pero sencillo, con atajos y atajos alternativos",
        "color": "#4a90d9",
        "color_oscuro": "#2c6cb0",
        "emoji": "⌨️",
        "saludo": "¡Hola! Soy Don Atajo. Todo lo que se pueda hacer con el teclado, te lo doy con su combinación exacta. ⌨️",
        "consejos": [
            "Pregúntame «¿qué atajo hago esto?» y te doy la tecla exacta.",
            "Los cinco atajos universales: Ctrl+C copiar, Ctrl+V pegar, Ctrl+Z deshacer, Ctrl+S guardar, Ctrl+F buscar.",
            "Si pulsas Ctrl + Alt + Supr se reinicia el equipo sinizard.",
        ],
    },
    "nubia": {
        "id": "nubia",
        "nombre": "Nubia",
        "rol": "Especialista en archivos y nube",
        "descripcion": "Experta en carpetas, copias de seguridad, OneDrive y todo lo que se guarda o se pierde.",
        "tono": "serena, organizada, con listas de pasos",
        "color": "#38b6a0",
        "color_oscuro": "#22897a",
        "emoji": "☁️",
        "saludo": "¡Hola! Soy Nubia. Todo lo que guardas, se guarda bien: archivos, carpetas, copias de seguridad y nube. ☁️",
        "consejos": [
            "Si no encuentras un archivo, escríbeme: «no encuentro el informe».",
            "Regla de oro: Ctrl + S cada pocos minutos.",
            "OneDrive de la empresa es donde se ven los archivos del equipo.",
        ],
    },
    "sumia": {
        "id": "sumia",
        "nombre": "Sumia",
        "rol": "Especialista en Excel y cálculo",
        "descripcion": "Dominas las fórmulas, las tablas y los gráficos. Te dice qué fórmula escribir y por qué.",
        "tono": "precisa, con ejemplos de fórmula",
        "color": "#7c5cd6",
        "color_oscuro": "#543ba0",
        "emoji": "📊",
        "saludo": "¡Hola! Soy Sumia. Si es una fórmula, una tabla o un gráfico, lo resolvemos juntas. 📊",
        "consejos": [
            "Dime qué quieres calcular y te escribo la fórmula exacta.",
            "Ctrl + Shift + L pone los filtros; Ctrl + 1 abre el formato de celdas.",
            "Si una celda muestra #####, amplía la columna.",
        ],
    },
}
PERSONAJES_POR_DEFECTO = "chispita"

# --------------------------------------------------------------------------- #
# Intenciones: respuestas rápidas y deterministas (funcionan sin internet)
# --------------------------------------------------------------------------- #
INTENCIONES = [
    {
        "id": "pantallazo",
        "titulo": "Hacer una captura de pantalla",
        "personajes": ["chispita", "donatajo"],
        "patrones": ["pantallazo", "captura de pantalla", "capturar pantalla", "captura", "screenshot",
                     "imagen de la pantalla", "recortes", "print screen", "impresion de pantalla"],
        "respuesta": (
            "Claro que sí. Tienes tres formas, según lo que necesites:\n\n"
            "1) **Capturar una zona concreta (la más usada)**: pulsa **Windows + Shift + S**. "
            "Se atenúa la pantalla, eliges el rectángulo que quieras arrastrando con el ratón y listo. "
            "La imagen queda en el portapapeles y abajo a la derecha sale un aviso para abrirla en Recortes, "
            "ahí puedes marcarla con una flecha y guardarla.\n\n"
            "2) **Capturar toda la pantalla y que se guarde sola**: pulsa **Windows + Impresión de pantalla**. "
            "El archivo se guarda en *Imágenes → Capturas de pantalla*.\n\n"
            "3) **Capturar solo la ventana que tienes abierta**: pulsa **Alt + Impresión de pantalla**.\n\n"
            "Truco: si te sale un error y quieres mandarlo, haz la captura, y en Outlook usa el icono del clip para adjuntarla."
        ),
        "atajos": ["Windows + Shift + S", "Windows + Impresión de pantalla", "Alt + Impresión de pantalla"],
    },
    {
        "id": "no-encuentro-archivo",
        "titulo": "No encuentro un archivo",
        "personajes": ["nubia", "chispita"],
        "patrones": ["no encuentro", "no encuentro mi archivo", "no aparece", "he perdido", "perdi el archivo",
                     "no veo el archivo", "no esta el archivo", "donde he puesto", "no encuentro la carpeta",
                     "no aparece el documento", "buscar un archivo"],
        "respuesta": (
            "Tranquila, esto pasa mucho y casi siempre tiene solución. Vamos por orden:\n\n"
            "1) **Mira dónde se guardó**: en Word o Excel, ve a *Archivo → Recientes*. Ahí aparece el archivo "
            "con su ruta completa.\n\n"
            "2) **Busca por partes del nombre**: abre el Explorador (Windows + E) y pulsa **Ctrl + F**. "
            "Escribe solo una parte del nombre, por ejemplo «ventas».\n\n"
            "3) **Busca en todo el equipo**: en el panel izquierdo del Explorador, pincha en *Este equipo* y busca ahí "
            "(tarda más, pero lo encuentra todo).\n\n"
            "4) **Revisa la Papelera de reciclaje**: a lo mejor lo borraste sin querer. Selecciona el archivo y pulsa *Restaurar*.\n\n"
            "5) **Mira en OneDrive**: si trabajabas en la nube, el archivo está en OneDrive, no en el disco del equipo.\n\n"
            "Si me dices el nombre del archivo te digo por dónde empezar."
        ),
        "atajos": ["Windows + E", "Ctrl + F"],
    },
    {
        "id": "contrasena",
        "titulo": "He olvidado la contraseña",
        "personajes": ["chispita", "donatajo"],
        "patrones": ["contraseña", "contrasena", "password", "clave", "no me acuerdo de la clave",
                     "he olvidado", "no puedo entrar", "contraseña olvidada", "mi usuario"],
        "respuesta": (
            "Vamos por partes:\n\n"
            "**Si es la contraseña de esta aplicación de ofimática**: el administrador (tu responsable de formación) "
            "puede resetarla desde el panel de administración. Solo tiene que abrir *Usuarios → tu nombre → Cambiar contraseña*.\n\n"
            "**Si es la contraseña de Windows**: entra en *Ajustes → Cuentas → Inicio de sesión → Contraseña → Cambiar*. "
            "Si no te acuerdas de la actual, necesitarás el PIN o la cuenta de Microsoft.\n\n"
            "**Si es la del correo (Outlook)**: en la pantalla de inicio de sesión, elige *¿Olvidaste tu contraseña?* "
            "y seguirá el proceso de verificación.\n\n"
            "Mientras tanto, recuerda la regla: una frase de cuatro palabras (bosque-lámpara-27-río) es más segura "
            "y más fácil de recordar que «Paco83»."
        ),
        "atajos": ["Windows + I"],
    },
    {
        "id": "guardar",
        "titulo": "Guardar el documento / no he guardado",
        "personajes": ["chispita", "nubia"],
        "patrones": ["guardar", "no he guardado", "como se guarda", "guardado", "guardar como",
                     "perdi los cambios", "no se guarda", "autoguardado"],
        "respuesta": (
            "**Guardar**: pulsa **Ctrl + S**. Es el atajo que debes automatizar: cada pocos minutos.\n\n"
            "**Guardar como (cambiar nombre, carpeta o formato)**: pulsa **F12** o ve a *Archivo → Guardar como*. "
            "Desde ahí eliges el nombre, la ubicación y el tipo de archivo (docx, xlsx o PDF).\n\n"
            "**Si has cerrado el programa sin guardar**: no siempre se pierde. En Word, al volver a abrir el archivo, "
            "puede aparecerte un documento de recuperación en la parte superior. También mira en *Documentos* "
            "si hay algún archivo llamado «Documento1» o con la marca de autoguardado.\n\n"
            "Y recuerda: **Ctrl + S** es tu mejor amiga."
        ),
        "atajos": ["Ctrl + S", "F12", "Ctrl + Mayús + S"],
    },
    {
        "id": "imprimir",
        "titulo": "Imprimir",
        "personajes": ["chispita", "donatajo"],
        "patrones": ["imprimir", "impresora", "no imprime", "impresión", "papel", "imprimir en dos caras"],
        "respuesta": (
            "Para imprimir desde cualquier programa: **Ctrl + P**.\n\n"
            "En la ventana que se abre:\n"
            "1) Mira la **vista previa** (panel izquierdo): comprueba cuántas páginas son.\n"
            "2) Elige la **impresora** (arriba).\n"
            "3) Ajusta **copias** y el rango de **páginas** (todas, la actual o 1-3).\n"
            "4) Para **dos caras**, entra en *Más ajustes* y marca *Imprimir en dos caras* (atajo: **Ctrl + Mayús + P**).\n"
            "5) Pulsa **Imprimir**.\n\n"
            "**Si la impresora no responde**: comprueba que tenga papel y que no tenga un error en su pantalla; "
            "en Windows, *Win + I → Bluetooth y dispositivos → Impresoras y escáneres* para ver el estado. "
            "Haz un pantallazo del error y avisa al servicio de sistemas: no desmontes nada.\n\n"
            "**Truco**: si solo quieres un PDF y no papel, elige la impresora *Microsoft Print to PDF*."
        ),
        "atajos": ["Ctrl + P", "Ctrl + Mayús + P"],
    },
    {
        "id": "excel-formula",
        "titulo": "Fórmulas de Excel",
        "personajes": ["sumia", "chispita"],
        "patrones": ["formula", "fórmula", "excel", "sumar", "suma", "promedio", "media", "como sumo",
                     "contar", "maximo", "minimo", "celda", "hoja de calculo", "tabla dinamica", "filtrar",
                     "ordenar", "grafico", "gráfico", "referencia absoluta", "sumar.si", "contar.si"],
        "respuesta": (
            "Te doy las fórmulas que más se usan. **Todas empiezan por el signo igual (=)**:\n\n"
            "- `=SUMA(B2:B20)` → suma el rango.\n"
            "- `=PROMEDIO(B2:B20)` → la media.\n"
            "- `=MAX(B2:B20)` / `=MIN(B2:B20)` → el máximo y el mínimo.\n"
            "- `=CONTAR(B2:B20)` → cuántas celdas tienen números.\n"
            "- `=SI(B2>1000;\"Alto\";\"Normal\")` → decisión según una condición.\n"
            "- `=SUMAR.SI(A2:A50;\"Madrid\";C2:C50)` → suma solo lo que cumple una condición.\n"
            "- `=CONTAR.SI(B2:B50;\"Sí\")` → cuenta los que cumplen una condición.\n\n"
            "**Atajos útiles**: **Alt + =** suma automática, **F4** fija una referencia (la pone como $B$2), "
            "**Ctrl + 1** abre el formato de celdas, **Ctrl + Mayús + L** pone los filtros.\n\n"
            "**Si te sale error**: `#¡VALOR!` es que estás multiplicando texto por número; "
            "`#¡DIV/0!` es que divides entre cero; `#¡REF!` es que borraste una celda usada por la fórmula.\n\n"
            "Dime exactamente qué quieres calcular y te escribo la fórmula con tus datos."
        ),
        "atajos": ["Alt + =", "F4", "Ctrl + 1", "Ctrl + Mayús + L"],
    },
    {
        "id": "word",
        "titulo": "Microsoft Word",
        "personajes": ["chispita", "donatajo"],
        "patrones": ["word", "documento", "tabla", "negrita", "encabezado", "indice", "índice", "plantilla",
                     "pdf", "insertar imagen", "margenes", "márgenes"],
        "respuesta": (
            "En **Word** lo esencial:\n\n"
            "- **Negrita** `Ctrl + B` · **Cursiva** `Ctrl + K` · **Subrayado** `Ctrl + U`\n"
            "- **Centrar** `Ctrl + E` · **Alinear a la izquierda** `Ctrl + Q` · **Justificar** `Ctrl + J`\n"
            "- **Guardar** `Ctrl + S` · **Guardar como / PDF** `F12` · **Imprimir** `Ctrl + P`\n"
            "- **Buscar** `Ctrl + F` · **Reemplazar** `Ctrl + H` (perfecto para cambiar un nombre repetido)\n"
            "- **Insertar tabla** `Ctrl + T`\n\n"
            "**Para crear un PDF**: *Archivo → Guardar como → Tipo: PDF (*.pdf)*.\n\n"
            "**Un consejo de ofimática**: en lugar de dar formato a mano, usa los **estilos** (Título 1, Título 2, "
            "Normal). Así todos los títulos se ven iguales, se cambian de golpe y el índice se monta solo.\n\n"
            "¿Qué necesitas hacer exactamente en Word?"
        ),
        "atajos": ["Ctrl + B", "Ctrl + E", "Ctrl + S", "F12", "Ctrl + H", "Ctrl + T"],
    },
    {
        "id": "thunderbird",
        "titulo": "Thunderbird: configurar, adjuntar, buscar",
        "personajes": ["chispita", "donatajo", "nubia"],
        "patrones": ["thunderbird", "mozilla", "rayo", "configurar thunderbird", "añadir cuenta",
                     "cuenta de correo thunderbird", "filtros thunderbird", "adjuntar thunderbird",
                     "busqueda global thunderbird"],
        "respuesta": (
            "**Thunderbird** es el programa de correo gratuito de Mozilla. Vamos por partes:\n\n"
            "**1) Instalarlo y conectar tu cuenta**\n"
            "- Descárgalo de *thunderbird.net* e instálalo (es un clic).\n"
            "- Al abrirlo, escribe tu nombre, tu dirección de correo y tu contraseña, y pulsa *Continuar*.\n"
            "- Si no encuentra el servidor solo, pulsa *Configurar manualmente*:\n"
            "  - Entrada: IMAP, servidor `outlook.office365.com` (o el de tu empresa), puerto 993, SSL/TLS.\n"
            "  - Salida (SMTP): `smtp.office365.com`, puerto 587, STARTTLS.\n"
            "  - El nombre de usuario es tu dirección de correo **completa**.\n\n"
            "**2) Los atajos de Thunderbird** (difieren un poco de Outlook):\n"
            "- `Ctrl + N` nuevo mensaje · `Ctrl + R` responder · `Ctrl + Mayús + R` responder a todos\n"
            "- `Ctrl + L` reenviar (¡en Outlook es Ctrl + F!)\n"
            "- `Ctrl + K` búsqueda global · `Ctrl + Mayús + K` filtro rápido\n"
            "- `F5` obtener mensajes nuevos\n\n"
            "**3) Adjuntar un archivo**: en la ventana de redacción, el icono del clip 📎 → "
            "*Adjuntar archivos…* → elige el archivo.\n\n"
            "**4) Poner tu firma**: menú ≡ → *Configuración* → *General* → campo * Firma*.\n\n"
            "**5) Crear una regla automática**: menú ≡ → *Herramientas → Filtros de mensajes* → *Nuevo…*.\n\n"
            "¿Estás con Thunderbird o con Outlook? Te lo adapto al tuyo."
        ),
        "atajos": ["Ctrl + N", "Ctrl + R", "Ctrl + L", "Ctrl + K", "F5"],
    },
    {
        "id": "correo",
        "titulo": "Correo electrónico",
        "personajes": ["chispita", "donatajo"],
        "patrones": ["correo", "email", "outlook", "adjuntar", "adjunto", "responder a todos", "regla",
                     "firma", "enviar", "bandeja de entrada", "no me llega", "correos", "mensaje nuevo",
                     "imap", "smtp", "pop3"],
        "respuesta": (
            "Lo básico del correo:\n\n"
            "- **Nuevo mensaje** `Ctrl + Shift + N` (en Outlook) o `Ctrl + N` (en Thunderbird)\n"
            "- **Responder** `Ctrl + R` · **Responder a todos** `Ctrl + Mayús + R` (¡ojo, puede llegar a mucha gente!)\n"
            "- **Reenviar** `Ctrl + F` en Outlook · `Ctrl + L` en Thunderbird\n"
            "- **Enviar** `Ctrl + Enter`\n\n"
            "**Adjuntar un archivo**: *Insertar → Adjuntar → Este equipo* (en Outlook) o el icono del clip 📎 "
            "(en Thunderbird). Comprueba siempre el nombre que aparece junto al clip antes de enviar.\n\n"
            "**Problemas típicos**:\n"
            "- *No puedo adjuntar*: el archivo está abierto en otro programa. Ciérralo y prueba otra vez.\n"
            "- *Es muy grande*: el límite es de unos 25 MB. Comprímelo o compártelo como enlace de OneDrive.\n"
            "- *No me llega*: mira la carpeta *Enviados*; si es un archivo grande, el envío puede haber fallado.\n\n"
            "**Para no depender de la memoria**, crea una **regla**: en Outlook, *Archivo → Reglas y alertas → "
            "Nueva regla*; en Thunderbird, *Herramientas → Filtros de mensajes → Nuevo…*.\n\n"
            "**¿Usas Outlook o Thunderbird?** Dímelo y te doy los pasos exactos del tuyo."
        ),
        "atajos": ["Ctrl + Shift + N", "Ctrl + R", "Ctrl + K", "Ctrl + Enter"],
    },
    {
        "id": "teclas-windows",
        "titulo": "Atajos de Windows y la tecla Windows",
        "personajes": ["donatajo", "chispita"],
        "patrones": ["tecla windows", "tecla windows", "boton windows", "atajo", "atajos", "shortcut",
                     "como se bloquea", "menu inicio", "abrir inicio", "cambiar de ventana", "windows mas"],
        "respuesta": (
            "La **tecla Windows** es la que lleva el dibujito de una ventana, entre Ctrl y Alt. "
            "Pulsada sola abre el menú Inicio.\n\n"
            "Los atajos que más vas a usar:\n"
            "- `Windows + E` → Explorador de archivos\n"
            "- `Windows + D` → mostrar el escritorio\n"
            "- `Windows + L` → bloquear el ordenador\n"
            "- `Windows + I` → Ajustes\n"
            "- `Windows + R` → Ejecutar (escribe `control` y pulsa Intro)\n"
            "- `Windows + S` → buscar\n"
            "- `Windows + X` → menú de administrador\n"
            "- `Windows + Shift + S` → captura de zona\n"
            "- `Windows + flecha ←/→` → poner la ventana en la mitad izquierda o derecha\n"
            "- `Windows + Z` → diseños de acoplamiento (dividir pantalla)\n"
            "- `Alt + Tab` → cambiar de ventana\n\n"
            "Y los universales de todos los programas: `Ctrl + C` copiar, `Ctrl + V` pegar, `Ctrl + Z` deshacer, "
            "`Ctrl + A` seleccionar todo, `Ctrl + S` guardar, `Ctrl + F` buscar, `Ctrl + P` imprimir."
        ),
        "atajos": ["Windows + E", "Windows + D", "Windows + L", "Windows + I", "Windows + R", "Alt + Tab"],
    },
    {
        "id": "teams-reunion",
        "titulo": "Reuniones y compartir pantalla",
        "personajes": ["chispita", "donatajo"],
        "patrones": ["teams", "reunion", "reunión", "videollamada", "compartir pantalla", "microfono",
                     "micrófono", "camara", "cámara", "zoom", "videoconferencia", "silenciar"],
        "respuesta": (
            "Antes de la reunión, comprueba tres cosas:\n"
            "1) **Micrófono muteado**: pulsa **Ctrl + Mayús + M** para silenciarlo.\n"
            "2) **Cámara**: **Ctrl + Mayús + O** para encenderla o apagarla.\n"
            "3) **Auriculares**: evitan el eco.\n\n"
            "**Para compartir pantalla**: pulsa *Compartir pantalla* y elige **Pestaña** en lugar de Pantalla completa. "
            "Así solo ven la pestaña que tú elijas. Para terminar, *Dejar de compartir*.\n\n"
            "**Importante**: antes de compartir, cierra el correo y cualquier documento de otro compañero. "
            "Todo lo que hay en tu escritorio se ve, y es el error más habitual en las reuniones.\n\n"
            "En el chat de la reunión, escribe con **Ctrl + Mayús + Enter** para enviar sin que se te corte el mensaje."
        ),
        "atajos": ["Ctrl + Mayús + M", "Ctrl + Mayús + O", "Ctrl + Mayús + Enter"],
    },
    {
        "id": "pdf",
        "titulo": "PDF y escaneo",
        "personajes": ["nubia", "chispita"],
        "patrones": ["pdf", "escaneo", "escanear", "escáner", "digitalizar", "unir pdf", "combinar pdf",
                     "imprimir en pdf", "firmar pdf"],
        "respuesta": (
            "**Ver un PDF**: doble clic. Windows lo abre con su visor y también con Edge, sin instalar nada.\n\n"
            "**Escanear a PDF**: pulsa **Windows + S**, escribe *Escáner* y abre la aplicación *Escáner de Windows*. "
            "Pulsa *Agregar*, elige tu multifunción, coloca el documento en el cristal (cara abajo, esquina arriba a la izquierda) "
            "y pulsa *Escanear*.\n\n"
            "**Unir varios PDF en uno** (Windows 11): selecciona los archivos en el Explorador con **Ctrl + clic**, "
            "clic derecho → **Combinar en un PDF**.\n\n"
            "**Pasar un PDF a Word**: ábrelo en Edge y usa el botón *Editar* / *Guardar como Word*. "
            "Si es un escaneado (imagen), el texto no se reconoce: habría que pasarlo por OCR.\n\n"
            "**Antes de enviar un documento**: si es para leer e imprimir, envíalo en PDF; si lo van a editar, en Word."
        ),
        "atajos": ["Windows + S", "Ctrl + F", "Ctrl + P"],
    },
    {
        "id": "wifi",
        "titulo": "Problemas de conexión",
        "personajes": ["chispita", "nubia"],
        "patrones": ["wifi", "internet", "no me conecto", "sin conexion", "sin conexión", "red", "no funciona internet",
                     "se desconecta", "globo terráqueo"],
        "respuesta": (
            "Vamos por orden:\n\n"
            "1) Pulsa **Windows + A** (ajustes rápidos) y mira si el wifi está encendido y si aparece la red de la oficina.\n"
            "2) Si te conectas pero no navegas, prueba a abrir el navegador. Si tampoco funciona: "
            "pulsa **Windows + R**, escribe `cmd` y Intro, y teclea `ping 8.8.8.8`. Si responde, el problema es de DNS.\n"
            "3) Desconecta y vuelve a conectar la red.\n"
            "4) Reinicia el equipo y el router (apágalo 10 segundos y enciéndelo).\n\n"
            "**Si tienes un globo terráqueo en la barra de tareas**, es que no hay acceso a Internet.\n\n"
            "Si nada de esto funciona, avisa al servicio de sistemas. No cambies la configuración de red por tu cuenta: "
            "en la oficina los equipos los configura el servicio técnico."
        ),
        "atajos": ["Windows + A", "Windows + R"],
    },
    {
        "id": "phishing",
        "titulo": "Sospecha de un correo falso",
        "personajes": ["chispita", "donatajo"],
        "patrones": ["phishing", "correo falso", "estafa", "fraude", "me han hackeado", "virus",
                     "sospechoso", "correo raro", "me piden contraseña", "suplantacion"],
        "respuesta": (
            "Si un correo te parece sospechoso, **no pulses nada**. Estas son las señales de alarma:\n\n"
            "- Urgencia: «tu cuenta se bloqueará en 24 horas».\n"
            "- Remitante parecido pero no igual: revisa que la dirección termine en el dominio real de la empresa.\n"
            "- Un enlace que no lleva a donde dice: pasa el ratón por encima (sin hacer clic) y mira la URL real abajo.\n"
            "- Petición de contraseñas o datos de pago: **ningún servicio legítimo te los pide por correo**.\n"
            "- Un adjunto inesperado con extensión .exe o .bat.\n\n"
            "**Qué hacer**: avisa a tu responsable por teléfono (no respondiendo al correo), no pulses enlaces y "
            "denúncialo con el botón *Denunciar phishing* de Outlook.\n\n"
            "Si crees que te han hackeado: cambia la contraseña desde otro equipo, avisa al servicio de sistemas "
            "y **no borres los correos** (pueden ser pruebas)."
        ),
        "atajos": ["Windows + L"],
    },
    {
        "id": "onedrive",
        "titulo": "OneDrive y carpetas compartidas",
        "personajes": ["nubia", "chispita"],
        "patrones": ["onedrive", "nube", "cloud", "compartir carpeta", "no me ven el archivo", "sincronizar",
                     "guardar en la nube", "carpeta compartida"],
        "respuesta": (
            "**OneDrive** es el espacio de la empresa en internet. Lo activo así:\n"
            "1) Haz clic en el icono de la nube en la bandeja (abajo a la derecha).\n"
            "2) Si pone *Iniciar sesión*, entra con tu cuenta de empresa.\n"
            "3) La carpeta OneDrive aparecerá en el Explorador; guarda ahí lo que quieras compartir.\n\n"
            "**El error más común**: un archivo guardado en *OneDrive - Personal* **no lo ven tus compañeras**. "
            "Muévelo a *OneDrive - Empresa* o a la carpeta compartida del equipo.\n\n"
            "**Los iconos**: nube con check verde = guardado; nube con flechas = se está subiendo (espera antes "
            "de apagar); nube con alerta = problema de sesión o falta de espacio.\n\n"
            "**Para compartir**: clic derecho sobre el archivo → *Compartir* → elige *Personas específicas* → "
            "añade a quien corresponda → *Puede editar* o *Puede ver*."
        ),
        "atajos": ["Windows + E"],
    },
    {
        "id": "lento",
        "titulo": "El ordenador va lento o se cuelga",
        "personajes": ["chispita", "donatajo"],
        "patrones": ["va lento", "lento", "cuelga", "se ha colgado", "no responde", "congelado", "se queda pillado",
                     "rendimiento", "tarda mucho"],
        "respuesta": (
            "**Si va lento pero funciona**:\n"
            "1) Espera un momento: el antivirus o una actualización pueden estar trabajando.\n"
            "2) Cierra los programas que no uses.\n"
            "3) Pulsa **Ctrl + Mayús + Esc** (Administrador de tareas) y mira qué programa consume más memoria o CPU.\n"
            "4) Reinicia el equipo: libera toda la memoria.\n\n"
            "**Si no responde**:\n"
            "1) **Ctrl + Mayús + Esc** → busca el programa con «(No responde)» → *Finalizar tarea*.\n"
            "2) Si no responde el sistema: **Ctrl + Alt + Supr** (reinicio forzado).\n\n"
            "**Si el disco está lleno**, el equipo va muy lento. Míralo en *Windows + I → Sistema → Almacenamiento*.\n\n"
            "Y recuerda: reinicia el equipo de vez en cuando, y guarda con **Ctrl + S** antes."
        ),
        "atajos": ["Ctrl + Mayús + Esc", "Ctrl + Alt + Supr"],
    },
    {
        "id": "ia",
        "titulo": "Usar la IA (Copilot) en el trabajo",
        "personajes": ["chispita", "sumia"],
        "patrones": ["copilot", "chatgpt", "inteligencia artificial", "ia", "prompt", "preguntar a la ia",
                     "redactar con ia", "resumir con ia"],
        "respuesta": (
            "La IA está en **Windows + C** (Copilot) y dentro de Word, Excel, Outlook y Teams (Microsoft 365 Copilot).\n\n"
            "**La estructura de una buena petición**: tarea + contexto + formato.\n"
            "Ejemplo: «Actúa como asistente administrativo. Escribe un correo al cliente que ha pedido aplazar la "
            "entrega: 3 frases, tono cordial, incluye la nueva fecha del 15 de noviembre».\n\n"
            "**Para que te sirva de verdad**:\n"
            "- *Redactar*: «Reescribe este párrafo para que sea más claro y formal».\n"
            "- *Resumir*: «Resume este correo en 3 puntos con la acción que tengo que hacer».\n"
            "- *Preparar*: «Crea una agenda de 5 puntos para revisar el informe».\n"
            "- *Excel*: «¿Cómo hago para contar las ventas que superan 1000 €?»\n\n"
            "**Reglas en la oficina**: no pegues datos confidenciales en una IA no autorizada, verifica siempre los datos "
            "y cifras que te da, y la responsabilidad final del documento es tuya."
        ),
        "atajos": ["Windows + C"],
    },
    {
        "id": "atajos-generico",
        "titulo": "Busco un atajo",
        "personajes": ["donatajo"],
        "patrones": ["que atajo", "cual es el atajo", "atajo para", "como se hace con el teclado", "atajo de"],
        "respuesta": (
            "Dime exactamente qué quieres hacer y te doy la tecla exacta. Los más usados son:\n\n"
            "| Quiero… | Atajo |\n|---|---|\n"
            "| Copiar | `Ctrl + C` |\n| Pegar | `Ctrl + V` |\n| Cortar | `Ctrl + X` |\n"
            "| Deshacer | `Ctrl + Z` |\n| Guardar | `Ctrl + S` |\n| Buscar | `Ctrl + F` |\n"
            "| Reemplazar | `Ctrl + H` |\n| Imprimir | `Ctrl + P` |\n| Nuevo | `Ctrl + N` |\n"
            "| Abrir | `Ctrl + O` |\n| Cerrar | `Ctrl + W` o `Alt + F4` |\n"
            "| Escritorio | `Windows + D` |\n| Bloquear | `Windows + L` |\n| Explorador | `Windows + E` |\n"
            "| Ajustes | `Windows + I` |\n| Captura | `Windows + Shift + S` |\n"
        ),
        "atajos": ["Ctrl + C", "Ctrl + V", "Ctrl + Z", "Ctrl + S", "Ctrl + F"],
    },
    {
        "titulo": "Progreso del curso",
        "id": "progreso",
        "personajes": ["chispita", "nubia", "sumia", "donatajo"],
        "patrones": ["mi progreso", "cuanto me falta", "mi nota", "mi avance", "por donde voy", "que he hecho"],
        "respuesta": "PROGRESO",  # se sustituye por el resumen real de progreso
        "atajos": [],
    },
]

CONSEJOS_RAPIDOS = [    "Pulsa **Ctrl + S** cada pocos minutos. Es el hábito que más tiempo te ahorra.",
    "¿Sabías que **Windows + Shift + S** hace una captura de la zona que elijas?",
    "Con **Windows + E** abres el Explorador de archivos sin tocar el ratón.",
    "En Word, **Ctrl + H** (reemplazar) cambia un nombre repetido en dos segundos.",
    "**Windows + L** bloquea el ordenador: hazlo siempre que te levantes de la mesa.",
    "En Excel, **Alt + =** suma la columna de al lado automáticamente.",
    "Si algo no te sale, haz un **pantallazo** antes de pedir ayuda: explica mejor.",
    "El **doble clic** en un archivo lo abre; un solo clic solo lo selecciona.",
    "**Windows + flecha izquierda** y **flecha derecha** ponen dos ventanas en paralelo.",
    "En Outlook, **Ctrl + Mayús + R** responde a todos. Úsalo con cuidado.",
]


# --------------------------------------------------------------------------- #
# Utilidades de texto
# --------------------------------------------------------------------------- #
# --------------------------------------------------------------------------- #
# Utilidades de texto
# --------------------------------------------------------------------------- #
STOPWORDS = {
    "de", "la", "el", "los", "las", "un", "una", "unos", "unas", "y", "o", "u", "a", "al", "del",
    "para", "con", "por", "sin", "es", "son", "no", "se", "lo", "su", "sus", "mi", "mis", "me",
    "te", "si", "ya", "muy", "mas", "más", "como", "cómo", "cuando", "cuándo", "donde", "dónde",
    "esto", "este", "esta", "hay", "he", "ha", "han", "ser", "estar", "fue", "era", "muy", "tan",
    "puedo", "puede", "puedes", "quiero", "saber", "hacer", "tengo", "tiene", "pero", "porque",
    "que", "qué", "ayuda", "ayudante", "hola", "gracias", "vale", "ok", "sirve", "necesito",
    "problema", "problema?", "ayudame", "ayúdame", "duda", "dudas", "favor", "porfa", "hola!",
    "nada", "ver", "vez", "veces", "cosa", "cosas", "gente", "sirve", "pasa", "pasan", "etc",
    "tengo", "tiene", "tienen", "puedo", "puede", "quiero", "necesito", "buscar", "busco", "donde",
}


def palabras_significativas(texto):
    """Palabras con contenido real de una consulta (descarta palabras vacías)."""
    return [p for p in normalizar(texto).split() if len(p) > 2 and p not in STOPWORDS]


def _coincide(texto, palabra):
    """True si la palabra aparece como palabra completa (no como parte de otra)."""
    if not palabra:
        return False
    return re.search(r"\b%s" % re.escape(palabra), texto) is not None


def normalizar(texto):
    """Minúsculas, sin acentos ni signos: ideal para comparar."""
    texto = (texto or "").lower().strip()
    texto = unicodedata.normalize("NFKD", texto)
    texto = "".join(c for c in texto if not unicodedata.combining(c))
    texto = re.sub(r"[^a-z0-9ñ ]+", " ", texto)
    return re.sub(r"\s+", " ", texto).strip()


def formatear(texto):
    """Convierte **negrita**, listas con - y saltos en HTML seguro."""
    salida = []
    for linea in (texto or "").split("\n"):
        esc = (linea.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))
        esc = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", esc)
        esc = re.sub(r"`(.+?)`", r"<code>\1</code>", esc)
        if esc.strip().startswith("- "):
            salida.append("<li>%s</li>" % esc.strip()[2:])
        elif esc.strip():
            salida.append("<p>%s</p>" % esc)
    # agrupar listas consecutivas
    html = ""
    en_lista = False
    for frag in salida:
        if frag.startswith("<li>"):
            if not en_lista:
                html += "<ul>"
                en_lista = True
            html += frag
        else:
            if en_lista:
                html += "</ul>"
                en_lista = False
            html += frag
    if en_lista:
        html += "</ul>"
    return html


# --------------------------------------------------------------------------- #
# Búsqueda en el manual
# --------------------------------------------------------------------------- #
def buscar_articulos(consulta, limite=4):
    """Devuelve artículos relevantes para la consulta (sin IA)."""
    palabras = palabras_significativas(consulta)
    if not palabras:
        return []
    filas = db.q("SELECT * FROM articles")
    puntuados = []
    for art in filas:
        titulo = normalizar(art["titulo"])
        tags = normalizar(art["tags"])
        cuerpo = normalizar(art["cuerpo"])
        categoria = normalizar(art["categoria"])
        puntos = 0
        for p in palabras:
            if _coincide(titulo, p):
                puntos += 6
            if _coincide(tags, p):
                puntos += 4
            if _coincide(categoria, p):
                puntos += 2
            if _coincide(cuerpo, p):
                puntos += 1
        if puntos > 0:
            puntuados.append((puntos, art))
    puntuados.sort(key=lambda x: -x[0])
    return [a for _, a in puntuados[:limite]]


def extraer_resumen(art, max_chars=420):
    """Primeras frases útiles del artículo."""
    texto = re.sub(r"<[^>]+>", " ", art["cuerpo"] or "")
    texto = re.sub(r"\s+", " ", texto).strip()
    if len(texto) <= max_chars:
        return texto
    corte = texto[:max_chars]
    punto = corte.rfind(". ")
    if punto > 120:
        corte = corte[: punto + 1]
    return corte + "…"


def coincidencia_intencion(mensaje, personaje=None):
    """Devuelve la intención más probable (o None)."""
    q = normalizar(mensaje)
    if not q:
        return None
    mejor = None
    mejor_puntos = 0
    for intent in INTENCIONES:
        if intent.get("respuesta") == "PROGRESO":
            continue
        if personaje and intent.get("personajes") and personaje not in intent["personajes"]:
            # permitimos igual, pero con penalización
            penal = 0.5
        else:
            penal = 1.0
        puntos = 0
        for patron in intent["patrones"]:
            pn = normalizar(patron)
            if not pn:
                continue
            if pn in q:
                puntos += max(3, len(pn.split()) * 3)
            else:
                # coincidencia por palabras sueltas del patrón
                palabras = [x for x in pn.split() if len(x) > 3]
                if palabras and sum(1 for x in palabras if x in q) >= max(2, len(palabras) - 1):
                    puntos += 2
        puntos *= penal
        if puntos > mejor_puntos:
            mejor_puntos = puntos
            mejor = intent
    return mejor if mejor_puntos >= 3 else None


# --------------------------------------------------------------------------- #
# Resumen de progreso para la ayudante
# --------------------------------------------------------------------------- #
def resumen_progreso(user_id):
    datos = db.q1(
        """SELECT
             (SELECT COUNT(*) FROM progress p JOIN lessons l ON l.id = p.lesson_id
                JOIN modules m ON m.id = l.module_id
               WHERE p.user_id = ? AND p.completado = 1) AS lecciones,
             (SELECT COUNT(*) FROM lessons) AS lecciones_totales,
             (SELECT COUNT(*) FROM exam_attempts ea JOIN exams e ON e.id = ea.exam_id
               WHERE ea.user_id = ? AND ea.aprobado = 1) AS exámenes_ok,
             (SELECT puntos FROM user_stats WHERE user_id = ?) AS puntos
        """,
        (user_id, user_id, user_id),
    )
    if not datos:
        return "Todavía no tienes progreso registrado. Empieza por el módulo 1."
    pct = 0
    if datos["lecciones_totales"]:
        pct = round(100 * datos["lecciones"] / datos["lecciones_totales"])
    return (
        "Llevas **%d de %d lecciones** (%d %%) y has aprobado **%d examen/es**. "
        "Tienes **%d puntos** acumulados. ¡Sigue así!"
        % (datos["lecciones"], datos["lecciones_totales"], pct, datos["exámenes_ok"], datos["puntos"] or 0)
    )


# --------------------------------------------------------------------------- #
# Respuesta final
# --------------------------------------------------------------------------- #
# Respuestas del correo adaptadas al programa que usa cada alumna.
RESPUESTAS_CORREO = {
    "outlook": (
        "Vamos con **Outlook**, que es el que usas:\n\n"
        "**Escribir y enviar**\n"
        "- Nuevo mensaje: `Ctrl + Shift + N`\n"
        "- Responder: `Ctrl + R` · Responder a todos: `Ctrl + Mayús + R` (¡cuidado, puede llegar a mucha gente!)\n"
        "- Reenviar: `Ctrl + F` · Buscar en el correo: `Ctrl + K`\n"
        "- Enviar: `Ctrl + Enter`\n\n"
        "**Adjuntar un archivo**: *Insertar → Adjuntar → Este equipo*, lo eliges y compruebas el nombre que "
        "aparece junto al clip antes de enviar.\n\n"
        "**Poner tu firma**: *Archivo → Opciones → Correo → Firma*.\n\n"
        "**Crear una regla automática**: *Archivo → Reglas y alertas → Nueva regla…* (por ejemplo, mover a "
        "*Facturas* todo lo que venga de la gestoría).\n\n"
        "**Si no puedo adjuntar**: el archivo está abierto en otro programa. Ciérralo y prueba otra vez.\n"
        "**Si es muy grande**: el límite es de unos 25 MB. Comprímelo o compártelo como enlace de OneDrive."
    ),
    "thunderbird": (
        "Vamos con **Thunderbird**, que es el que usas:\n\n"
        "**Escribir y enviar**\n"
        "- Nuevo mensaje: `Ctrl + N`\n"
        "- Responder: `Ctrl + R` · Responder a todos: `Ctrl + Mayús + R`\n"
        "- Reenviar: `Ctrl + L` (¡en Outlook es Ctrl + F!) · Buscar en todo: `Ctrl + K`\n"
        "- Obtener mensajes nuevos: `F5`\n\n"
        "**Adjuntar un archivo**: en la ventana de redacción, el icono del clip 📎 → *Adjuntar archivos…*.\n\n"
        "**Poner tu firma**: menú ≡ → *Configuración* → *General* → campo *Firma*.\n\n"
        "**Crear una regla automática**: menú ≡ → *Herramientas → Filtros de mensajes* → *Nuevo…*.\n\n"
        "**Si no me deja adjuntar**: el archivo está abierto en otro programa. Ciérralo y prueba otra vez.\n"
        "**Si no encuentra mi cuenta**: *Configuración de la cuenta → Ações de la cuenta → Añadir cuenta de correo*, "
        "con IMAP puerto 993 SSL/TLS y SMTP puerto 587 STARTTLS."
    ),
    "ambos": (
        "Como usas los dos, aquí van los dos caminos:\n\n"
        "**Outlook**\n"
        "- Nuevo mensaje `Ctrl + Shift + N` · Reenviar `Ctrl + F` · Buscar `Ctrl + K`\n"
        "- Adjuntar: *Insertar → Adjuntar → Este equipo*\n"
        "- Regla: *Archivo → Reglas y alertas → Nueva regla…*\n\n"
        "**Thunderbird**\n"
        "- Nuevo mensaje `Ctrl + N` · Reenviar `Ctrl + L` · Búsqueda global `Ctrl + K`\n"
        "- Adjuntar: icono del clip 📎 en la ventana de redacción\n"
        "- Regla: *Herramientas → Filtros de mensajes → Nuevo…*\n\n"
        "**Lo que es igual en los dos**: `Ctrl + R` responder, `Ctrl + Mayús + R` responder a todos, "
        "`Ctrl + Enter` enviar, `F5` para bajar el correo nuevo (en Outlook, el botón *Obtener*).\n\n"
        "¿Con cuál te has quedado atascada?"
    ),
}


def cliente_correo(user_id):
    """Devuelve el programa de correo elegido por la alumna (outlook/thunderbird/ambos)."""
    if not user_id:
        return "ambos"
    fila = db.q1("SELECT email_client FROM users WHERE id = ?", (user_id,))
    valor = (fila["email_client"] if fila else "") or "ambos"
    return valor if valor in ("outlook", "thunderbird", "ambos") else "ambos"


def construir_respuesta(mensaje, user_id=None, personaje="chispita", contexto=None):
    """Devuelve dict con: texto (HTML), origen, articulos, atajos, sugerencias."""
    mensaje = (mensaje or "").strip()
    if not mensaje:
        return {
            "texto": "<p>¿En qué te puedo ayudar? Escríbeme tu duda tal como la dirías a una compañera.</p>",
            "origen": "sistema",
            "articulos": [],
            "atajos": [],
            "sugerencias": [],
        }

    # 1) Intención determinista
    intent = coincidencia_intencion(mensaje, personaje)

    # 2) Búsqueda en el manual
    articulos = buscar_articulos(mensaje, limite=3)

    # 3) Intención específica de progreso
    qn = normalizar(mensaje)
    if any(k in qn for k in ["mi progreso", "cuanto me falta", "mi nota", "mi avance", "que he hecho"]):
        if user_id:
            texto = "<p>%s</p>" % formatear(resumen_progreso(user_id))
        else:
            texto = "<p>Puedo darte tu progreso en cuanto estés identificada.</p>"
        return {
            "texto": texto,
            "origen": "progreso",
            "articulos": [],
            "atajos": [],
            "sugerencias": [],
        }

    # 4) Si hay IA configurada, la usamos como red de seguridad (respuesta conversacional)
    from .ia import configuracion_ia, llamar_ia

    conf = configuracion_ia()
    if conf.get("activada") == "1":
        contexto_extra = ""
        if contexto:
            contexto_extra = (
                "Contexto de la alumna:\n"
                "- Módulo actual: %s\n- Lección actual: %s\n"
                % (contexto.get("modulo", ""), contexto.get("leccion", ""))
            )
        resumen_art = ""
        if articulos:
            resumen_art = "\n".join(
                "- %s: %s" % (a["titulo"], extraer_resumen(a, 320)) for a in articulos
            )
        respuesta_ia = llamar_ia(mensaje, personaje, resumen_art, contexto_extra)
        if respuesta_ia:
            return {
                "texto": formatear(respuesta_ia),
                "origen": "ia",
                "articulos": [{"titulo": a["titulo"], "slug": a["slug"], "categoria": a["categoria"]} for a in articulos],
                "atajos": (intent or {}).get("atajos", []),
                "sugerencias": [a["titulo"] for a in articulos[:2]],
            }

    # 5) Respuesta determinista
    if intent:
        texto_cruda = intent["respuesta"]
        # El correo se adapta al programa que usa cada alumna
        if intent.get("id") == "correo":
            eleccion = cliente_correo(user_id)
            texto_cruda = RESPUESTAS_CORREO.get(eleccion, texto_cruda)
        texto = formatear(texto_cruda)
        origen = "manual"
    elif articulos:
        partes = ["<p>Esto es lo que he encontrado en el manual:</p>"]
        for art in articulos[:2]:
            partes.append(
                "<div class='caja'><strong>%s</strong><br><span class='cita'>%s</span></div>"
                % (art["titulo"], extraer_resumen(art, 300))
            )
        partes.append("<p>¿Quieres que te lo explique paso a paso? Cuéntame un poco más.</p>")
        texto = "".join(partes)
        origen = "manual"
    else:
        texto = formatear(
            "No tengo una respuesta exacta guardada para eso, pero puedo ayudarte. "
            "Prueba a explicarme qué estás intentando hacer y qué te pasa, con tus palabras. "
            "También puedes buscar la duda en el Manual (el buscador de arriba). "
            "Estos son los atajos que más se usan, por si te sirven:\n"
            "- Ctrl + S → guardar\n"
            "- Ctrl + C / Ctrl + V → copiar y pegar\n"
            "- Ctrl + Z → deshacer\n"
            "- Windows + E → Explorador de archivos\n"
            "- Windows + Shift + S → captura de pantalla"
        )
        origen = "fallback"

    return {
        "texto": texto,
        "origen": origen,
        "articulos": [{"titulo": a["titulo"], "slug": a["slug"], "categoria": a["categoria"]} for a in articulos],
        "atajos": (intent or {}).get("atajos", []),
        "sugerencias": [a["titulo"] for a in articulos[:2]],
    }


def consejo_del_dia(indice=None):
    """Un consejo rotativo estilo 'tip' de Clippy."""
    if indice is None:
        import random

        return random.choice(CONSEJOS_RAPIDOS)
    return CONSEJOS_RAPIDOS[indice % len(CONSEJOS_RAPIDOS)]


def buscar_para_buscador(consulta, limite=20):
    """Búsqueda del manual para la página del manual (devuelve también extractos)."""
    palabras = palabras_significativas(consulta)
    if not palabras:
        return []
    filas = db.q("SELECT * FROM articles ORDER BY categoria, titulo")
    res = []
    for art in filas:
        titulo = normalizar(art["titulo"])
        tags = normalizar(art["tags"])
        cuerpo = normalizar(art["cuerpo"])
        puntos = 0
        for p in palabras:
            if _coincide(titulo, p):
                puntos += 8
            if _coincide(tags, p):
                puntos += 5
            if _coincide(cuerpo, p):
                puntos += 2
        if puntos > 0:
            res.append((puntos, art))
    res.sort(key=lambda x: (-x[0], x[1]["titulo"]))
    return [a for _, a in res[:limite]]
