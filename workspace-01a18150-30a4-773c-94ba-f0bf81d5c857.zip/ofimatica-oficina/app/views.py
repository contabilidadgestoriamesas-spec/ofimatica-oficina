"""Rutas principales para las Albrecht (alumnas) y el manual."""
import json
import random

from flask import (Blueprint, abort, flash, redirect, render_template, request,
                   session, url_for)

from . import db
from .auth import (admin_requerido, hash_password, login_requerido, subir_puntos,
                    usuario_actual, validar_password)
from .assistant import buscar_para_buscador, consejo_del_dia, formatear, resumen_progreso
from .config import PUNTOS_POR_EJERCICIO, PUNTOS_POR_EXAMEN, PUNTOS_POR_LECCION
from .programa import (CLIENTES_CORREO, cliente_de, leccion_visible,
                       preguntas_ejercicio, preguntas_examen)

bp = Blueprint("curso", __name__)


# --------------------------------------------------------------------------- #
# Utilidades
# --------------------------------------------------------------------------- #
def modulos_permitidos(usuario):
    raw = usuario["modulos"] or "todos"
    if raw == "todos":
        return None
    return [x.strip() for x in raw.split(",") if x.strip()]


def obtener_modulos(usuario):
    filas = db.q("SELECT * FROM modules ORDER BY orden")
    permitidos = modulos_permitidos(usuario)
    if permitidos is None:
        return filas
    return [f for f in filas if f["slug"] in permitidos]


def lecciones_del_modulo(usuario, module_id):
    cliente = cliente_de(usuario)
    filas = db.q("SELECT * FROM lessons WHERE module_id = ? ORDER BY orden", (module_id,))
    return [f for f in filas if leccion_visible(f, cliente)]


def estado_modulo(user_id, module_id, cliente="ambos"):
    """Devuelve (completadas, total, porcentaje) contando solo las lecciones visibles."""
    total = db.q1(
        "SELECT COUNT(*) AS n FROM lessons WHERE module_id = ? AND (ruta = 'comun' OR ? = 'ambos' "
        "OR (ruta = 'outlook' AND ? IN ('outlook','ambos')) OR (ruta = 'thunderbird' AND ? IN ('thunderbird','ambos')))",
        (module_id, cliente, cliente, cliente),
    )["n"]
    hechas = db.q1(
        """SELECT COUNT(*) AS n FROM progress p JOIN lessons l ON l.id = p.lesson_id
           WHERE p.user_id = ? AND l.module_id = ? AND p.completado = 1
             AND (l.ruta = 'comun' OR ? = 'ambos'
                  OR (l.ruta = 'outlook' AND ? IN ('outlook','ambos'))
                  OR (l.ruta = 'thunderbird' AND ? IN ('thunderbird','ambos')))""",
        (user_id, module_id, cliente, cliente, cliente),
    )["n"]
    pct = round(100 * hechas / total) if total else 0
    return hechas, total, pct


def progreso_global(user_id):
    total = db.q1("SELECT COUNT(*) AS n FROM lessons")["n"]
    hechas = db.q1(
        "SELECT COUNT(*) AS n FROM progress WHERE user_id = ? AND completado = 1", (user_id,)
    )["n"]
    pct = round(100 * hechas / total) if total else 0
    return hechas, total, pct


def datos_usuario(user_id):
    st = db.q1("SELECT * FROM user_stats WHERE user_id = ?", (user_id,))
    puntos = st["puntos"] if st else 0
    racha = st["racha"] if st else 0
    insignias = json.loads(st["insignias"]) if st and st["insignias"] else []
    return {"puntos": puntos, "racha": racha, "insignias": insignias}


# --------------------------------------------------------------------------- #
# Panel del alumno
# --------------------------------------------------------------------------- #
@bp.route("/")
@login_requerido
def dashboard():
    u = usuario_actual()
    modulos = obtener_modulos(u)
    tarjetas = []
    for m in modulos:
        hechas, total, pct = estado_modulo(u["id"], m["id"], cliente_de(u))
        exam = db.q1("SELECT * FROM exams WHERE module_id = ?", (m["id"],))
        mejor = 0
        aprobado = False
        if exam:
            fila = db.q1(
                """SELECT MAX(score) AS s, MAX(aprobado) AS ap FROM exam_attempts
                   WHERE user_id = ? AND exam_id = ?""",
                (u["id"], exam["id"]),
            )
            mejor = fila["s"] or 0
            aprobado = bool(fila["ap"])
        tarjetas.append({
            "modulo": m, "hechas": hechas, "total": total, "pct": pct,
            "exam": exam, "mejor": mejor, "aprobado": aprobado,
        })

    hechas, total, pct = progreso_global(u["id"])
    stats = datos_usuario(u["id"])
    actividad = db.q(
        "SELECT * FROM activity WHERE user_id = ? ORDER BY id DESC LIMIT 8", (u["id"],)
    )
    siguiente = None
    if modulos:
        marcadores = ",".join("?" * len(modulos))
        cliente = cliente_de(u)
        candidatas = db.q(
            """SELECT l.* FROM lessons l JOIN modules m ON m.id = l.module_id
               LEFT JOIN progress p ON p.lesson_id = l.id AND p.user_id = ?
               WHERE m.slug IN (%s) AND (p.completado IS NULL OR p.completado = 0)
               ORDER BY m.orden, l.orden""" % marcadores,
            [u["id"]] + [m["slug"] for m in modulos],
        )
        siguiente = next((l for l in candidatas if leccion_visible(l, cliente)), None)

    en_curso = db.q(
        """SELECT l.*, m.titulo AS modulo FROM progress p JOIN lessons l ON l.id = p.lesson_id
           JOIN modules m ON m.id = l.module_id
           WHERE p.user_id = ? AND p.en_curso = 1 AND p.completado = 0
           ORDER BY p.updated_at DESC LIMIT 1""",
        (u["id"],),
    )
    if en_curso and not leccion_visible(en_curso[0], cliente_de(u)):
        en_curso = []

    return render_template(
        "dashboard.html",
        tarjetas=tarjetas,
        en_curso=en_curso[0] if en_curso else None,
        stats=stats,
        hechas=hechas, total=total, pct=pct,
        actividad=actividad,
        siguiente=siguiente,
        consejo=consejo_del_dia(),
    )


@bp.route("/modulo/<slug>")
@login_requerido
def modulo(slug):
    u = usuario_actual()
    mod = db.q1("SELECT * FROM modules WHERE slug = ?", (slug,))
    if not mod:
        abort(404)
    permitidos = modulos_permitidos(u)
    if permitidos is not None and slug not in permitidos:
        flash("Ese módulo no está asignado a tu cuenta.", "error")
        return redirect(url_for("curso.dashboard"))
    cliente = cliente_de(u)
    lecciones = lecciones_del_modulo(u, mod["id"])
    estados = {}
    for l in lecciones:
        p = db.q1(
            "SELECT * FROM progress WHERE user_id = ? AND lesson_id = ?", (u["id"], l["id"])
        )
        estados[l["id"]] = p
    ejercicios = db.q(
        "SELECT * FROM exercises WHERE module_id = ? AND publicado = 1 ORDER BY nivel, id",
        (mod["id"],),
    )
    exam = db.q1("SELECT * FROM exams WHERE module_id = ?", (mod["id"],))
    mejor = 0
    aprobado = False
    intentos = 0
    if exam:
        fila = db.q1(
            """SELECT MAX(score) AS s, MAX(aprobado) AS ap, COUNT(*) AS n FROM exam_attempts
               WHERE user_id = ? AND exam_id = ?""",
            (u["id"], exam["id"]),
        )
        mejor = fila["s"] or 0
        aprobado = bool(fila["ap"])
        intentos = fila["n"] or 0
    hechas, total, pct = estado_modulo(u["id"], mod["id"], cliente)
    return render_template(
        "modulo.html", mod=mod, lecciones=lecciones, estados=estados, ejercicios=ejercicios,
        exam=exam, mejor=mejor, aprobado=aprobado, intentos=intentos,
        hechas=hechas, total=total, pct=pct, cliente=cliente,
        clientes_correo=CLIENTES_CORREO,
    )


@bp.route("/leccion/<slug>", methods=["GET", "POST"])
@login_requerido
def leccion(slug):
    u = usuario_actual()
    lec = db.q1("SELECT * FROM lessons WHERE slug = ?", (slug,))
    if not lec:
        abort(404)
    mod = db.q1("SELECT * FROM modules WHERE id = ?", (lec["module_id"],))
    if not leccion_visible(lec, cliente_de(u)):
        flash(
            "Esta lección es del otro programa de correo. Si lo prefieres, puedes cambiar tu elección "
            "en el módulo de correo o en Ajustes.",
            "aviso",
        )
        return redirect(url_for("curso.modulo", slug=mod["slug"]))
    atajos = json.loads(lec["atajos"] or "[]")
    trampas = json.loads(lec["trampas"] or "[]")

    if request.method == "POST":
        accion = request.form.get("accion")
        if accion == "completar":
            db.execute(
                """INSERT INTO progress(user_id, lesson_id, completado, en_curso, score, updated_at)
                   VALUES(?,?,1,0,100,?)
                   ON CONFLICT(user_id, lesson_id) DO UPDATE SET
                     completado = 1, en_curso = 0, score = 100, updated_at = excluded.updated_at""",
                (u["id"], lec["id"], db.ahora()),
            )
            db.execute("DELETE FROM drafts WHERE user_id = ? AND clave = ?",
                       (u["id"], "leccion:%s" % slug))
            existente = db.q1(
                "SELECT * FROM progress WHERE user_id = ? AND lesson_id = ?", (u["id"], lec["id"])
            )
            if not existente or existente["completado"] != 1:
                subir_puntos(u["id"], PUNTOS_POR_LECCION, "lección «%s»" % lec["titulo"])
            db.log(u["id"], u["username"], "leccion", lec["titulo"])
            flash("¡Lección completada! +%d puntos 🎉" % PUNTOS_POR_LECCION, "ok")
        return redirect(url_for("curso.leccion", slug=slug))

    p = db.q1(
        "SELECT * FROM progress WHERE user_id = ? AND lesson_id = ?", (u["id"], lec["id"])
    )
    completada = bool(p and p["completado"])
    anterior = db.q1(
        """SELECT l.* FROM lessons l WHERE l.module_id = ? AND l.orden < ?
           ORDER BY l.orden DESC LIMIT 1""",
        (lec["module_id"], lec["orden"]),
    )
    siguiente = db.q1(
        """SELECT l.* FROM lessons l WHERE l.module_id = ? AND l.orden > ?
           ORDER BY l.orden ASC LIMIT 1""",
        (lec["module_id"], lec["orden"]),
    )
    ejercicio = None
    if lec["practica"]:
        ejercicio = db.q1("SELECT * FROM exercises WHERE slug = ?", (lec["practica"],))
    return render_template(
        "leccion.html", lec=lec, mod=mod, atajos=atajos, trampas=trampas,
        completada=completada, anterior=anterior, siguiente=siguiente, ejercicio=ejercicio,
    )


@bp.route("/chuleta")
@login_requerido
def chuleta():
    """Chuleta de atajos imprimible para pegar junto al monitor."""
    return render_template("chuleta.html")


@bp.route("/mi-progreso")
@login_requerido
def mi_progreso():
    u = usuario_actual()
    hechas, total, pct = progreso_global(u["id"])
    stats = datos_usuario(u["id"])
    modulos = obtener_modulos(u)
    detalle = []
    for m in modulos:
        h, t, p = estado_modulo(u["id"], m["id"], cliente_de(u))
        exam = db.q1("SELECT * FROM exams WHERE module_id = ?", (m["id"],))
        nota = None
        if exam:
            fila = db.q1(
                "SELECT MAX(score) AS s FROM exam_attempts WHERE user_id = ? AND exam_id = ?",
                (u["id"], exam["id"]),
            )
            nota = fila["s"]
        detalle.append({"modulo": m, "hechas": h, "total": t, "pct": p, "nota": nota})
    intentos = db.q(
        """SELECT ea.*, e.titulo FROM exam_attempts ea JOIN exams e ON e.id = ea.exam_id
           WHERE ea.user_id = ? ORDER BY ea.id DESC LIMIT 20""",
        (u["id"],),
    )
    return render_template(
        "progreso.html", hechas=hechas, total=total, pct=pct, stats=stats,
        detalle=detalle, intentos=intentos,
    )


# --------------------------------------------------------------------------- #
# Manual
# --------------------------------------------------------------------------- #
@bp.route("/manual")
@login_requerido
def manual():
    consulta = (request.args.get("q") or "").strip()
    articulos = buscar_para_buscador(consulta, limite=30) if consulta else []
    if not consulta:
        categorias = db.q("SELECT categoria, COUNT(*) AS n FROM articles GROUP BY categoria ORDER BY categoria")
        recientes = db.q("SELECT * FROM articles ORDER BY id LIMIT 8")
    else:
        categorias = []
        recientes = []
    return render_template(
        "manual.html", consulta=consulta, articulos=articulos,
        categorias=categorias, recientes=recientes,
    )


@bp.route("/manual/<slug>")
@login_requerido
def articulo(slug):
    art = db.q1("SELECT * FROM articles WHERE slug = ?", (slug,))
    if not art:
        abort(404)
    otros = db.q(
        "SELECT slug, titulo FROM articles WHERE categoria = ? AND slug != ? LIMIT 6",
        (art["categoria"], slug),
    )
    return render_template("articulo.html", art=art, otros=otros)


# --------------------------------------------------------------------------- #
# Ejercicios
# --------------------------------------------------------------------------- #
@bp.route("/ejercicio/<slug>")
@login_requerido
def ejercicio(slug):
    u = usuario_actual()
    ej = db.q1("SELECT * FROM exercises WHERE slug = ?", (slug,))
    if not ej:
        abort(404)
    cfg = json.loads(ej["config"] or "{}")
    cfg["preguntas"] = preguntas_ejercicio(cfg, cliente_de(u))
    mod = db.q1("SELECT * FROM modules WHERE id = ?", (ej["module_id"],)) if ej["module_id"] else None
    prog = db.q1(
        "SELECT * FROM exercise_progress WHERE user_id = ? AND exercise_id = ?", (u["id"], ej["id"])
    )
    return render_template(
        "ejercicio.html", ej=ej, cfg=cfg, mod=mod, prog=prog,
        tipos_opcion=cfg.get("preguntas", []) if ej["tipo"] == "opcion" else [],
    )


@bp.route("/ejercicios")
@login_requerido
def lista_ejercicios():
    u = usuario_actual()
    filas = db.q(
        """SELECT e.*, m.titulo AS modulo, m.slug AS modulo_slug, m.icono AS icono FROM exercises e
           LEFT JOIN modules m ON m.id = e.module_id
           WHERE e.publicado = 1 ORDER BY m.orden, e.nivel, e.id"""
    )
    progreso = {
        r["exercise_id"]: r
        for r in db.q("SELECT * FROM exercise_progress WHERE user_id = ?", (u["id"],))
    }
    permitidos = modulos_permitidos(u)
    if permitidos is not None:
        filas = [f for f in filas if f["modulo_slug"] is None or f["modulo_slug"] in permitidos]
    return render_template("ejercicios.html", filas=filas, progreso=progreso)


# --------------------------------------------------------------------------- #
# Exámenes
# --------------------------------------------------------------------------- #
@bp.route("/examen/<slug_modulo>")
@login_requerido
def examen(slug_modulo):
    u = usuario_actual()
    mod = db.q1("SELECT * FROM modules WHERE slug = ?", (slug_modulo,))
    if not mod:
        abort(404)
    exam = db.q1("SELECT * FROM exams WHERE module_id = ?", (mod["id"],))
    if not exam:
        flash("Este módulo todavía no tiene examen.", "error")
        return redirect(url_for("curso.modulo", slug=slug_modulo))
    preguntas = preguntas_examen(json.loads(exam["preguntas"] or "[]"),
                                cliente_de(u), mod["slug"] == "correo")
    if not preguntas:
        flash("El examen está vacío.", "error")
        return redirect(url_for("curso.modulo", slug=slug_modulo))
    intentos = db.q1(
        "SELECT COUNT(*) AS n FROM exam_attempts WHERE user_id = ? AND exam_id = ?",
        (u["id"], exam["id"]),
    )["n"]
    return render_template(
        "examen.html", mod=mod, exam=exam, preguntas=preguntas, intentos=intentos,
    )


@bp.route("/examen/<slug_modulo>/corregir", methods=["POST"])
@login_requerido
def corregir_examen(slug_modulo):
    u = usuario_actual()
    mod = db.q1("SELECT * FROM modules WHERE slug = ?", (slug_modulo,))
    exam = db.q1("SELECT * FROM exams WHERE module_id = ?", (mod["id"],))
    preguntas = preguntas_examen(json.loads(exam["preguntas"] or "[]"),
                                cliente_de(u), mod["slug"] == "correo")
    respuestas = []
    acertadas = 0
    detalle = []
    for idx, pr in enumerate(preguntas):
        valor = request.form.get("p%d" % idx)
        elegida = int(valor) if valor not in (None, "") else -1
        ok = elegida == pr["correcta"]
        if ok:
            acertadas += 1
        detalle.append({
            "pregunta": pr["pregunta"],
            "opciones": pr["opciones"],
            "correcta": pr["correcta"],
            "elegida": elegida,
            "explicacion": pr.get("explicacion", ""),
            "ok": ok,
        })
        respuestas.append({"elegida": elegida, "ok": ok})
    total = len(preguntas)
    score = round(100 * acertadas / total) if total else 0
    aprobado = score >= exam["aprobado"]
    db.execute(
        """INSERT INTO exam_attempts(user_id, exam_id, score, aprobado, respuestas, created_at)
           VALUES(?,?,?,?,?,?)""",
        (u["id"], exam["id"], score, 1 if aprobado else 0,
         json.dumps(respuestas, ensure_ascii=False), db.ahora()),
    )
    if aprobado:
        anterior = db.q1(
            "SELECT MAX(score) AS s FROM exam_attempts WHERE user_id = ? AND exam_id = ?",
            (u["id"], exam["id"]),
        )
        if not anterior or score >= (anterior["s"] or 0):
            subir_puntos(u["id"], PUNTOS_POR_EXAMEN, "examen de %s" % mod["titulo"])
    db.log(u["id"], u["username"], "examen", "%s: %d%%" % (mod["titulo"], score))
    return render_template(
        "resultado.html", mod=mod, exam=exam, score=score, aprobado=aprobado, detalle=detalle,
        total=total, acertadas=acertadas,
    )


# --------------------------------------------------------------------------- #
# Configuración del alumno
# --------------------------------------------------------------------------- #
@bp.route("/configuracion", methods=["GET", "POST"])
@login_requerido
def configuracion():
    u = usuario_actual()
    if request.method == "POST":
        accion = request.form.get("accion")
        if accion == "ayudante":
            nuevo = request.form.get("assistant") or "chispita"
            db.execute("UPDATE users SET assistant = ? WHERE id = ?", (nuevo, u["id"]))
            db.log(u["id"], u["username"], "assistant", "Ayudante: %s" % nuevo)
            flash("¡Ayudante cambiado! Ahora te ayuda %s." % nuevo, "ok")
        elif accion == "perfil":
            db.execute(
                "UPDATE users SET nombre = ?, email = ? WHERE id = ?",
                (request.form.get("nombre", "").strip(), request.form.get("email", "").strip(), u["id"]),
            )
            flash("Datos guardados.", "ok")
        elif accion == "email_cliente":
            nuevo = request.form.get("email_client") or "ambos"
            if nuevo not in CLIENTES_CORREO:
                nuevo = "ambos"
            db.execute("UPDATE users SET email_client = ? WHERE id = ?", (nuevo, u["id"]))
            db.log(u["id"], u["username"], "email_client",
                   "Programa de correo: %s" % CLIENTES_CORREO[nuevo])
            flash("Hecho. Tus lecciones de correo se han adaptado a %s."
                  % CLIENTES_CORREO[nuevo].lower(), "ok")
        return redirect(url_for("curso.configuracion"))
    return render_template("configuracion.html", stats=datos_usuario(u["id"]),
                           cliente=cliente_de(u), clientes_correo=CLIENTES_CORREO)


@bp.route("/mi-programa-correo", methods=["POST"])
@login_requerido
def cambiar_programa_correo():
    """Permite cambiar el programa de correo desde el propio módulo."""
    u = usuario_actual()
    nuevo = request.form.get("email_client") or "ambos"
    if nuevo not in CLIENTES_CORREO:
        nuevo = "ambos"
    db.execute("UPDATE users SET email_client = ? WHERE id = ?", (nuevo, u["id"]))
    db.log(u["id"], u["username"], "email_client",
           "Programa de correo: %s" % CLIENTES_CORREO[nuevo])
    destino = request.form.get("volver") or url_for("curso.modulo", slug="correo")
    flash("Tus lecciones de correo son ahora las de %s." % CLIENTES_CORREO[nuevo].lower(), "ok")
    return redirect(destino)


@bp.route("/sw.js")
def service_worker():
    """Sirve el service worker en la raíz para que la app sea instalable en Windows 11."""
    import os

    from flask import send_from_directory

    base = os.path.dirname(os.path.abspath(__file__))
    return send_from_directory(os.path.join(base, "static"), "sw.js",
                               mimetype="application/javascript")


@bp.route("/pista")
@login_requerido
def pista():
    return {"consejo": formatear(consejo_del_dia())}


@bp.route("/pista/<int:indice>")
@login_requerido
def pista_indice(indice):
    return {"consejo": formatear(consejo_del_dia(indice))}


# --------------------------------------------------------------------------- #
# Utilidades para el administrator
# --------------------------------------------------------------------------- #
@bp.route("/admin")
@admin_requerido
def admin_redirect():
    return redirect(url_for("admin.panel"))
