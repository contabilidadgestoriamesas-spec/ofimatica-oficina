"""PARTE 2 · Módulos 5-6: Microsoft Word y Microsoft Excel."""

MODULOS_5_6 = [
    # ------------------------------------------------------------------ #
    {
        "slug": "word",
        "titulo": "Microsoft Word: documentos",
        "nivel": "Básico",
        "icono": "📄",
        "duracion": 110,
        "descripcion": "Crear, maquetar y guardar documentos: texto, formato, tablas, imágenes y PDF.",
        "lecciones": [
            {
                "slug": "word-primera-vez",
                "titulo": "Word por primera vez: la pantalla y la cinta de opciones",
                "objetivo": "Saber dónde está cada cosa en Word y crear un documento nuevo.",
                "duracion": 14,
                "contenido": """
<h2>La cinta de opciones (Ribbon)</h2>
<p>En la parte superior de Word hay una franja con botones agrupados por pestañas:</p>
<ul>
<li><strong>Archivo</strong>: todo lo que tiene que ver con el documento (nuevo, abrir, guardar, imprimir, opciones). Es la única pestaña que cambia la cinta.</li>
<li><strong>Inicio</strong>: fuente, tamaño, negrita, alineación, listas, estilos. Es la que más vas a usar.</li>
<li><strong>Insertar</strong>: imágenes, tablas, formas, encabezados, vínculos.</li>
<li><strong>Diseño</strong>: márgenes, orientación, tema del documento, tamaño de página.</li>
<li><strong>Formato</strong>: estilos, colores de página y ajustes finos.</li>
<li><strong>Referencias</strong>: índice, notas al pie, tabla de contenido.</li>
<li><strong>Revisar</strong>: ortografía, comentarios, comparar documentos.</li>
<li><strong>Vista</strong>: zoom, modo lectura, líneas de la cuadrícula.</li>
</ul>
<div class="caja aviso"><strong>Atajo imprescindible:</strong> <strong>Alt</strong>alone activa las <em>teclas de acceso rápido</em>: aparecen letras y números sobre los botones. Pulsa <strong>Alt</strong> y luego la letra que ves. Por ejemplo <strong>Alt + N</strong> abre <em>Insertar</em>. Es la forma más rápida de working con Word.</div>
<h2>Crear el primer documento</h2>
<ol class="pasos">
<li>Abre Word desde el menú Inicio o con <strong>Windows</strong> y escribe <em>word</em>.</li>
<li>Elige una plantilla en blanco o una de las sugeridas (carta, informe...). Para empezar, elige <strong>Documento en blanco</strong>.</li>
<li>Escribe directamente en la hoja. No hace falta crear nada antes.</li>
<li><strong>Ctrl + S</strong> para guardar. Ponle nombre y elige la carpeta.</li>
</ol>
<h2>La barra de estado (abajo)</h2>
<p>Muestra el número de página, el número de palabras, el idioma y el zoom. El <strong>zoom</strong> se cambia con el botón <em>100 %</em> o con <strong>Ctrl + rueda del ratón</strong>.</p>
<h2>Guardar el primer documento</h2>
<ol class="pasos">
<li>Pulsa <strong>Ctrl + S</strong>.</li>
<li>En el panel izquierdo aparece la información del archivo. Escribe el <strong>nombre</strong>.</li>
<li>Elige la <strong>ubicación</strong> (Documentos, OneDrive, escritorio...).</li>
<li>Haz clic en <strong>Guardar</strong>.</li>
</ol>
""",
                "atajos": [
                    {"teclas": "Ctrl + N", "accion": "Nuevo documento"},
                    {"teclas": "Ctrl + S", "accion": "Guardar"},
                    {"teclas": "Ctrl + O", "accion": "Abrir"},
                    {"teclas": "Ctrl + P", "accion": "Imprimir"},
                    {"teclas": "Ctrl + Z", "accion": "Deshacer"},
                    {"teclas": "Ctrl + Y", "accion": "Rehacer"},
                ],
                "trampas": [
                    "Word abre a veces documentos en «Modo de lectura» o «Modo de compatibilidad». Si no puedes escribir, mira la pestaña Revisar.",
                ],
                "practica": "",
            },
            {
                "slug": "word-formato-texto",
                "titulo": "Dar formato al texto: fuente, tamaño, color y alineación",
                "objetivo": "Que tus documentos se vean profesionales.",
                "duracion": 15,
                "contenido": """
<h2>Los cinco botones que más se usan</h2>
<ul>
<li><strong>Ctrl + N</strong> <em>Negrita</em>: destaca las palabras importantes.</li>
<li><strong>Ctrl + K</strong> <em>Cursiva</em>: títulos,citaciones, marcas.</li>
<li><strong>Ctrl + U</strong> <em>Subrayado</em>: poco usado en documentos formales.</li>
<li><strong>Ctrl + E</strong> <em>Centrar</em>.</li>
<li><strong>Ctrl + J</strong> <em>Justificar</em>.</li>
</ul>
<p>Para alinear a la izquierda: <strong>Ctrl + Q</strong>. Para interlineado: <strong>Ctrl + 5</strong> o el botón del grupo Párrafo.</p>
<h2>Cambiar fuente y tamaño</h2>
<ol class="pasos">
<li>Selecciona el texto (arrastra con el ratón o <strong>Ctrl + A</strong> para todo).</li>
<li>Haz clic en el cuadro de la fuente (por defecto Calibri) y escribe el nombre: Arial, Calibri, Times New Roman, Aptos...</li>
<li>Haz clic en el cuadro del tamaño (11 o 12) y escribe el número.</li>
</ol>
<p>Atajos rápidos de tamaño: <strong>Ctrl + Shift + &gt;</strong> aumenta y <strong>Ctrl + Shift + &lt;</strong> reduce.</p>
<h2>Color, resaltado y estilos</h2>
<ul>
<li><strong>Color de fuente</strong>: la letra <em>A</em> con la barra de color, en el grupo <em>Fuente</em>.</li>
<li><strong>Resaltado</strong>: el marcador, para marcar texto pendiente de revisar.</li>
<li><strong>Estilos</strong>: un título con estilo <em>Título 1</em> se ve igual en todos los documentos y además aparece en el índice. Es la forma "correcta" de dar formato.</li>
</ul>
<h2>Deshacer y rehacer</h2>
<p><strong>Ctrl + Z</strong> deshace la última acción (puedes repetirlo muchas veces). <strong>Ctrl + Y</strong> la rehace. Si has aplicado un formato que no querías, esta es tu salida rápida.</p>
<div class="caja aviso"><strong>El atajo que más se olvida:</strong> <strong>Ctrl + B</strong> pone negrita. Si un día no te hace nada, comprueba que no esté el <em>Bloq Mayús</em> activado o que no estés en otro programa.</div>
<h2>Copiar formato</h2>
<p>Si un párrafo te ha quedado perfecto, selecciónalo y pulsa <strong>Ctrl + Mayús + C</strong> (copiar formato). Luego selecciona el otro texto y pulsa <strong>Ctrl + Mayús + V</strong> (pegar formato).</p>
""",
                "atajos": [
                    {"teclas": "Ctrl + B", "accion": "Negrita"},
                    {"teclas": "Ctrl + K", "accion": "Cursiva"},
                    {"teclas": "Ctrl + U", "accion": "Subrayado"},
                    {"teclas": "Ctrl + E", "accion": "Centrar"},
                    {"teclas": "Ctrl + Q", "accion": "Alinear a la izquierda"},
                    {"teclas": "Ctrl + J", "accion": "Justificar"},
                    {"teclas": "Ctrl + Shift + C", "accion": "Copiar formato"},
                ],
                "trampas": [
                    "Dar formato con el cursor puesto sin seleccionar solo afecta a la palabra donde hagas clic.",
                ],
                "practica": "ej-word-formato",
            },
            {
                "slug": "word-parrafos-listas",
                "titulo": "Párrafos, listas, tabulaciones y saltos",
                "objetivo": "Organizar el texto para que se lea bien.",
                "duracion": 14,
                "contenido": """
<h2>Saltos de línea, de párrafo y de página</h2>
<ul>
<li><strong>Intro</strong>: salto de párrafo (empieza una línea nueva completa).</li>
<li><strong>Mayús + Intro</strong>: salto de línea (sigue en el mismo párrafo). Perfecto para listas de direcciones.</li>
<li><strong>Ctrl + Intro</strong>: salto de página.</li>
<li><strong>Ctrl + Intro</strong> en tablas o al final: insertar una página.</li>
</ul>
<h2>Listas con viñetas y numeradas</h2>
<ol class="pasos">
<li>Selecciona los párrafos que quieres en lista.</li>
<li>Haz clic en el botón de <strong>Viñetas</strong> (•) o en <strong>Numeración</strong> (1. 2. 3.) en la pestaña Inicio.</li>
<li>Para cambiar el estilo, usa la flecha pequeña junto al botón.</li>
</ol>
<p>Atajo: <strong>Ctrl + Shift + L</strong> aplica viñetas rápidamente.</p>
<h2>Cambiar el estilo de una lista</h2>
<p>Si escribes <em>1.</em> y luego un espacio y el texto, Word convierte solo la línea en lista numerada yContinúa con la siguiente al pulsar Intro.</p>
<h2>Tabulaciones y sangrías</h2>
<ul>
<li><strong>Tab</strong>: mueve el cursor al siguiente tabulador (por defecto 1,25 cm).</li>
<li><strong>Mayús + Tab</strong>: reduces la sangría.</li>
<li><strong>Ctrl + Tab</strong>: insertas un tabulador manual.</li>
<li><strong>Ctrl + M</strong>: aumenta la sangría del párrafo.</li>
<li><strong>Ctrl + Mayús + M</strong>: quitas la sangría.</li>
</ul>
<h2>Alineación vertical (acabo de tabular)</h2>
<ol class="pasos">
<li>En la pestaña Inicio, en el grupo Párrafo, haz clic en el botón <em>Alineación</em> (líneas horizontales).</li>
<li>Elige <em>Superior</em>, <em>Centrar verticalmente</em> o <em>Inferior</em>.</li>
<li>Escribe <strong>Ctrl + E</strong> para centrar el texto dentro de esa tabla.</li>
</ol>
<div class="caja aviso"><strong>Un documento bien maquetado:</strong> título con estilo Título 1, apartados con Título 2, texto justificado, interlineado 1,15 y márgenes normales (2,5 cm). Con eso ya pareces profesional.</div>
""",
                "atajos": [
                    {"teclas": "Ctrl + Shift + L", "accion": "Viñetas rápidas"},
                    {"teclas": "Mayús + Intro", "accion": "Salto de línea"},
                    {"teclas": "Ctrl + Intro", "accion": "Salto de página"},
                    {"teclas": "Ctrl + M", "accion": "Aumentar sangría"},
                ],
                "trampas": [
                    "Si pulsas Intro al final de una lista, Word crea un nuevo elemento. Para salir de la lista, pulsa Intro dos veces.",
                ],
                "practica": "",
            },
            {
                "slug": "word-tablas-imagenes",
                "titulo": "Tablas e imágenes en Word",
                "objetivo": "Meter tablas, fotos y logotipos sin que se descentren.",
                "duracion": 15,
                "contenido": """
<h2>Insertar una tabla</h2>
<ol class="pasos">
<li>Haz clic donde debe aparecer la tabla.</li>
<li>Pestaña <strong>Insertar</strong> → <strong>Tabla</strong>.</li>
<li>Elige el número de filas y columnas con el ratón, o usa <em>Insertar tabla…</em> para especificarlo.</li>
<li>La tabla aparece en el cursor. Escribe y usa <strong>Tab</strong> para pasar a la siguiente celda.</li>
</ol>
<p>Atajo rápido: <strong>Ctrl + T</strong> inserta una tabla y te deja elegir el tamaño.</p>
<h2>Dar formato a la tabla</h2>
<ul>
<li>Haz clic dentro de la tabla: aparecen las <strong>Herramientas de tabla</strong> (Diseño y Disposición).</li>
<li><em>Diseño</em>: estilo de la tabla, color de encabezado, bordes, sombreado.</li>
<li><em>Disposición</em>: añadir o quitar filas y columnas, alineación vertical, ajustar ancho.</li>
</ul>
<p>Para mover una tabla: haz clic en la {| } que aparece arriba a la izquierda, o selecciónala y usa la pestaña Disposición.</p>
<h2>Insertar una imagen</h2>
<ol class="pasos">
<li>Clic en el punto exacto donde quieres la imagen.</li>
<li><strong>Insertar → Imágenes → Este dispositivo</strong> y búscala en el Explorador.</li>
<li>Haz clic en <strong>Insertar</strong>.</li>
</ol>
<h2>Envolver el texto</h2>
<p>Con la imagen seleccionada, en <em>Formato de imagen → Disposición → Ajustar texto</em>, elige <strong>Cuadrado</strong> o <strong>Estrecho</strong>. Así el texto rodeará la imagen en lugar de empujarla.</p>
<h2>Alinear y dimensionar</h2>
<ul>
<li><strong>Insertar → Alinear</strong>: izquierda, centro, derecha, superior, medio, inferior.</li>
<li>Arrastra las esquinas redondas para cambiar el tamaño <strong>manteniendo las proporciones</strong> (si pulsas Shift al arrastrar).</li>
</ul>
<div class="caja aviso"><strong>Consejo:</strong> inserta el logo en la <em>cabecera</em> (Insertar → Cabecera) para que se repita en todas las páginas sin tener que copiarlo.</div>
""",
                "atajos": [
                    {"teclas": "Ctrl + T", "accion": "Insertar tabla"},
                    {"teclas": "Mayús + flechas", "accion": "Seleccionar texto"},
                ],
                "trampas": [
                    "Si la imagen se mueve al hacer clic, es que has arrastrado el tirador de la esquina superior izquierda.",
                ],
                "practica": "",
            },
            {
                "slug": "word-guardar-pdf",
                "titulo": "Guardar, exportar a PDF y revisar el documento",
                "objetivo": "Entregar el documento terminado sin sorpresas.",
                "duracion": 14,
                "contenido": """
<h2>Guardar y guardar como</h2>
<p><strong>Ctrl + S</strong> guarda; <strong>F12</strong> (o <em>Archivo → Guardar como</em>) abre el panel para cambiar nombre, carpeta o formato.</p>
<h2>Exportar a PDF</h2>
<ol class="pasos">
<li><strong>Archivo → Guardar como</strong> (o F12).</li>
<li>Elige la carpeta y el nombre.</li>
<li>En <strong>Tipo</strong>, selecciona <strong>PDF (*.pdf)</strong>.</li>
<li>Haz clic en <strong>Guardar</strong>.</li>
</ol>
<p>También puedes usar <strong>Archivo → Exportar → Crear documento PDF/XPS</strong>.</p>
<div class="caja aviso"><strong>Cuándo enviar PDF y cuándo Word:</strong> si el documento lo va a leer o editar otra persona, envíale el <em>.docx</em>. Si lo va a leer e imprimir sin tocarlo, envíale el <em>PDF</em>: todos lo ven igual.</div>
<h2>Revisar ortografía</h2>
<ul>
<li>Las palabras mal escritas salen subrayadas en rojo mientras escribes.</li>
<li><strong>F7</strong>: revisa todo el documento y propose correcciones.</li>
<li>Clic derecho sobre una palabra marcada para ver las sugerencias.</li>
</ul>
<h2>Contar palabras y páginas</h2>
<p>Click en <em>Revisar → Contar palabras</em>. Verás palabras, caracteres, páginas y líneas.</p>
<h2>Imprimir correctamente</h2>
<ol class="pasos">
<li><strong>Ctrl + P</strong> para abrir la vista previa de impresión.</li>
<li>Elige impresora, número de copias, páginas (todas o un rango).</li>
<li>Haz clic en <strong>Imprimir</strong>.</li>
</ol>
<p>En <em>Más ajustes</em> puedes activar <strong>Imprimir en dos caras</strong> (ahorra papel y queda profesional).</p>
<h2>Propiedades del documento</h2>
<p><strong>Archivo → Información → Propiedades</strong>: título, autor, palabras clave. Útil para archivos compartidos, para que nadie lo confunda.</p>
""",
                "atajos": [
                    {"teclas": "Ctrl + S", "accion": "Guardar"},
                    {"teclas": "F12", "accion": "Guardar como / exportar a PDF"},
                    {"teclas": "Ctrl + P", "accion": "Imprimir"},
                    {"teclas": "F7", "accion": "Revisar ortografía"},
                ],
                "trampas": [
                    "Antes de imprimir un documento largo, previsualiza en el panel izquierdo para no gastar 40 páginas por error.",
                ],
                "practica": "",
            },
            {
                "slug": "word-plantillas-cartas",
                "titulo": "Plantillas, cartas y documentos de la oficina",
                "objetivo": "Crear documentos reutilizables para el trabajo diario.",
                "duracion": 13,
                "contenido": """
<h2>Usar una plantilla</h2>
<ol class="pasos">
<li><strong>Archivo → Nuevo</strong>.</li>
<li>En el buscador escribe lo que necesitas: <em>carta</em>, <em>acta</em>, <em>curriculum</em>, <em>informe</em>.</li>
<li>Haz clic en la plantilla para verla en grande.</li>
<li>Haz clic en <strong>Crear</strong>. Se abre una copia que ya puedes personalizar.</li>
</ol>
<h2>Crear tu propia plantilla</h2>
<ol class="pasos">
<li>Diseña el documento con tu logo, tu dirección y tu formato habitual.</li>
<li><strong>Archivo → Guardar como</strong>.</li>
<li>En <strong>Tipo</strong>, elige <strong>Plantilla de Word (*.dotx)</strong>.</li>
<li>Guárdala en <em>Documentos → Plantillas personalizadas</em> o en OneDrive para que esté disponible para el equipo.</li>
</ol>
<div class="caja aviso"><strong>La diferencia entre .docx y .dotx:</strong> el documento (.docx) se abre y se edita; la plantilla (.dotx) se abre y crea una copia nueva, sin riesgo de sobrescribir la original. Por eso las plantillas se guardan con otro formato.</div>
<h2>Correo electrónico desde Word</h2>
<p><strong>Archivo → Compartir → Correo electrónico</strong>: abre Outlook con el documento adjunto. Es el camino más corto para mandar un acta sin salir de Word.</p>
<h2>Combinar correspondencia (para cartas masivas)</h2>
<p>Permite enviar la misma carta a muchas personas con datos diferentes (nombre, dirección). Se usa en <strong>Correspondencia → Iniciar combinación de correspondencia</strong>. Útil para notificaciones, certificados o cartas masivas de la administración.</p>
""",
                "atajos": [
                    {"teclas": "Ctrl + N", "accion": "Nuevo documento"},
                    {"teclas": "Ctrl + Shift + N", "accion": "Documento en blanco"},
                ],
                "trampas": [
                    "Si abres una plantilla y la guardas con Ctrl + S, sobrescribes la plantilla original. Guarda siempre con Ctrl + Shift + S.",
                ],
                "practica": "",
            },
        ],
    },
    # ------------------------------------------------------------------ #
    {
        "slug": "excel",
        "titulo": "Microsoft Excel: hojas de cálculo",
        "nivel": "Básico",
        "icono": "📊",
        "duracion": 140,
        "descripcion": "Datos, fórmulas, formatos, tablas y gráficos: la herramienta que más tiempo te ahorra.",
        "lecciones": [
            {
                "slug": "excel-primera-vez",
                "titulo": "Excel por primera vez: celdas, columnas y hojas",
                "objetivo": "Entender la rejilla de Excel y moverse por ella sin perderse.",
                "duracion": 15,
                "contenido": """
<h2>La anatomía de una hoja</h2>
<ul>
<li><strong>Celda</strong>: cada cajita. Se identifica con una letra (columna) y un número (fila): <strong>B4</strong> es la columna B, fila 4.</li>
<li><strong>Columna</strong>: letras (A, B, C...). <strong>Fila</strong>: números (1, 2, 3...).</li>
<li><strong>Rango</strong>: varias celdas juntas, por ejemplo <code>B2:D7</code>.</li>
<li><strong>Hoja</strong>: cada pestaña de abajo (Hoja1, Hoja2...). Un libro puede tener muchas.</li>
<li><strong>Barra de fórmulas</strong>: arriba, muestra el contenido real de la celda seleccionada.</li>
<li><strong>Cuadro Nombre</strong>: a la izquierda de la barra de fórmulas; escribe ahí <code>B2:D7</code> y Excel selecciona ese rango.</li>
</ul>
<h2>Introducir datos</h2>
<ol class="pasos">
<li>Haz clic en una celda (o navega con las flechas).</li>
<li>Escribe. Para desplazarte a la celda siguiente pulsa <strong>Intro</strong>; para la de la derecha, <strong>Tab</strong>.</li>
<li>Pulsa <strong>Esc</strong> si quieres cancelar lo que estabas escribiendo.</li>
</ol>
<h2>Tipos de dato</h2>
<ul>
<li><strong>Número</strong>: 1500 · <strong>Fecha</strong>: 15/03/2026 · <strong>Texto</strong>: Madrid.</li>
<li>Excel reconoce solo un dato por celda: si escribes «15/3/26 cliente» lo interpreta como texto.</li>
<li>Para fechas: <strong>Ctrl + ;</strong> inserta la fecha de hoy. Para la hora: <strong>Ctrl + Mayús + ;</strong>.</li>
</ul>
<h2>Navegación rápida</h2>
<table class="tabla-atajos">
<tr><th>Atajo</th><th>Para qué</th></tr>
<tr><td><strong>Flechas</strong></td><td>Mover una celda</td></tr>
<tr><td><strong>Ctrl + flechas</strong></td><td>Saltar al final de la zona con datos</td></tr>
<tr><td><strong>Ctrl + Inicio</strong></td><td>Ir a la celda A1</td></tr>
<tr><td><strong>Ctrl + Fin</strong></td><td>Ir a la última celda usada</td></tr>
<tr><td><strong>Ctrl + RePág / AvPág</strong></td><td>Subir/bajar una pantalla</td></tr>
<tr><td><strong>Mayús + flechas</strong></td><td>Seleccionar celdas</td></tr>
<tr><td><strong>Ctrl + A</strong></td><td>Seleccionar todo</td></tr>
</table>
<div class="caja aviso"><strong>Equivocación clásica:</strong> escribir números con unidades («12 clientes») o con el símbolo € dentro de la celda. Excel lo trata como texto y luego no puedes sumar. Escribe solo el número y usa el formato de celda para poner el € o las unidades.</div>
""",
                "atajos": [
                    {"teclas": "Ctrl + Inicio", "accion": "Ir a A1"},
                    {"teclas": "Ctrl + Fin", "accion": "Ir a la última celda"},
                    {"teclas": "Ctrl + ;", "accion": "Insertar la fecha de hoy"},
                    {"teclas": "Ctrl + Mayús + ;", "accion": "Insertar la hora"},
                    {"teclas": "F2", "accion": "Editar la celda"},
                    {"teclas": "Esc", "accion": "Cancelar la edición"},
                ],
                "trampas": [
                    "Escribir «1.234,56» con el teclado español da 1.234 (no 1234.56). Usa el punto decimal: 1234.56.",
                ],
                "practica": "",
            },
            {
                "slug": "excel-seleccionar-editar",
                "titulo": "Seleccionar, editar, deshacer y pegar",
                "objetivo": "Moverte y corregir datos con soltura.",
                "duracion": 13,
                "contenido": """
<h2>Formas de seleccionar</h2>
<ul>
<li><strong>Una celda</strong>: clic.</li>
<li><strong>Un rango</strong>: clic en la primera celda y arrastra hasta la última.</li>
<li><strong>Todo</strong>: <strong>Ctrl + A</strong>.</li>
<li><strong>Una columna</strong>: clic en la letra de la columna. <strong>Una fila</strong>: clic en el número.</li>
<li><strong>Todo el rango de datos</strong>: <strong>Ctrl + *</strong> (tecla del asterisco).</li>
<li><strong>Celdas no contiguas</strong>: mantén pulsado <strong>Ctrl</strong> y ve clic en cada zona.</li>
</ul>
<h2>Editar el contenido de una celda</h2>
<ol class="pasos">
<li>Selecciona la celda y pulsa <strong>F2</strong> (o doble clic dentro).</li>
<li>Edita con las flechas y <strong>Supr</strong>.</li>
<li>Pulsa <strong>Intro</strong> para confirmar o <strong>Esc</strong> para cancelar.</li>
</ol>
<p>Si solo quieres añadir algo al final, pulsa <strong>F2</strong> y luego <strong>Fin</strong>.</p>
<h2>Deshacer y rehacer</h2>
<p><strong>Ctrl + Z</strong> deshace; <strong>Ctrl + Y</strong> rehace. Funciona igual que en Word.</p>
<h2>Cortar, copiar y pegar (con atención)</h2>
<p><strong>Ctrl + C / Ctrl + X / Ctrl + V</strong> funcionan como en cualquier programa. Pero en Excel hay un detalle importante:</p>
<div class="caja aviso"><strong>Pegar especial</strong>: cuando pegas una celda que tenía fórmula, la fórmula se ajusta a la nueva posición (las referencias cambian). A veces no es lo que quieres. Usa <strong>Ctrl + Alt + V</strong> para elegir <em>Valores</em> y pegar solo el resultado, no la fórmula.</div>
<h2>Buscar y reemplazar</h2>
<p><strong>Ctrl + F</strong> para buscar; <strong>Ctrl + H</strong> para reemplazar. En Excel, <em>Reemplazar todo</em> es peligrosísimo: revisa la opción <em>Buscar en: Fórmulas</em> vs <em>Valores</em> antes de darle al botón.</p>
<h2>Insertar y borrar filas y columnas</h2>
<ul>
<li>Clic derecho en el número de la fila → <strong>Insertar</strong> / <strong>Eliminar</strong>.</li>
<li>También con <strong>Mayús + Insertar</strong> (fila) y <strong>Mayús + -</strong> (columna) cuando tengas seleccionada una fila o columna.</li>
</ul>
""",
                "atajos": [
                    {"teclas": "F2", "accion": "Editar celda"},
                    {"teclas": "Ctrl + *", "accion": "Seleccionar la región de datos"},
                    {"teclas": "Ctrl + Alt + V", "accion": "Pegar especial"},
                    {"teclas": "Mayús + Insertar", "accion": "Insertar fila"},
                ],
                "trampas": [
                    "Si borras una fila con Shift + espacio y pulsas Supr, se borra todo el contenido de la fila, no solo lo que ves.",
                ],
                "practica": "",
            },
            {
                "slug": "excel-formulas",
                "titulo": "Fórmulas: SUMA, PROMEDIO y las que más usarás",
                "objetivo": "Hacer que Excel calcule por ti.",
                "duracion": 20,
                "contenido": """
<p>Una fórmula empieza siempre por <strong>=</strong>. Ejemplo: <code>=A1+B2</code></p>
<h2>Las fórmulas imprescindible</h2>
<table class="tabla-atajos">
<tr><th>Fórmula</th><th>Qué hace</th><th>Ejemplo</th></tr>
<tr><td><code>=SUMA(A1:A10)</code></td><td>Suma un rango</td><td><code>=SUMA(B2:B20)</code></td></tr>
<tr><td><code>=PROMEDIO(A1:A10)</code></td><td>Media</td><td><code>=PROMEDIO(C2:C50)</code></td></tr>
<tr><td><code>=MAX()</code> / <code>=MIN()</code></td><td>Máximo y mínimo</td><td><code>=MAX(D2:D30)</code></td></tr>
<tr><td><code>=CONTAR(A1:A10)</code></td><td>Cuántas celdas tienen números</td><td><code>=CONTAR(B2:B100)</code></td></tr>
<tr><td><code>=CONTARA(A1:A10)</code></td><td>Cuántas celdas tienen algo (texto o número)</td><td></td></tr>
<tr><td><code>=SI(prueba; valor_si; valor_no)</code></td><td>Decisión</td><td><code>=SI(E2&gt;1000;"Alto";"Normal")</code></td></tr>
<tr><td><code>=SUMAR.SI(rango;criterio;suma)</code></td><td>Suma solo lo que cumple una condición</td><td><code>=SUMAR.SI(A2:A50;"Madrid";C2:C50)</code></td></tr>
<tr><td><code>=CONTAR.SI(rango;criterio)</code></td><td>Cuenta los que cumplen una condición</td><td><code>=CONTAR.SI(B2:B50;"Sí")</code></td></tr>
<tr><td><code>=HOY()</code></td><td>Fecha de hoy</td><td></td></tr>
<tr><td><code>=REDONDEAR(número;decimales)</code></td><td>Redondea</td><td><code>=REDONDEAR(C2;2)</code></td></tr>
</table>
<h2>Ejemplo paso a paso</h2>
<ol class="pasos">
<li>En la celda <strong>D2</strong> escribe <code>=B2*C2</code> y pulsa Intro.</li>
<li>En <strong>D3</strong> escribe <code>=B3*C3</code>.</li>
<li>Selecciona D2, copia (Ctrl + C), selecciona D3:D50 y pega (Ctrl + V): la fórmula se ajusta sola.</li>
<li>En <strong>D52</strong> escribe <code>=SUMA(D2:D50)</code> para el total.</li>
</ol>
<h2>El separador de argumentos</h2>
<p>En el teclado español, las fórmulas usan <strong>punto y coma</strong> (;) para separar partes: <code>=SI(A1&gt;0;"Positivo";"Negativo")</code>. Si tu Excel usa coma, el separador es la coma. Si te da error al escribir la fórmula, prueba a cambiar el signo.</p>
<h2>Referencias absolutas (el superpoder)</h2>
<p>Si multiplicas muchas filas por una celda fija (un IVA del 21 %, un precio), usa <strong>F4</strong> para fijar la referencia:</p>
<ol class="pasos">
<li>En E2 escribe <code>=D2*$H$1</code> (el 21 % está en H1).</li>
<li>Copia hacia abajo: si no fijaras con $$, el 21 % cambiaría a H2, H3...</li>
</ol>
<h2>Errores típicos</h2>
<ul>
<li><strong>#¡VALOR!</strong>: estás multiplicando un texto por un número.</li>
<li><strong>#¡DIV/0!</strong>: estás dividiendo entre cero o entre una celda vacía.</li>
<li><strong>#¡REF!</strong>: borraste una fila o columna que usaba la fórmula.</li>
<li><strong>#¿NOMBRE?</strong>: escribiste mal el nombre de la función.</li>
</ul>
<div class="caja aviso"><strong>Truco:</strong> cuando no sepas la función que necesitas, escribe <code>=</</code> y pulsa la tecla <strong>F1</strong>: se abre la ayuda de Excel con el buscador de funciones. También sirve <em>Insertar → Función</em>.</div>
""",
                "atajos": [
                    {"teclas": "Alt + =", "accion": "AutoSuma (suma rápida)"},
                    {"teclas": "F4", "accion": "Referencia absoluta ($)"},
                    {"teclas": "Ctrl + `", "accion": "Ver fórmulas en lugar de valores"},
                    {"teclas": "Ctrl + F1", "accion": "Formato de celdas"},
                    {"teclas": "F1", "accion": "Ayuda de funciones"},
                ],
                "trampas": [
                    "El separador de argumentos (coma o punto y coma) depende de la configuración regional de Windows. Si da error, prueba el otro.",
                ],
                "practica": "ej-excel-formulas",
            },
            {
                "slug": "excel-formato",
                "titulo": "Formato de celdas: números, fechas, columnas y colores",
                "objetivo": "Que la hoja se vea limpia y los datos se entiendan.",
                "duracion": 15,
                "contenido": """
<h2>Formato de celdas</h2>
<p>Selecciona las celdas y pulsa <strong>Ctrl + 1</strong> para abrir el cuadro de diálogo <em>Formato de celdas</em>, con 4 pestañas:</p>
<ul>
<li><strong>Número</strong>: decimales, separador de miles, formato de moneda, porcentaje.</li>
<li><strong>Alineación</strong>: horizontal y vertical, orientación del texto, ajuste de celda.</li>
<li><strong>Fuente</strong>: tipo, tamaño, color.</li>
<li><strong>Border</strong>: bordes, color y estilos de línea.</li>
<li><strong>Relleno</strong>: color de fondo de la celda.</li>
</ul>
<h2>Las soluciones rápidas (pestaña Inicio)</h2>
<ul>
<li><strong>€</strong>: formato de moneda. <strong>%</strong>: porcentaje. <strong>Aumentar/decimales</strong>: botones con flechas.</li>
<li><strong>Formato de fecha</strong>: elige el estilo de la fecha.</li>
<li><strong>Ajustar al ancho</strong>: la columna se ajusta al contenido.</li>
<li><strong>Fila / columna de tamaño automático</strong>.</li>
</ul>
<h2>Notas al pie y comentarios</h2>
<ul>
<li><strong>Revisar → Nota al pie</strong>: aclaraciones al pie de la página.</li>
<li><strong>Revisar → Nuevo comentario</strong>: notas para tu equipo, en el margen.</li>
</ul>
<h2>Inmovilizar paneles (esencial con muchas filas)</h2>
<p>Si tienes 500 filas y te pierdes al bajar, inmoviliza la cabecera:</p>
<ol class="pasos">
<li>Colócate en la celda A2 (justo debajo de la fila de títulos).</li>
<li><strong>Vista → Inmovilizar paneles → Inmovilizar paneles</strong>.</li>
</ol>
<p>Ahora la fila 1 siempre visible. Para descongelar: <em>Vista → Inmovilizar paneles → Desinmovilizar paneles</em>.</p>
<h2>Ordenar y filtrar</h2>
<ol class="pasos">
<li>Haz clic dentro de los datos.</li>
<li><strong>Datos → Ordenar y filtrar</strong>.</li>
<li><em>De mayor a menor</em> o <em>De menor a mayor</em> para ordenar por la columna activa. Para filtrar, usa el icono de embudo.</li>
</ol>
<div class="caja aviso"><strong>Antes de ordenar:</strong> si solo has seleccionado algunas celdas, Excel te preguntará si quieres ampliar la selección. Di <strong>Sí</strong> siempre, o los datos se descolocarán.</div>
""",
                "atajos": [
                    {"teclas": "Ctrl + 1", "accion": "Formato de celdas"},
                    {"teclas": "Ctrl + Mayús + L", "accion": "Activar/desactivar filtros"},
                    {"teclas": "Ctrl + B", "accion": "Negrita"},
                ],
                "trampas": [
                    "Si una columna muestra #####, la columna es demasiado estrecha. Amplíala (doble clic en el borde) o cambia el formato.",
                ],
                "practica": "",
            },
            {
                "slug": "excel-tablas-filtros",
                "titulo": "Tablas, filtros y búsqueda en los datos",
                "objetivo": "Trabajar con listas de datos como una profesional.",
                "duracion": 15,
                "contenido": """
<h2>Convertir el rango en tabla</h2>
<ol class="pasos">
<li>Haz clic dentro de los datos.</li>
<li><strong>Insertar → Tabla</strong> (o <strong>Ctrl + T</strong>).</li>
<li>Marca <em>La tabla tiene encabezados</em> y acepta.</li>
</ol>
<p>Ventajas de las tablas de Excel:</p>
<ul>
<li>Filtros y órdenes automáticos.</li>
<li>Bandas de color alternas que facilitation la lectura.</li>
<li>Una fila de <strong>totales</strong> automáticos en la parte de abajo.</li>
<li>Las fórmulas se adaptan solas si añades filas.</li>
</ul>
<h2>Filtrar y buscar</h2>
<ol class="pasos">
<li>En la cabecera de la tabla aparece un icono de embudo.</li>
<li>Haz clic para ver la lista de valores de esa columna y marca los que te interesan.</li>
<li>Para buscar texto: <strong>Ctrl + F</strong> y escribe; para encontrar y reemplazar: <strong>Ctrl + H</strong>.</li>
<li>Para limpiar el filtro: vuelve a pulsar el embudo y desmarca <em>(Todo)</em>.</li>
</ol>
<h2>Quitar duplicados</h2>
<p><strong>Datos → Eliminar duplicados</strong>. Selecciona las columnas donde buscar duplicados y acepta. Antes de hacerlo, haz una copia de seguridad del archivo.</p>
<h2>Texto en mayúsculas</h2>
<p><strong>Fórmula =MAYUSC()</strong> convierte un texto a mayúsculas. Copia la fórmula, pégala en una columna vacía y luego pega solo los valores encima (Ctrl + Alt + V → Valores).</p>
<h2>Buscar en varias hojas</h2>
<p>En la hoja <em>General</em> de Excel, la casilla <strong>Referencia</strong> permite buscar un dato en todo el libro.</p>
<div class="caja aviso"><strong>Consejo de ofimática:</strong> antes de escribir mil datos a mano, pregúntate si puedes <em>importarlos</em>: <strong>Datos → Obtener datos → Desde archivo de texto/CSV</strong>, o simplemente pegar una tabla copiada de una web.</div>
""",
                "atajos": [
                    {"teclas": "Ctrl + T", "accion": "Crear tabla"},
                    {"teclas": "Ctrl + Mayús + L", "accion": "Filtros"},
                    {"teclas": "Ctrl + F", "accion": "Buscar"},
                    {"teclas": "Ctrl + H", "accion": "Buscar y reemplazar"},
                ],
                "trampas": [
                    "Al filtrar, las filas ocultas siguen ahí. Cierra el filtro antes de copiar o imprimir, o imprimirán solo lo visible.",
                ],
                "practica": "",
            },
            {
                "slug": "excel-graficos",
                "titulo": "Gráficos e impresión de hojas",
                "objetivo": "Visualizar los datos y sacarles resultados por pantalla y por papel.",
                "duracion": 16,
                "contenido": """
<h2>Crear un gráfico</h2>
<ol class="pasos">
<li>Selecciona los datos (incluye los títulos de las columnas).</li>
<li><strong>Insertar → Insertar gráfico</strong> (columna, línea, circular...).</li>
<li>Elige el tipo y el subtipo.</li>
<li>En la pestaña <strong>Diseño del gráfico</strong> puedes cambiar colores, título y estilo.</li>
</ol>
<p>Atajo magic: selecciona los datos y pulsa <strong>F11</strong>: se crea el gráfico en una hoja nueva. (Para ponerlo en la misma hoja, elige <em>Mover a la hoja de cálculo</em>.)</p>
<h2>Cambiar los datos del gráfico</h2>
<p>Clic derecho sobre el gráfico → <strong>Seleccionar datos</strong>. Allí puedes cambiar el rango, añadir series o modificar los títulos de la leyenda.</p>
<h2>Elementos del gráfico</h2>
<ul>
<li>Título, subtítulo y etiquetas de los ejes (se activan con el botón <em>+</em> que aparece al seleccionar el gráfico).</li>
<li>Si el eje de los valores muestra 0, 2, 4... en vez de 0, 500, 1000..., hay que widenlo: clic derecho en el eje → <em>Formato de eje</em> → escribe el mínimo en 500.</li>
</ul>
<h2>Imprimir una hoja</h2>
<ol class="pasos">
<li><strong>Archivo → Imprimir</strong> o <strong>Ctrl + P</strong>.</li>
<li>En el panel puedes ver la vista previa y cambiar la orientación a <strong>Horizontal</strong> (para tablas anchas).</li>
<li>Ajusta <em>Escalar</em> para que quepa en una página.</li>
<li>Imprime.</li>
</ol>
<div class="caja aviso"><strong>Antes de imprimir una hoja con 40 columnas</strong>, usa <em>Diseño de página → Imprimir → Áreas de impresión</em> o pon el gráfico en su propia hoja. Imprimir 12 páginas de tabla para nada es la mayor pérdida de tiempo de la ofimática.</div>
<h2>Exportar el gráfico como imagen</h2>
<p>Clic derecho sobre el gráfico → <strong>Guardar como imagen</strong>. Se guarda como PNG para pegarlo en un correo o en un documento.</p>
""",
                "atajos": [
                    {"teclas": "F11", "accion": "Crear un gráfico en una hoja nueva"},
                    {"teclas": "Ctrl + P", "accion": "Imprimir"},
                    {"teclas": "Ctrl + Mayús + L", "accion": "Filtros"},
                ],
                "trampas": [
                    "Si el gráfico sale vacío, es que la selección no incluía las filas de datos o los títulos.",
                ],
                "practica": "",
            },
            {
                "slug": "excel-impresion-pdf",
                "titulo": "Imprimir, exportar a PDF y enviar por correo",
                "objetivo": "Cerrar el ciclo: del dato al documento entregado.",
                "duracion": 14,
                "contenido": """
<h2>Exportar la hoja a PDF</h2>
<ol class="pasos">
<li><strong>Archivo → Guardar como</strong> (o <strong>F12</strong>).</li>
<li>En <strong>Tipo</strong>, elige <strong>PDF (*.pdf)</strong>.</li>
<li>Guarda. Excel exporta la hoja activa (o el área de impresión si la has definido).</li>
</ol>
<p>Alternativa: <strong>Archivo → Exportar → Crear documento PDF/XPS</strong>.</p>
<h2>Imprimir varios folios por hoja</h2>
<p>En <em>Diseño de página → Configurar página</em> o en la vista previa de impresión, puedes cambiar <em>Hojas por página</em> (1, 2, 4...). Ahorra mucho papel con listados largos.</p>
<h2>Enviar por correo directamente desde Excel</h2>
<ol class="pasos">
<li><strong>Archivo → Compartir → Correo electrónico</strong>.</li>
<li>Elige si enviar el archivo adjunto o como enlace.</li>
<li>Se abre Outlook con el mensaje preparado.</li>
</ol>
<div class="caja aviso"><strong>Mejor opción para la oficina:</strong> en lugar de adjuntar 20 archivos cada mes, publica el libro en <strong>OneDrive</strong> y comparte el enlace. Así todos ven la última versión y nadie trabaja sobre una copia antigua.</div>
<h2>Preparar un informe mensual de 5 pasos</h2>
<ol class="pasos">
<li>Los datos de origen en una hoja <em>Datos</em> (copiados de la aplicación de la empresa).</li>
<li>Una hoja <em>Resumen</em> con las fórmulas que usan los datos.</li>
<li>Un gráfico que muestre la evolución.</li>
<li>Formato limpio: títulos en negrita, columnas ajustadas, formato de moneda.</li>
<li>Ctrl + P → vista previa → PDF → enviar.</li>
</ol>
""",
                "atajos": [
                    {"teclas": "F12", "accion": "Guardar como (PDF)"},
                    {"teclas": "Ctrl + P", "accion": "Vista previa de impresión"},
                    {"teclas": "Ctrl + S", "accion": "Guardar el libro"},
                ],
                "trampas": [
                    "Un libro .xlsx con macros no se guarda como .xlsx. Si Excel te avisa, elige un formato compatible o guarda el libro sin macros.",
                ],
                "practica": "",
            },
        ],
    },
]
