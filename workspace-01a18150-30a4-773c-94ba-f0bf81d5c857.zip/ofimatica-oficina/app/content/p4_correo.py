"""PARTE 4 · Módulo 7: Correo electrónico (itinerarios Outlook y Thunderbird).

Cada lección lleva una "ruta":
    comun       -> sirve para las dos
    outlook     -> solo si la alumna usa Outlook
    thunderbird -> solo si la alumna usa Thunderbird
La alumna elige en "Ajustes" o en la página del módulo: Outlook, Thunderbird o ambos.
"""

MODULO_CORREO = {
    "slug": "correo",
    "titulo": "Correo electrónico: Outlook o Thunderbird",
    "nivel": "Básico",
    "icono": "✉️",
    "duracion": 130,
    "descripcion": "Elige tu programa (Outlook, Thunderbird o los dos) y aprende a escribir, adjuntar, buscar y organizar el correo.",
    "lecciones": [
        # ---------------- COMÚN ---------------- #
        {
            "slug": "que-es-el-correo",
            "titulo": "Qué es el correo electrónico (y las palabras raras)",
            "ruta": "comun",
            "objetivo": "Entender las nociones básicas: servidor, IMAP, POP3, SMTP, adjuntos y carpetas.",
            "duracion": 13,
            "contenido": """
<h2>El correo funciona como el correo postal, pero por cable</h2>
<ol class="pasos">
<li>Escribes un mensaje en tu programa de correo (Outlook, Thunderbird...).</li>
<li>Ese programa lo entrega al <strong>servidor de salida</strong> (SMTP) de tu empresa.</li>
<li>El servidor de salida lo reparte al <strong>servidor de entrada</strong> (IMAP) del destinatario.</li>
<li>Cuando el destinatario abre su programa, este <strong>descarga</strong> los mensajes del servidor.</li>
</ol>
<h2>Las tres palabras que te vas a encontrar</h2>
<table class="tabla-atajos">
<tr><th>Palabra</th><th>Qué significa</th><th>En palabras sencillas</th></tr>
<tr><td><strong>SMTP</strong></td><td>Servidor de salida</td><td>«Salida de correo»</td></tr>
<tr><td><strong>IMAP</strong></td><td>Servidor de entrada</td><td>«El buzón está en el servidor; tú ves una copia»</td></tr>
<tr><td><strong>POP3</strong></td><td>Servidor de entrada (antiguo)</td><td>«Te descargas el buzón al ordenador y se vacía del servidor»</td></tr>
</table>
<p>Usa siempre <strong>IMAP</strong>: es el estándar actual y te deja ver el mismo correo desde el
ordenador y desde el móvil. POP3 solo tiene sentido si trabajas siempre en el mismo equipo y sin conexión.</p>
<h2>Outlook o Thunderbird: los dos hacen lo mismo</h2>
<table class="tabla-atajos">
<tr><th></th><th>Outlook</th><th>Thunderbird</th></tr>
<tr><td>Precio</td><td>Incluido con Microsoft 365</td><td>Gratis</td></tr>
<tr><td>Instalación</td><td>Ya suele estar en el equipo</td><td>Hay que instalarlo (una vez)</td></tr>
<tr><td>Con Microsoft 365</td><td>Integrado: correo, calendario, contactos y Teams en uno</td><td>Solo correo</td></tr>
<tr><td>Calendarario y citas</td><td>Sí, completo</td><td>No (hay que usar el calendario de Outlook web o de Teams)</td></tr>
<tr><td>Uso</td><td>Más habitual en oficinas</td><td>Ligero y muy personalizable</td></tr>
</table>
<div class="caja aviso"><strong>Elige en "Ajustes" tu programa de correo</strong> (o hazlo en la página de este módulo).
Así verás solo las lecciones que necesitas... o las dos, si prefieres aprender las dos cosas.</div>
<h2>Las carpetas que you'll ver siempre</h2>
<ul>
<li><strong>Bandeja de entrada</strong>: lo que te llega.</li>
<li><strong>Enviados</strong>: lo que has mandado (útil para recuperar un adjunto).</li>
<li><strong>Borradores</strong>: mensajes a medias (¡se guardan solos!).</li>
<li><strong>Papelera / Elementos eliminados</strong>: lo que has borrado.</li>
<li><strong>Archivados</strong>: lo que has ordenado y guardado.</li>
</ul>
""",
            "atajos": [
                {"teclas": "Ctrl + N", "accion": "Escribir un mensaje nuevo (en los dos programas)"},
                {"teclas": "Ctrl + Enter", "accion": "Enviar el mensaje (en los dos programas)"},
            ],
            "trampas": [
                "Si el mensaje se queda en «Borradores», no se ha enviado: vuelve a abrirlo y pulsa Enviar.",
            ],
            "practica": "",
        },
        {
            "slug": "configurar-cuenta-correo",
            "titulo": "Configurar tu cuenta de correo: los datos que necesitas",
            "ruta": "comun",
            "objetivo": "Configurar el correo en cualquier programa, aunque el servidor no se detecte solo.",
            "duracion": 15,
            "contenido": """
<h2>Los 5 datos que te tiene que dar tu empresa</h2>
<ol class="pasos">
<li><strong>Tu dirección de correo</strong> (nombre@empresa.es).</li>
<li><strong>Tu contraseña</strong> de correo.</li>
<li><strong>Servidor de entrada (IMAP)</strong>: por ejemplo <code>imap.empresa.es</code>.</li>
<li><strong>Servidor de salida (SMTP)</strong>: por ejemplo <code>smtp.empresa.es</code>.</li>
<li><strong>Los puertos y la seguridad</strong> (ver la tabla de abajo).</li>
</ol>
<div class="caja ejemplo"><strong>Tabla de puertos (la de casi todos los servidores):</strong><br>
<strong>IMAP (entrada)</strong> → puerto <strong>993</strong> con <strong>SSL/TLS</strong>.<br>
<strong>IMAP (alternativo)</strong> → puerto <strong>143</strong> con <strong>STARTTLS</strong>.<br>
<strong>SMTP (salida)</strong> → puerto <strong>587</strong> con <strong>STARTTLS</strong>.<br>
<strong>SMTP (alternativo)</strong> → puerto <strong>465</strong> con <strong>SSL/TLS</strong>.<br>
<strong>POP3 (entrada, antiguo)</strong> → puerto <strong>995</strong> con <strong>SSL/TLS</strong>.</div>
<h2>Para Microsoft 365 (si es vuestro caso)</h2>
<table class="tabla-atajos">
<tr><th></th><th>Servidor</th><th>Puerto</th><th>Seguridad</th><th>Autenticación</th></tr>
<tr><td>Entrada (IMAP)</td><td>outlook.office365.com</td><td>993</td><td>SSL/TLS</td><td>OAuth2</td></tr>
<tr><td>Salida (SMTP)</td><td>smtp.office365.com</td><td>587</td><td>STARTTLS</td><td>OAuth2</td></tr>
</table>
<h2>Si el programa no detecta el servidor solo</h2>
<p>Los dos programas (Outlook y Thunderbird) intentan adivinar la configuración a partir del dominio de tu
correo. Si fallan, siempre puedes introducirla a mano: los datos de la tabla de arriba.</p>
<h2>La verificación en dos pasos</h2>
<p>Si vuestra empresa usa doble verificación, puede que el programa pida un código en vez de la contraseña.
En ese caso:</p>
<ul>
<li><strong>Microsoft 365</strong>: se abre una ventana del navegador para que te identifiques (OAuth2). Es normal.</li>
<li>En otros casos, hay que crear una <em>contraseña de aplicación</em>: pídela al servicio de sistemas.</li>
</ul>
<div class="caja aviso"><strong>Nunca pongas la contraseña de tu cuenta personal</strong> en el correo de la oficina
ni al revés. Cada cuenta, su contraseña.</div>
<h2>Comprobación final</h2>
<ol class="pasos">
<li>Envia un correo a ti misma.</li>
<li>Responde a ese correo.</li>
<li>Si las dos cosas funcionan, tu configuración está bien.</li>
</ol>
""",
            "atajos": [
                {"teclas": "Ctrl + Shift + N", "accion": "Nuevo mensaje (Thunderbird: Ctrl + N)"},
            ],
            "trampas": [
                "El puerto 465 usa SSL/TLS directo y el 587 usa STARTTLS. Si eliges el de seguridad equivocado, da error al enviar.",
            ],
            "practica": "",
        },
        # ---------------- OUTLOOK ---------------- #
        {
            "slug": "outlook-la-ventana",
            "titulo": "Outlook: la ventana y las carpetas",
            "ruta": "outlook",
            "objetivo": "Situarte en Outlook y saber qué es cada cosa.",
            "duracion": 14,
            "contenido": """
<h2>Las tres zonas de Outlook</h2>
<ul>
<li><strong>Barra de navegación</strong> (izquierda): Carpetas, Bandeja de entrada, Elementos enviados, Papelera. Si no la ves, activa <em>Ver → Barra de navegación</em>.</li>
<li><strong>Lista de mensajes</strong> (centro): una fila por correo. Columnas: remitente, asunto, fecha y un fragmento del texto.</li>
<li><strong>Lectura</strong> (derecha): el mensaje abierto.</li>
</ul>
<h2>Las carpetas que usarás</h2>
<ul>
<li><strong>Bandeja de entrada</strong>: todo lo que te llega.</li>
<li><strong>Elementos enviados</strong>: lo que has enviado (útil para recuperar un adjunto).</li>
<li><strong>Borradores</strong>: mensajes a medias.</li>
<li><strong>Archivos</strong>: correos ya archivados.</li>
<li><strong>Papelera de reciclaje</strong>: se vacía a los 30 días.</li>
</ul>
<h2>Organizar el correo</h2>
<ul>
<li>Arrastra un correo a una carpeta para archivarlo.</li>
<li>Crea subcarpetas: clic derecho sobre una carpeta → <strong>Nueva carpeta</strong>. Nombra por clientes o por temas.</li>
<li>Marca como <em>Leído</em> con la tecla <strong>U</strong>.</li>
<li>Marca con un <strong>banderín</strong> (Ctrl + 1) para no perderlo.</li>
<li>Archiva con la tecla <strong>E</strong>.</li>
</ul>
<div class="caja aviso"><strong>Regla de oro del correo:</strong> vacía la bandeja de entrada todos los días. Lo que no se resuelve en 48 horas, se archiva. Una bandeja con 400 correos es una bandeja donde no se encuentra nada.</div>
""",
            "atajos": [
                {"teclas": "Ctrl + 1", "accion": "Marcar con banderín"},
                {"teclas": "E", "accion": "Archivar"},
                {"teclas": "U", "accion": "Marcar como leído/no leído"},
                {"teclas": "Ctrl + Shift + N", "accion": "Nuevo mensaje"},
                {"teclas": "Alt + Enter", "accion": "Abrir en una ventana aparte"},
            ],
            "trampas": [
                "La tecla U marca como leído solo con el mensaje seleccionado en la lista, no con la vista de lectura abierta.",
            ],
            "practica": "",
        },
        {
            "slug": "outlook-redactar",
            "titulo": "Outlook: escribir y enviar un correo",
            "ruta": "outlook",
            "objetivo": "Redactar un correo claro, con asunto y adjuntos correctos.",
            "duracion": 16,
            "contenido": """
<h2>Crear un mensaje</h2>
<ol class="pasos">
<li>Pulsa <strong>Nuevo correo</strong> (o <strong>Ctrl + Shift + N</strong>).</li>
<li>Escribe en <strong>Para</strong> la dirección. Si es la primera vez, escribe el nombre y Outlook lo completa.</li>
<li><strong>Asunto</strong>: escribe siempre un asunto claro. Sin asunto, el correo se pierde en la bandeja de la otra persona.</li>
<li>Escribe el cuerpo del mensaje.</li>
<li>Adjunta los archivos (ver la lección siguiente).</li>
<li>Pulsa <strong>Enviar</strong>.</li>
</ol>
<h2>El formato del texto</h2>
<p>En el grupo <em>Fuente</em> de la pestaña <em>Mensaje</em> tienes negrita, cursiva, color, viñetas, niveles y sangrías. Úsalos con moderación: un correo con tres colores y subrayados es difícil de leer.</p>
<h2>Responder, responder a todos y reenviar</h2>
<ul>
<li><strong>Responder</strong> (Ctrl + R): solo a quien te escribió.</li>
<li><strong>Responder a todos</strong> (Ctrl + Mayús + R): a todos los destinatarios. <span class="aviso-inline">Úsalo con mucho cuidado:</span> si hay una lista de correo de toda la empresa, estás escribiendo a 200 personas.</li>
<li><strong>Reenviar</strong> (Ctrl + F): manda el mensaje a otra persona, manteniendo el original como cita.</li>
</ul>
<h2>Responder bien: encima o debajo</h2>
<div class="caja ejemplo"><strong>Responder arriba (recomendado):</strong> escribe tu respuesta en la parte de arriba, y deja el texto original debajo, en gris. Así se lee de un vistazo.<br><strong>Responder abajo:</strong> la respuesta queda al final, debajo de la cita. Es la opción por defecto en Outlook.</div>
<h2>Programar un envío</h2>
<p>Si escribes el correo ahora pero quieres que llegue mañana a las 9:00: <em>Enviar → Programar envío</em>. Ideal para comunicaciones fuera de horario o para discretos recordatorios.</p>
<h2>Deshacer un envío</h2>
<p>Si te has equivocado: <em>Archivo → Información → Deshacer envío</em>. Solo funciona si el mensaje todavía no se ha entregado.</p>
<div class="caja aviso"><strong>Nunca pulses Enviar con un destinatario equivocado</strong> y luego te entre el pánico. Revisa el campo <em>Para</em> una vez más: un clic de más es un desastre.</div>
""",
            "atajos": [
                {"teclas": "Ctrl + Shift + N", "accion": "Nuevo mensaje"},
                {"teclas": "Ctrl + R", "accion": "Responder"},
                {"teclas": "Ctrl + Mayús + R", "accion": "Responder a todos"},
                {"teclas": "Ctrl + F", "accion": "Reenviar"},
                {"teclas": "Ctrl + Enter", "accion": "Enviar el mensaje"},
            ],
            "trampas": [
                "Ctrl + F en Outlook reenvía; para buscar usa Ctrl + K o el cuadro de búsqueda de arriba.",
            ],
            "practica": "ej-correo",
        },
        {
            "slug": "outlook-adjuntos",
            "titulo": "Outlook: adjuntar archivos y el problema de los adjuntos",
            "ruta": "outlook",
            "objetivo": "Adjuntar sin errores y resolver los problemas más comunes.",
            "duracion": 15,
            "contenido": """
<h2>Adjuntar un archivo</h2>
<ol class="pasos">
<li>En el mensaje, ve a <strong>Insertar → Adjuntar</strong> (o el icono del clip 📎).</li>
<li>Elige <strong>Capturas de pantalla</strong>, <strong>Este equipo</strong> o <strong>Archivos recientes</strong>.</li>
<li>Selecciona el archivo y haz clic en <strong>Insertar</strong>.</li>
<li>Verás el nombre del archivo junto al clip: comprueba que es el correcto.</li>
</ol>
<h2>Problemas típicos y su solución</h2>
<table class="tabla-atajos">
<tr><th>Problema</th><th>Solución</th></tr>
<tr><td>«No puedo adjuntar este archivo»</td><td>El archivo está abierto en otro programa. Ciérralo (Word, Excel) y prueba otra vez.</td></tr>
<tr><td>El archivo pesa demasiado</td><td>El límite habitual es de 25 MB. Comprímelo (ZIP) o compártelo como enlace de OneDrive.</td></tr>
<tr><td>«He enviado un archivo, pero no llega»</td><td>Mira la carpeta de Elementos enviados. Si el archivo pesaba mucho, puede que el envío haya fallado en silencio.</td></tr>
<tr><td>El destinatario no lo abre</td><td>Formato incompatible o bloqueado por el servidor. Envíalo en PDF.</td></tr>
<tr><td>Adjunto el archivo equivocado</td><td>No hay forma de recuperarlo si ya se envió. Revisa <em>Enviados</em> y reenvía si hace falta.</td></tr>
</table>
<h2>Compartir un archivo sin adjuntarlo</h2>
<p>Con OneDrive, <em>Insertar → OneDrive</em> te deja compartir el archivo como <strong>enlace</strong>. Ventajas:</p>
<ul>
<li>El archivo puede pesar 2 GB.</li>
<li>La otra persona ve siempre la última versión.</li>
<li>Puedes quitarle el acceso cuando quieras.</li>
</ul>
<div class="caja aviso"><strong>Importante:</strong> si compartes un enlace, quien lo tenga puede verlo. Asegúrate de elegir <em>Personas específicas</em> y no <em>Cualquiera con el enlace</em> para datos de la empresa.</div>
""",
            "atajos": [
                {"teclas": "Ctrl + Enter", "accion": "Enviar"},
                {"teclas": "Ctrl + K", "accion": "Buscar"},
            ],
            "trampas": [
                "Un archivo que ya está abierto en el equipo puede dar error al adjuntarlo.",
            ],
            "practica": "",
        },
        {
            "slug": "outlook-buscar-reglas",
            "titulo": "Outlook: buscar correos, firmas y reglas automáticas",
            "ruta": "outlook",
            "objetivo": "Encontrar cualquier mensaje en segundos y automatizar lo repetitivo.",
            "duracion": 15,
            "contenido": """
<h2>Buscar un correo</h2>
<ol class="pasos">
<li>Escribe en el cuadro de búsqueda de arriba: <em>de:dpto</em>, <em>asunto:factura</em>, <em>adjunto:xlsx</em>.</li>
<li>Pulsa <strong>Ctrl + K</strong> para buscar y luego Intro o clic en el resultado.</li>
</ol>
<p>Ejemplos de búsqueda avanzada:</p>
<ul>
<li><code>from:jefa</code> → correos de una persona.</li>
<li><code>subject:reunión</code> → por asunto.</li>
<li><code>hasattachment:yes</code> → solo los que llevan archivo.</li>
<li><code>received:01/10/2026..31/10/2026</code> → por rango de fechas.</li>
</ul>
<h2>La firma de correo</h2>
<ol class="pasos">
<li><strong>Archivo → Opciones → Correo → Firma</strong>.</li>
<li>Escribe tu firma (nombre, cargo, teléfono, correo de la empresa).</li>
<li>Marca <strong>Usar para todos los mensajes</strong>.</li>
</ol>
<h2>Reglas automáticas (la regla de oro)</h2>
<p>Una regla mueve, reenvía o marca automáticamente los mensajes según un criterio. Ejemplo: «mover a la carpeta Facturas todo lo que venga de la gestoría».</p>
<ol class="pasos">
<li><strong>Archivo → Reglas y alertas → Nueva regla…</strong></li>
<li>Elige <em>Mover los mensajes a otra carpeta</em>.</li>
<li>Define la condición (por ejemplo, «contiene la palabra factura»).</li>
<li>Elige la carpeta de destino y ponle nombre a la regla.</li>
<li>Listo: a partir de ahora se aplica sola a los correos nuevos.</li>
</ol>
<div class="caja aviso"><strong>Recomendación para la oficina:</strong> cread una regla que mueva automáticamente a <em>Facturas</em> los correos con el asunto o los adjuntos correspondientes. Y otra que marque con banderín los mensajes de tu jefa. Ahorra tiempo y evita que nada se pase.</div>
""",
            "atajos": [
                {"teclas": "Ctrl + K", "accion": "Buscar en el correo"},
                {"teclas": "Ctrl + Shift + K", "accion": "Buscar con criterios avanzados"},
            ],
            "trampas": [
                "Las reglas solo se aplican a los correos nuevos, no a los antiguos. Para los antiguos, selecciónalos y usa «Crear regla».",
            ],
            "practica": "",
        },
        # ---------------- THUNDERBIRD ---------------- #
        {
            "slug": "thunderbird-instalar-cuenta",
            "titulo": "Thunderbird: instalarlo y conectar tu cuenta",
            "ruta": "thunderbird",
            "objetivo": "Instalar Thunderbird y dejar tu correo de la empresa funcionando.",
            "duracion": 16,
            "contenido": """
<h2>Qué es Thunderbird</h2>
<p>Es el programa de correo <strong>gratuito</strong> de Mozilla, parecido a Outlook pero más ligero.
Se instala en el equipo una vez y funciona con cualquier cuenta de correo (Microsoft 365, Gmail,
correo de la empresa...).</p>
<h2>Instalarlo</h2>
<ol class="pasos">
<li>Entra en <strong>thunderbird.net</strong> desde el navegador del equipo.</li>
<li>Pulsa el botón de descarga (Windows) y abre el archivo <code>Thunderbird-Setup.exe</code>.</li>
<li>Deja que se instale y, al terminar, se abre solo con la pantalla de <strong>Configurar una cuenta de correo</strong>.</li>
</ol>
<h2>Añadir tu cuenta (forma automática, la más fácil)</h2>
<ol class="pasos">
<li>En la primera pantalla, escribe tu <strong>nombre</strong> (el que verán los demás) y tu <strong>dirección de correo</strong>.</li>
<li>Escribe tu <strong>contraseña</strong> y pulsa <strong>Continuar</strong>.</li>
<li>Thunderbird busca solo la configuración del servidor. Si la encuentra, marca <strong>Hecho</strong> y listo.</li>
</ol>
<h2>Si no la encuentra: configuración manual</h2>
<p>Pulsa <strong>Configurar manualmente</strong> y rellena:</p>
<table class="tabla-atajos">
<tr><th></th><th>Servidor</th><th>Puerto</th><th>Seguridad</th></tr>
<tr><td><strong>Entrada IMAP</strong></td><td>outlook.office365.com<br>(o el que te dé tu empresa)</td><td>993</td><td>SSL/TLS</td></tr>
<tr><td><strong>Salida SMTP</strong></td><td>smtp.office365.com<br>(o el de tu empresa)</td><td>587</td><td>STARTTLS</td></tr>
</table>
<p>El <strong>nombre de usuario</strong> es siempre tu dirección de correo completa.
En <em>Método de autenticación</em>, elige <strong>OAuth2</strong> si aparece; si no, <em>Contraseña normal</em>.</p>
<p>Para Microsoft 365, al pulsar <strong>Hecho</strong> se abrirá una ventana del navegador para que te
identifiques: es normal, no es un error.</p>
<h2>IMAP o POP3</h2>
<ul>
<li><strong>IMAP</strong> (recomendado): los mensajes se quedan en el servidor y los ves iguales desde
el ordenador y desde el móvil.</li>
<li><strong>POP3</strong>: se descargan al ordenador y se vacían del servidor. Solo si trabajas siempre en el mismo equipo.</li>
</ul>
<h2>Comprobación</h2>
<ol class="pasos">
<li>En Thunderbird, arriba a la derecha, pulsa <strong>Obtener mensajes</strong> (o la tecla <strong>F5</strong>).</li>
<li>Si tu bandeja de entrada se llena, la cuenta está bien configurada.</li>
<li>Envia un correo a ti misma y comprueba que sale.</li>
</ol>
<div class="caja aviso"><strong>Si te dice «Thunderbird no ha podido encontrar los ajustes»</strong>, no es un problema:
puedes introducir los datos a mano con la tabla de arriba. Y si tu empresa usa doble verificación, puede que
necesites una «contraseña de aplicación»: pídela al servicio de sistemas.</div>
""",
            "atajos": [
                {"teclas": "F5", "accion": "Obtener los mensajes nuevos"},
                {"teclas": "Mayús + F5", "accion": "Obtener mensajes de todas las cuentas"},
                {"teclas": "Alt + Inicio", "accion": "Volver a la vista de correo"},
            ],
            "trampas": [
                "El nombre de usuario es tu dirección de correo COMPLETA, no solo tu nombre.",
            ],
            "practica": "",
        },
        {
            "slug": "thunderbird-la-ventana",
            "titulo": "Thunderbird: la ventana y las carpetas",
            "ruta": "thunderbird",
            "objetivo": "Moverte por Thunderbird y encontrar cualquier mensaje.",
            "duracion": 14,
            "contenido": """
<h2>Las zonas de la ventana</h2>
<ul>
<li><strong>Barra de carpetas</strong> (izquierda): Bandeja de entrada, Enviados, Borradores, Archivos, Papelera, y las cuentas que tengas configuradas.</li>
<li><strong>Lista de mensajes</strong> (centro): los correos de la carpeta seleccionada, con una barra de búsqueda rápida encima.</li>
<li><strong>Panel de lectura</strong> (derecha): el mensaje abierto.</li>
</ul>
<div class="caja aviso"><strong>Thunderbird ha cambiado de aspecto.</strong> En las versiones 115 y posteriores la
interfaz es la nueva (se llama «Space bar»): las carpetas están a la izquierda, la lista en el centro y el
mensaje a la derecha, con una barra de herramientas arriba. En versiones anteriores se ve la interfaz clásica
de tres columnas. Las dos funcionan igual; lo único que cambia es dónde está cada botón.</div>
<h2>Las carpetas y qué se puede hacer con ellas</h2>
<ul>
<li><strong>Bandeja de entrada</strong>: lo que te llega.</li>
<li><strong>Enviados</strong>: lo que has enviado (aquí recuperas un adjunto que se te olvidó).</li>
<li><strong>Borradores</strong>: Thunderbird guarda solo lo que estás escribiendo. Si se cierra la ventana, el borrador se conserva.</li>
<li><strong>Archivos</strong> y <strong>Papelera</strong>: lo archivado y lo borrado.</li>
<li>Crea tus propias carpetas: clic derecho sobre la cuenta → <strong>Nueva carpeta</strong>.</li>
</ul>
<h2>Acciones rápidas con el mensaje seleccionado</h2>
<ul>
<li><strong>Supr</strong>: mover a la papelera. <strong>Mayús + Supr</strong>: borrar sin pasar por la papelera (cuidado).</li>
<li><strong>E</strong>: archivar. <strong>U</strong>: marcar como leído/no leído. <strong>S</strong>: poner una estrella (para encontrarlo luego).</li>
<li><strong>Ctrl + 1</strong>: marcar con banderín (en Thunderbird, etiqueta).</li>
</ul>
<h2>Ver el mensaje en pantalla completa</h2>
<p>Haz clic en <strong>Mostrar mensaje en una ventana nueva</strong> (o pulsa <strong>Intro</strong> con un
mensaje seleccionado) para leerlo a pantalla completa sin cerrarlo.</p>
""",
            "atajos": [
                {"teclas": "E", "accion": "Archivar"},
                {"teclas": "U", "accion": "Marcar como leído"},
                {"teclas": "S", "accion": "Poner o quitar estrella"},
                {"teclas": "Intro", "accion": "Abrir el mensaje en una ventana"},
                {"teclas": "Supr", "accion": "Mover a la papelera"},
            ],
            "trampas": [
                "Mayús + Supr borra definitivamente: en el correo es mejor usar solo Supr.",
            ],
            "practica": "",
        },
        {
            "slug": "thunderbird-redactar-adjuntar",
            "titulo": "Thunderbird: escribir, adjuntar y responder",
            "ruta": "thunderbird",
            "objetivo": "Redactar correos con adjuntos y firmas, como en Outlook.",
            "duracion": 15,
            "contenido": """
<h2>Escribir un mensaje</h2>
<ol class="pasos">
<li>Pulsa <strong>Escribir</strong> (o <strong>Ctrl + N</strong>).</li>
<li>Se abre una ventana de redacción: arriba los destinatarios, debajo el asunto y luego el cuerpo.</li>
<li>Escribe el texto y pulsa <strong>Enviar</strong> (o <strong>Ctrl + Enter</strong>).</li>
</ol>
<h2>Responder y reenviar</h2>
<ul>
<li><strong>Responder</strong> — <strong>Ctrl + R</strong>: solo a quien te escribió.</li>
<li><strong>Responder a todos</strong> — <strong>Ctrl + Mayús + R</strong>: cuidado, puede haber mucha gente.</li>
<li><strong>Reenviar</strong> — <strong>Ctrl + L</strong>: manda el mensaje a otra persona.</li>
<li><strong>Editar como nuevo</strong> — <strong>Ctrl + E</strong>: parte del texto en un mensaje nuevo, sin adjuntos.</li>
</ul>
<h2>Adjuntar un archivo</h2>
<ol class="pasos">
<li>En la ventana de redacción, pulsa el icono del **clip 📎** (o <em>Mensaje → Adjuntar → Archivo</em>).</li>
<li>Elige <strong>Adjuntar archivos…</strong> y búscalo en el Explorador.</li>
<li>Haz clic en <strong>Adjuntar</strong>. Verás el nombre del archivo junto al icono.</li>
</ol>
<p>Para adjuntar una foto que acabas de hacer: captura con <strong>Windows + Shift + S</strong>, y en la
ventana de redacción arrastra la imagen directamente desde la notificación.</p>
<h2>Tu firma en todos los correos</h2>
<ol class="pasos">
<li>Menú <strong>≡ (hamburguesa)</strong> → <strong>Configuración</strong>.</li>
<li>En la izquierda, <strong>General</strong> → abajo del todo, el campo <strong>Firma</strong>.</li>
<li>Escribe tu firma y marca la casilla para ponerla <strong>en todos los mensajes</strong>.</li>
</ol>
<h2>Texto plano o con formato</h2>
<p>En <em>Preferencias de redacción</em> puedes elegir si los correos nuevos llevan formato (negrita, colores)
o solo texto plano. Para escribir a alguien externo, el texto plano es más seguro.</p>
<div class="caja aviso"><strong>Antes de enviar, comprueba siempre el adjunto.</strong> Es el error más común:
enviar el mensaje con el archivo equivocado o sin el archivo.</div>
""",
            "atajos": [
                {"teclas": "Ctrl + N", "accion": "Nuevo mensaje"},
                {"teclas": "Ctrl + R", "accion": "Responder"},
                {"teclas": "Ctrl + Mayús + R", "accion": "Responder a todos"},
                {"teclas": "Ctrl + L", "accion": "Reenviar"},
                {"teclas": "Ctrl + E", "accion": "Editar como nuevo"},
                {"teclas": "Ctrl + Enter", "accion": "Enviar"},
            ],
            "trampas": [
                "En Thunderbird, «Responder a todos» es Ctrl + Mayús + R y «Reenviar» es Ctrl + L (no Ctrl + F, que es buscar).",
            ],
            "practica": "ej-correo",
        },
        {
            "slug": "thunderbird-organizar",
            "titulo": "Thunderbird: filtros, búsqueda y orden",
            "ruta": "thunderbird",
            "objetivo": "Encontrar cualquier correo en segundos y tener la bandeja limpia.",
            "duracion": 15,
            "contenido": """
<h2>Buscar correos</h2>
<table class="tabla-atajos">
<tr><th>Atajo</th><th>Qué hace</th></tr>
<tr><td><strong>Ctrl + K</strong></td><td>Búsqueda global: busca en TODAS las cuentas y en el texto de los mensajes</td></tr>
<tr><td><strong>Ctrl + Mayús + K</strong></td><td>Filtro rápido: filtra la carpeta que tienes abierta</td></tr>
<tr><td><strong>Ctrl + Mayús + F</strong></td><td>Buscar mensajes (búsqueda avanzada por fechas, remitente...)</td></tr>
<tr><td><strong>Ctrl + F</strong></td><td>Buscar texto dentro del mensaje que estás leyendo</td></tr>
</table>
<div class="caja ejemplo">Ejemplo: escribe <code>factura adjunta</code> en la búsqueda global y
Thunderbird encuentra los correos que hablan de facturas y que llevan un archivo adjunto.</div>
<h2>Los filtros (reglas automáticas)</h2>
<p>Un filtro mueve el correo a una carpeta automáticamente, igual que las reglas de Outlook.</p>
<ol class="pasos">
<li>Menú <strong>≡ (hamburguesa)</strong> → <strong>Herramientas → Filtros de mensajes</strong>.</li>
<li>Pulsa <strong>Nuevo…</strong>.</li>
<li>Elige la condición: <em>El asunto contiene</em>, <em>El remitente es</em>, <em>El cuerpo contiene</em>…</li>
<li>Elige la acción: <em>Mover mensaje a la carpeta X</em>, <em>Marcar como leído</em>, <em>Marcar con estrella</em>…</li>
<li>Elige la carpeta de destino y pulsa <strong>OK</strong>.</li>
</ol>
<p>Ejemplo útil: que todo lo que llegue de la gestoría y tenga «factura» en el asunto caiga solo en la
carpeta <em>Facturas</em>.</p>
<h2>Etiquetas, estrellas y carpetas</h2>
<ul>
<li><strong>Estrella</strong> (tecla <strong>S</strong>): marca los importantes para localizarlos después.</li>
<li><strong>Etiquetas</strong> (Ctrl + 1): como las etiquetas de colores de Gmail.</li>
<li><strong>Carpetas</strong>: arrastra un correo para archivarlo. Arrastra varios a la vez con Ctrl.</li>
</ul>
<h2>Vaciar la bandeja</h2>
<p>Puedes vaciar la papelera con clic derecho sobre la carpeta <em>Papelera</em> → <em>Vaciar papelera</em>.
Hazlo de vez en cuando: la bandeja se llena y cuesta encontrar las cosas.</p>
""",
            "atajos": [
                {"teclas": "Ctrl + K", "accion": "Búsqueda global"},
                {"teclas": "Ctrl + Mayús + K", "accion": "Filtro rápido"},
                {"teclas": "Ctrl + Mayús + F", "accion": "Buscar mensajes (avanzado)"},
                {"teclas": "Ctrl + F", "accion": "Buscar texto en el mensaje"},
                {"teclas": "S", "accion": "Estrella"},
            ],
            "trampas": [
                "Ctrl + F en Thunderbird busca dentro del mensaje abierto; para buscar en toda la cuenta, Ctrl + K.",
            ],
            "practica": "",
        },
    ],
}
