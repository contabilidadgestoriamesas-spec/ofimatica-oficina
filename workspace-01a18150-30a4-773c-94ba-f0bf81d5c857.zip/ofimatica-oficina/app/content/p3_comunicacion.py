"""PARTE 3 · Módulos 8-10: reuniones, impresión y seguridad/IA.

El módulo de correo vive aparte (p4_correo.py) porque tiene dos itinerarios:
Outlook y Thunderbird.
"""

MODULOS_7_10 = [
    # ------------------------------------------------------------------ #
    {
        "slug": "reuniones",
        "titulo": "Teams y reuniones virtuales",
        "nivel": "Básico",
        "icono": "👥",
        "duracion": 70,
        "descripcion": "Unirse a reuniones, compartir pantalla, usar el chat y grabarlas.",
        "lecciones": [
            {
                "slug": "teams-lo-basico",
                "titulo": "Teams: entrar, chats y canales",
                "objetivo": "Moverte por Teams sin bloquearte.",
                "duracion": 15,
                "contenido": """
<h2>Las tres zonas de Teams</h2>
<ul>
<li><strong>Chat</strong>: mensajes directos con una persona o con un grupo.</li>
<li><strong>Equipos</strong>: grupos de trabajo. Cada equipo tiene canales (conversaciones por temas) y archivos compartidos.</li>
<li><strong>Actividad</strong>: todo lo que ha pasado: mensajes, menciones, cambios.</li>
</ul>
<h2>Enviar un mensaje en un chat</h2>
<ol class="pasos">
<li>En <strong>Chat</strong>, elige la persona o el grupo en la lista de la izquierda.</li>
<li>Escribe en el cuadro inferior y pulsa <strong>Intro</strong>.</li>
<li>Si quieres una línea nueva dentro del mismo mensaje: <strong>Mayús + Intro</strong>.</li>
</ol>
<p>Para adjuntar un archivo: el icono del clip 📎. Para enviar una captura: arrastra la imagen desde la carpeta al chat.</p>
<h2>Responder a un mensaje en un canal</h2>
<p>En un canal, escribe en el cuadro inferior. Si quieres responder a alguien concreto, pasa el ratón por su mensaje y pulsa <em>Responder</em> (o escribe «@nombre» para mencionarle y que le llegue un aviso).</p>
<h2>Reacciones y emoji</h2>
<p>Pasa el ratón por un mensaje y haz clic en <em>Añadir reacción</em>: un pulgar arriba o un 👍 rápido sustituye a un «gracias» de 30 segundos.</p>
<div class="caja aviso"><strong>Buena costumbre en el chat:</strong> una línea para la respuesta, sin parpadear de mayúsculas. <strong>NO escribir en mayúsculas</strong>: en el chat se lee como gritar.</div>
<h2>Los canales: la diferencia clave</h2>
<table class="tabla-atajos">
<tr><th></th><th>Chat</th><th>Canal</th></tr>
<tr><td>¿Quién lo ve?</td><td>Solo las personas del chat</td><td>Todo el equipo del canal</td></tr>
<tr><td>¿Sirve para?</td><td>Conversaciones rápidas y privadas</td><td>Información que debe quedar guardada</td></tr>
<tr><td>¿Se archiva?</td><td>Hay que buscarlo</td><td>Sí, queda en el historial</td></tr>
</table>
""",
                "atajos": [
                    {"teclas": "Ctrl + Mayús + M", "accion": "Silenciar el micrófono"},
                    {"teclas": "Ctrl + Mayús + O", "accion": "Activar/desactivar la cámara"},
                    {"teclas": "Ctrl + Mayús + Enter", "accion": "Subir al chat en una reunión"},
                ],
                "trampas": [
                    "En una reunión, pulsar Mayús + Intro en el chat puede abrir en el teclado: usa el botón de enviar.",
                ],
                "practica": "",
            },
            {
                "slug": "teams-reunion",
                "titulo": "Unirse a una reunión y compartir pantalla",
                "objetivo": "Entrar, hablar, ver quién está y compartir una ventana.",
                "duracion": 18,
                "contenido": """
<h2>Unirse a una reunión</h2>
<ol class="pasos">
<li>Abre Teams y busca en <strong>Chat</strong> el mensaje con el enlace de la reunión.</li>
<li>Haz clic en <strong>Unirse</strong>.</li>
<li>Elige si entrar con <strong>cámara</strong> o solo con <strong>micrófono</strong>. Es muy útil hacer una prueba de sonido antes de la reunión.</li>
<li>Cuando estés lista, haz clic en <strong>Unirse ahora</strong>.</li>
</ol>
<h2>Antes de entrar: 3 comprobaciones</h2>
<ul>
<li><strong>Micrófono muted?</strong> El icono del micro con una raya roja significa que está apagado. Pulsa el icono o <strong>Ctrl + Mayús + M</strong>.</li>
<li><strong>Cámara apagada</strong> (icono de cámara tachada): pulsa <strong>Ctrl + Mayús + O</strong> para encenderla.</li>
<li><strong>Auriculares</strong>: conectarlos evita el eco.</li>
</ul>
<h2>La barra de herramientas de la reunión</h2>
<ul>
<li><strong>Micrófono</strong> y <strong>cámara</strong>: encender/apagar.</li>
<li><strong>Compartir pantalla</strong>: el botón con un rectángulo y una flecha.</li>
<li><strong>Participantes</strong>: ver quién está y quién habla (iconos verdes).</li>
<li><strong>Chat de la reunión</strong>: para enviar links y comentarios sin interrumpir.</li>
<li><strong>Reacciones</strong>: el icono de la cara sonriente (¡genial para celebrar en las reuniones!).</li>
<li><strong>Más ⋯</strong>: encuesta, pizarra, notas y subtítulos en vivo.</li>
</ul>
<h2>Compartir pantalla (lo que más se usa)</h2>
<ol class="pasos">
<li>Pulsa <strong>Compartir pantalla</strong>.</li>
<li>Elige <strong>Pantalla completa</strong>, <strong>Ventana</strong> o <strong>Pestaña</strong>.</li>
<li>Elige <strong>Windows + Mayús + S</strong> para seleccionar una zona concreta, o selecciona la ventana que quieras.</li>
<li>Para dejar de compartir: pulsa <strong>Dejar de compartir</strong>.</li>
</ol>
<div class="caja aviso"><strong>Antes de compartir pantalla, cierra todo lo que sea privado:</strong> el correo, el WhatsApp, los documentos de otros compañeros. Todo lo que hay en tu escritorio se ve. Es el error más común y el másarrassing de las reuniones.</div>
<h2>Grabación</h2>
<p>Unirse a la reunión como <strong>presentador</strong> permite grabarla. Queda guardada en la pestaña <em>Reuniones</em> y se puede compartir con un enlace. Avisa siempre a los asistentes antes de grabar.</p>
""",
                "atajos": [
                    {"teclas": "Ctrl + Mayús + M", "accion": "Silenciar el micrófono"},
                    {"teclas": "Ctrl + Mayús + O", "accion": "Encender/apagar la cámara"},
                    {"teclas": "Ctrl + Mayús + Enter", "accion": "Escribir en el chat de la reunión"},
                ],
                "trampas": [
                    "Compartir una pestaña (y no la pantalla) es más seguro: solo se ve lo que estás mostrando.",
                ],
                "practica": "",
            },
            {
                "slug": "reuniones-organizar",
                "titulo": "Organizar una reunión y enviar invitations",
                "objetivo": "Crear una reunión, enviar la invitación y salir de ella bien.",
                "duracion": 15,
                "contenido": """
<h2>Crear una reunión</h2>
<ol class="pasos">
<li>En Teams, arriba a la izquierda, haz clic en <strong>Nuevo → Nueva reunión</strong>.</li>
<li>Escribe el <strong>título</strong> (obligatorio y descriptivo: «Revisión semanal de ventas»).</li>
<li>Elige la <strong>fecha y hora</strong> y la duración.</li>
<li>En <strong>Participantes</strong>, escribe los nombres o correos.</li>
<li>Pulsa <strong>Enviar invitación</strong>.</li>
</ol>
<h2>Agendar una reunión desde el calendario</h2>
<ol class="pasos">
<li>Abre <strong>Calendario</strong> (el icono de la barra lateral izquierda).</li>
<li>Haz clic en el botón <strong>Nuevo evento</strong> o en un hueco libre del calendario.</li>
<li>Completa título, fecha, hora de inicio y fin, participantes.</li>
<li>Pulsa <strong>Guardar</strong>.</li>
</ol>
<h2>El mensaje de invitación</h2>
<p>La invitación incluye un enlace. Si alguien no puede entrar, comprueba que:</p>
<ul>
<li>El enlace esté completo (a veces se parte al copiar).</li>
<li>La persona haya abierto el mensaje en Outlook (no en una vista previa del móvil, donde el enlace puede no funcionar).</li>
</ul>
<h2>Al terminar la reunión</h2>
<p>Pulsa <strong>Salir</strong>. Si eras la organizadora, se abre el resumen de la reunión con la grabación, las transcripción y el chat.</p>
<h2>Reuniones híbridas (presenciales + cámara)</h2>
<p>Si hay gente en la sala y gente en remoto, mejor: pon el móvil o un portátil en la sala y úsalo como cámara del móvil (en Teams: Camera → Phone as camera, si tu versión lo permite). De lo contrario, la mitad de la reunión no oye nada.</p>
<div class="caja aviso"><strong>Reglas para reuniones con cámara:</strong> luz delante (no a la espalda), cámara a la altura de los ojos, fondo despejado y micrófono con auricular. Parece poco, pero cambia por completo cómo te perciben.</div>
""",
                "atajos": [
                    {"teclas": "Ctrl + N", "accion": "Nueva reunión"},
                    {"teclas": "Ctrl + Shift + V", "accion": "Pegar"},
                ],
                "trampas": [
                    "Antes de una reunión, comprueba que el micrófono del PC es el que se usa y no el del ratón.",
                ],
                "practica": "",
            },
        ],
    },
    # ------------------------------------------------------------------ #
    {
        "slug": "imprimir",
        "titulo": "Impresoras, PDF y escáner",
        "nivel": "Básico",
        "icono": "🖨️",
        "duracion": 60,
        "descripcion": "Imprimir sin sustos, digitalizar documentos y trabajar con PDF.",
        "lecciones": [
            {
                "slug": "impresoras-basico",
                "titulo": "Imprimir: elegir impresora, copias y páginas",
                "objetivo": "Imprimir lo correcto en el formato correcto.",
                "duracion": 15,
                "contenido": """
<h2>Imprimir desde cualquier programa</h2>
<ol class="pasos">
<li><strong>Ctrl + P</strong> (en Word, Excel, el navegador... siempre funciona).</li>
<li>En el panel izquierdo aparece la <strong>vista previa</strong>: comprueba qué se va a imprimir.</li>
<li>Elige la <strong>impresora</strong> (si hay varias, está arriba).</li>
<li>Ajusta <strong>copias</strong>, <strong>páginas</strong> (todas, Actual o un rango como 1-3).</li>
<li>Haz clic en <strong>Imprimir</strong>.</li>
</ol>
<h2>Impresoras habituales en la oficina</h2>
<ul>
<li><strong>Impresora de la oficina</strong>: la de red, en la sala común.</li>
<li><strong>PDF (Microsoft Print to PDF)</strong>: en lugar de imprimir en papel, guarda el documento en un archivo PDF en el ordenador.</li>
<li><strong>Microsoft XPS Document Writer</strong>: crea un archivo XPS. Útil si la oficina lo pide.</li>
</ul>
<h2>Ajustes que ahorran mucho</h2>
<ul>
<li><strong>Imprimir en dos caras</strong> (duplex): la mitad de papel.</li>
<li><strong>Copias</strong>: todas en el mismo trabajo (no repitas el trabajo de impresión).</li>
<li><strong>Alleziamiento/Ordenación</strong>: <em>Por copia</em> o <em>Por trabajo</em>.</li>
<li><strong>Escala</strong>: <em>Ajustar a la página</em> para que no salga cortado.</li>
<li><strong>Propiedades de la impresora</strong>: calidad en color o en escala de grises (¡el gris sale mucho más barato!).</li>
</ul>
<div class="caja aviso"><strong>Antes de imprimir 40 páginas, comprueba la vista previa y el número de páginas</strong> en la parte inferior. Es el ahorro de tiempo más fácil del mundo.</div>
<h2>Cuando la impresora no responde</h2>
<ol class="pasos">
<li>Comprueba que tiene papel y que no hay errores en la pantalla de la impresora.</li>
<li><strong>Windows + Impresión de pantalla</strong> no sirve aquí; lo que sirve es hacer un pantallazo del error.</li>
<li>En Windows: <strong>Win + I → Bluetooth y dispositivos → Impresoras y escáneres</strong> y comprueba el estado.</li>
<li>Pide ayuda: casi nunca es cosa tuya. No desmontes la impresora.</li>
</ol>
""",
                "atajos": [
                    {"teclas": "Ctrl + P", "accion": "Imprimir"},
                    {"teclas": "Ctrl + Mayús + P", "accion": "Imprimir en dos caras"},
                ],
                "trampas": [
                    "Dejar la impresora en blanco o en color produce ficheros muy distintos en el presupuesto de la oficina.",
                ],
                "practica": "",
            },
            {
                "slug": "pdf-escaner",
                "titulo": "PDF: ver, combinar y escanear",
                "objetivo": "Manejarte con PDF sin programas extra.",
                "duracion": 15,
                "contenido": """
<h2>Ver un PDF</h2>
<p>Haz doble clic en el archivo. Se abre con el <strong>visor de PDF</strong> de Windows o con Edge, que ya lo incluye. No hace falta instalar nada.</p>
<h2>Las cosas que puedes hacer con un PDF</h2>
<ul>
<li><strong>Buscar</strong>: Ctrl + F.</li>
<li><strong>Zoom</strong>: Ctrl + rueda del ratón.</li>
<li><strong>Marcar y anotar</strong>: los iconos del menú superior (resaltar, dibujar, texto).</li>
<li><strong>Imprimir o guardar como PDF</strong>: Ctrl + P y elige «Microsoft Print to PDF».</li>
<li><strong>Exportar texto</strong>: icono de copia de la barra superior, para pegar el texto en Word.</li>
</ul>
<h2>Escanear un documento a PDF</h2>
<ol class="pasos">
<li><strong>Win + S</strong> → escribe <em>Escáner</em> → abre la app <em>Escáner de Windows</em>.</li>
<li>Pulsa <strong>Agregar</strong> y elige el escáner o la multifunción.</li>
<li>Coloca el documento en el cristal del escáner (cara abajo, esquina arriba a la izquierda).</li>
<li>Elige el tipo de documento (Documento / Foto) y la resolución.</li>
<li>Pulsa <strong>Escanear</strong> y elige dónde guardarlo.</li>
</ol>
<h2>Digitalizar desde el Explorador</h2>
<ol class="pasos">
<li>Clic derecho en un espacio vacío de una carpeta → <strong>Nuevo</strong> → el escáner de tu máquina.</li>
<li>Haz la copia y elige la carpeta de destino.</li>
</ol>
<h2>Unir varios PDF en uno</h2>
<p>Hay dos caminos fáciles:</p>
<ul>
<li><strong>Imprimir y elegir «Microsoft Print to PDF»</strong> varias veces: no sirve.</li>
<li>En el <strong>visor de PDF de Edge/Adobe</strong>: <em>Editar → Organizar páginas</em> (Edge lo permite con un PDF de origen).

En la práctica, para la mayoría de los casos de oficina, lo más rápido es:</li>
</ol>
<ol class="pasos">
<li>Exporta cada documento a PDF (Ctrl + P → Microsoft Print to PDF).</li>
<li>En el Explorador, selecciona los PDFs, clic derecho → <strong>Combinar en un PDF</strong> (Windows 11 ofrece esta opción para varios archivos seleccionados) o <strong>Imprimir</strong> → «Microsoft Print to PDF».</li>
</ol>
<div class="caja aviso"><strong>En Windows 11, seleccionar varios PDFs y usar «Combinar en un PDF» (clic derecho en la selección) es la forma más rápida</strong> de juntar documentos escaneados.</div>
""",
                "atajos": [
                    {"teclas": "Ctrl + F", "accion": "Buscar en el PDF"},
                    {"teclas": "Ctrl + P", "accion": "Imprimir o guardar como PDF"},
                    {"teclas": "Ctrl + rueda", "accion": "Zoom"},
                ],
                "trampas": [
                    "Un PDF escaneado no tiene texto seleccionable. Si necesitas editarlo, exporta a Word desde el visor o vuelve a escanear como «Documento de texto».",
                ],
                "practica": "",
            },
        ],
    },
    # ------------------------------------------------------------------ #
    {
        "slug": "seguridad",
        "titulo": "Seguridad, contraseñas e inteligencia artificial",
        "nivel": "Básico",
        "icono": "🔐",
        "duracion": 80,
        "descripcion": "Proteger la información de la empresa y empezar a usar la IA con criterio.",
        "lecciones": [
            {
                "slug": "contrasenas-seguridad",
                "titulo": "Contraseñas, bloqueos y phishing",
                "objetivo": "Proteger tu acceso y no caer en engaños.",
                "duracion": 18,
                "contenido": """
<h2>Una contraseña buena</h2>
<p>Piensa en una <strong>frase</strong>: cuatro palabras sin relación entre sí. Por ejemplo: <em>bosque-lámpara-27-río</em>.</p>
<ul>
<li>Mínimo 12 caracteres.</li>
<li>Una sola contraseña para cada sitio: si filtran una, se filtran todas.</li>
<li>Nunca la escribas en un papel pegado al monitor ni en un chat.</li>
<li>Usa un gestor de contraseñas (el de Microsoft viene con Windows) para no memorizar 30 claves.</li>
</ul>
<h2>La autenticación en dos pasos</h2>
<p>Windows 11 y Outlook pueden pedir, además de la contraseña, un código que llega al móvil o un código de la app Microsoft Authenticator. Actívalo: aunque alguienRob your password, no podrá entrar sin tu móvil.</p>
<h2>Bloquear la pantalla</h2>
<p>Cuando te levantes de la mesa: <strong>Windows + L</strong>. Cuesta un segundo y evita que cualquiera mire tu correo mientras te tomas un café.</p>
<h2>Reconocer un phishing</h2>
<p>Las estafas llegan por correo, SMS o teléfono. Las señales de alarma:</p>
<ul>
<li>Urgencia: «tu cuenta se bloqueará en 24 horas».</li>
<li>Remitente parecido pero no igual: <em>correo@mic-empresa.com</em> en lugar de <em>correo@miempresa.com</em>.</li>
<li>Enlace que no lleva a donde dice: pasa el ratón por encima para ver la URL real.</li>
<li>Petición de datos que la empresa nunca pide por correo: contraseñas, números de tarjeta, claves.</li>
</ul>
<div class="caja aviso"><strong>Regla de la empresa:</strong> si un correo te pide una contraseña o un pago urgente, no pulses nada. Llama a tu jefa por el teléfono de siempre y pregunta. Ningún servicio legítimo te pide tu contraseña por correo.</div>
<h2>Cuidado con el wifi público y los USB</h2>
<ul>
<li>En cafeterías o hoteles, evita entrar a la intranet de la empresa con la wifi pública.</li>
<li>No uses puertos USB que te ofrezcan personas desconocidas (salvo que sepas exactamente qué estás conectando). Un USB puede instalar programas.</li>
</ul>
<h2>Qué hacer si crees que te han hackeado</h2>
<ol class="pasos">
<li>Cambia la contraseña desde otro equipo.</li>
<li>Avisa al responsable de sistemas de inmediato (no por correo, mejor en persona o por teléfono).</li>
<li>No borres los correos suspects: pueden ser pruebas.</li>
</ol>
""",
                "atajos": [
                    {"teclas": "Windows + L", "accion": "Bloquear el ordenador al salir"},
                    {"teclas": "Ctrl + Alt + Supr", "accion": "Cerrar sesión y bloquear (más rápido)"},
                    {"teclas": "Windows + I", "accion": "Ajustes de Windows"},
                ],
                "trampas": [
                    "La pantalla de bloqueo también muestra notificaciones con el contenido del correo. Ocúltalas si hay información sensible.",
                ],
                "practica": "",
            },
            {
                "slug": "ia-generativa",
                "titulo": "La IA en el trabajo: Copilot y ChatGPT",
                "objetivo": "Usar la IA para ganar tiempo sin meter la pata.",
                "duracion": 20,
                "contenido": """
<h2>Dónde vive la IA en Windows 11</h2>
<ul>
<li><strong>Copilot</strong> (tecla Windows + C): el asistente del sistema, disponible en algunos equipos con Windows 11 y Microsoft 365 Copilot.</li>
<li><strong>Microsoft 365 Copilot</strong>: dentro de Word, Excel, Outlook y Teams. Escribe en el cuadro <em>Copilot</em> o con el botón de la cinta de opciones.</li>
<li><strong>ChatGPT u otras IA</strong>: en el navegador, en su propia web o como aplicación de escritorio.</li>
</ul>
<h2>Lo que la IA hace bien por ti</h2>
<ul>
<li><strong>Redactar y mejorar textos</strong>: «Reescribe este párrafo para que sea más claro y formal».</li>
<li><strong>Resumir</strong>: «Resume este correo en 3 puntos con la acción que tengo que hacer».</li>
<li><strong>Preparar una reunión</strong>: «Crea una agenda de 5 puntos para revisar el informe de ventas».</li>
<li><strong>Explicar fórmulas de Excel</strong>: «¿Cómo hago para contar cuántas ventas superan 1000€?»</li>
<li><strong>Traducir</strong> correos y documentos.</li>
</ul>
<h2>El prompt que funciona (estructura: tarea + contexto + formato)</h2>
<div class="caja ejemplo">Tarea: redactar. Contexto: correo para un cliente que nos ha pedido aplazar una entrega.<br>Formato: 3 frases, tono cordial, con una propuesta de nueva fecha.<br><br>Escribe: «Actúo comorieves de un department comercial de una empresa de material de oficina. Escribe un correo al cliente que ha pedido aplazar la entrega, con tono cordial y profesional, de 3 frases, incluya una propuesta de nueva fecha (15 de noviembre)».</div>
<p>Cuanto más concreto sea el encargo, mejor la respuesta. Y si no te convence, pídele una versión más corta o con otro tono.</p>
<h2>Reglas de oro para usar IA en la oficina</h2>
<div class="caja aviso"><strong>1.</strong> No pegues datos confidenciales, personales o de clientes en una IA que no sea la autorizada por la empresa.<br><strong>2.</strong> Verifica siempre el resultado: las IA pueden inventar datos, cifras y citas.<br><strong>3.</strong> La responsabilidad final del documento es tuya, no de la IA.<br><strong>4.</strong> Usa el texto de la IA como borrador, no como entrega final sin revisar.</div>
<h2>Copilot en Excel (ejemplo rápido)</h2>
<ol class="pasos">
<li>Ten tus datos en una tabla y selecciónalos.</li>
<li>Abre <strong>Copilot</strong> y pide: «Añade una columna con el total de cada línea».</li>
<li>Revisa la fórmula que ha puesto y comprueba los resultados.</li>
</ol>
""",
                "atajos": [
                    {"teclas": "Windows + C", "accion": "Abrir Copilot"},
                    {"teclas": "Ctrl + Alt + M", "accion": "Alternar a la IA en el menú de búsqueda de Windows"},
                ],
                "trampas": [
                    "Una IA puede responder con seguridad cosas que no son ciertas. Comprueba siempre los datos y las cifras.",
                ],
                "practica": "",
            },
            {
                "slug": "copys-de-seguridad",
                "titulo": "Copias de seguridad y trabajo compartido",
                "objetivo": "No perder el trabajo y compartir con el equipo sin errores.",
                "duracion": 16,
                "contenido": """
<h2>La regla 3-2-1</h2>
<p>Para un trabajo importante, ought tener:</p>
<ul>
<li><strong>3</strong> copias de tus datos.</li>
<li>En <strong>2</strong> tipos de soporte (disco del equipo + OneDrive).</li>
<li><strong>1</strong> copia fuera de la oficina (OneDrive en la nube ya lo cumple).</li>
</ul>
<h2>Guardar en la nube de la empresa</h2>
<ol class="pasos">
<li>Abre <strong>OneDrive</strong> desde el icono de la nube en la bandeja (abajo a la derecha).</li>
<li>Si ves el icono con una raya, haz clic y <strong>inicia sesión con tu cuenta de empresa</strong>.</li>
<li>La carpeta <em>OneDrive</em> aparece en el Explorador. Todo lo que guardes allí se sincroniza automáticamente.</li>
</ol>
<h2>Compartir un documento con el equipo</h2>
<ol class="pasos">
<li>Clic derecho en el archivo → <strong>Compartir</strong> (o <strong>Dar acceso a</strong>).</li>
<li>Añade a las personas concretas (o un grupo de la empresa).</li>
<li>Elige el permiso: <em>Puede editar</em> o <em>Puede ver</em>.</li>
</ol>
<div class="caja aviso"><strong>Cuando algo está en «OneDrive - Personal», los compañeros de la oficina NO lo ven.</strong> Necesitas moverlo a <em>OneDrive - Empresa</em> o a una carpeta compartida. Es la causa número uno de «no encuentro el documento que me han enviado».</div>
<h2>Trabajar a la vez en el mismo archivo</h2>
<ul>
<li>Cuando dos personas abren un archivo de OneDrive a la vez, Word/Excel lo avisa y permite trabajar en paralelo.</li>
<li>Si aparece «archivo en uso», alguien lo tiene abierto. Espera a que cierre o abre una copia.</li>
</ul>
<h2>El maletero de Windows</h2>
<p>Si has movido un archivo al escritorio por error, puede que esté en el <em>Papelera de reciclaje</em> o en la carpeta <em>Papelera de reciclaje del sistema</em>. Búscalo.</p>
""",
                "atajos": [
                    {"teclas": "Windows + E", "accion": "Explorador de archivos"},
                    {"teclas": "Ctrl + Mayús + E", "accion": "Ver las carpetas superiores"},
                ],
                "trampas": [
                    "Una carpeta local no se comparte con nadie por OneDrive: hay que mover el archivo a la carpeta de OneDrive.",
                ],
                "practica": "",
            },
            {
                "slug": "resumen-y-plan",
                "titulo": "Tu plan de ofimática de los próximos 30 días",
                "objetivo": "Convertir lo aprendido en un plan que se pueda sostener.",
                "duracion": 12,
                "contenido": """
<h2>Un plan realista</h2>
<table class="tabla-atajos">
<tr><th>Semana</th><th>Objetivo</th><th>Cómo se comprueba</th></tr>
<tr><td>1ª</td><td>Windows, ratón, ventanas, menú Inicio y búsqueda</td><td>Aprieta Windows + E sin mirar y encuentra una carpeta</td></tr>
<tr><td>2ª</td><td>Teclado: Ctrl + C/V/Z/S, Windows + D/L/Shift + S</td><td>Haz un pantallazo y pégalo en un Word</td></tr>
<tr><td>3ª</td><td>Archivos: crear, renombrar, buscar, guardar en OneDrive</td><td>Crea la carpeta «Mi trabajo» y guarda un archivo dentro</td></tr>
<tr><td>4ª</td><td>Word: escribir, dar formato, guardar, PDF</td><td>Redacta una carta de 1 página y expórtala a PDF</td></tr>
<tr><td>5ª</td><td>Excel: datos, SUMA, PROMEDIO, filtro, gráfico</td><td>Haz una tabla de 10 ventas con su total y un gráfico</td></tr>
<tr><td>6ª</td><td>Correo: adjuntar, buscar, reglas</td><td>Envía un correo con un PDF adjunto y crea una regla</td></tr>
<tr><td>7ª</td><td>Teams: reuniones, compartir pantalla</td><td>En una reunión, comparte solo una ventana</td></tr>
<tr><td>8ª</td><td>Impresión, PDF, escáner</td><td>Escanea un documento y lo guarda como PDF</td></tr>
</table>
<h2>El método de los 20 minutos</h2>
<p>Un objetivo realistic: <strong>20 minutos al día</strong>, con una tarea concreta:</p>
<ol class="pasos">
<li>Escoge una tarea real de tu trabajo (no un ejercicio inventado).</li>
<li>Intenta hacerla sin ayuda.</li>
<li>Cuando te atasques, busca en el manual o pregunta a la ayudante.</li>
<li>Repite la tarea. La segunda vez saldrá el doble de rápido.</li>
</ol>
<div class="caja aviso"><strong>El atajo que más tiempo ahorra:</strong> cuando algo no te salga, no repitas el mismo botón 20 veces. Haz un pantallazo, anota qué has hecho y pregunta. Reintentar a ciegas no enseña nada.</div>
<h2>Dónde seguir</h2>
<ul>
<li>El <strong>Manual</strong> de esta aplicación: busca cualquier duda en el buscador.</li>
<li>La <strong>ayudante</strong> de la esquina inferior derecha: escribe tu duda tal cual la formularías a una compañera.</li>
<li>La <strong>biblioteca de atajos</strong>: una hoja con los 20 atajos que más usas. Pégala junto al monitor el primer mes.</li>
</ul>
""",
                "atajos": [
                    {"teclas": "Windows + D", "accion": "Volver al escritorio y empezar la práctica"},
                ],
                "trampas": [
                    "No intentes aprenderlo todo de golpe. Es mejor 20 minutos todos los días que 3 horas el domingo.",
                ],
                "practica": "",
            },
        ],
    },
]
