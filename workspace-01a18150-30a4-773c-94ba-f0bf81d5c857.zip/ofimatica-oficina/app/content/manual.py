"""Manual de consulta: artículos del knowledge base (buscable por el alumno y por la IA)."""

CATEGORIAS = [
    "Windows 11",
    "Teclado y atajos",
    "Archivos y carpetas",
    "Word",
    "Excel",
    "Correo electrónico",
    "Impresión y PDF",
    "Seguridad",
    "Nube y equipo",
    "Inteligencia artificial",
]

MANUAL = [
    # ----------------------------------------------------------------- #
    {
        "titulo": "Hacer una captura de pantalla en Windows 11",
        "categoria": "Windows 11",
        "tags": "captura, pantallazo, pantalla, recortes, snipping, print screen, imagen",
        "fuente": "https://support.microsoft.com/es-es/windows/use-la-herramienta-recortes-para-capturar-pantallas-9e40415d-f1e3-4b32-9a9a-8b4d9d9c2a6c",
        "cuerpo": """
<p>Windows 11 tiene varias formas de capturar la pantalla. Elige la que necesites según lo que quieras mostrar.</p>
<h3>Capturar una zona concreta (la más usada)</h3>
<ol>
<li>Pulsa <strong>Windows + Shift + S</strong>.</li>
<li>Elige el modo: rectangular (por defecto), forma libre, ventana o pantalla completa.</li>
<li>Arrastra el ratón para marcar la zona.</li>
<li>La captura se copia al portapapeles y sale un aviso abajo a la derecha. Haz clic en el aviso para abrirla en Recortes y poder anotarla.</li>
</ol>
<h3>Capturar toda la pantalla y guardarla como archivo</h3>
<p>Pulsa <strong>Windows + Impresión de pantalla</strong>. El archivo se guarda solo en <em>Imágenes → Capturas de pantalla (Screenshots)</em>.</p>
<h3>Capturar toda la pantalla al portapapeles</h3>
<p>Pulsa <strong>Impresión de pantalla</strong>. En las versiones recientes de Windows 11, esta tecla abre directamente la herramienta Recortes; para el comportamiento antiguo ve a <em>Ajustes → Accesibilidad → Teclado</em> y desactiva <em>Usar la tecla de impresión de pantalla para abrir la captura de pantalla</em>.</p>
<h3>Capturar solo la ventana que tienes abierta</h3>
<p>Pulsa <strong>Alt + Impresión de pantalla</strong>. Se copia al portapapeles la ventana activa, sin el resto del escritorio.</p>
<h3>Grabar un vídeo de la pantalla</h3>
<p>Pulsa <strong>Windows + Shift + R</strong> o abre <em>Recortes → Grabar vídeo</em>. El archivo se guarda en <em>Vídeos → Capturas de pantalla</em>.</p>
<h3>Dónde ha quedado la captura</h3>
<ul>
<li><strong>Portapapeles</strong>: para pegarla con Ctrl + V en un correo, un Word o un chat.</li>
<li><strong>Imágenes → Screenshots</strong>: archivos PNG guardados automáticamente.</li>
<li><strong>Recortes</strong>: si necesitas recortar, anotar con flechas o cifrar un dato.</li>
</ul>
<div class="caja aviso"><strong>Consejo:</strong> antes de capturar, ten en cuenta si aparece información confidencial o datos de compañeros. Si es así, recorta la imagen o difumina la zona con el botón de «efecto Pixelar» de Recortes.</div>
""",
    },
    {
        "titulo": "Los 15 atajos de Windows 11 imprescindibles",
        "categoria": "Teclado y atajos",
        "tags": "atajos, shortcuts, windows, teclas, combinadas, rapido",
        "fuente": "https://support.microsoft.com/es-es/windows/teclado-teclas-de-accceso-rapido-de-windows-3cc4d6fe-63a3-4d4a-bd5d-97a46e04d1f6",
        "cuerpo": """
<table>
<tr><th>Atajo</th><th>Acción</th></tr>
<tr><td><strong>Windows</strong></td><td>Abre o cierra el menú Inicio</td></tr>
<tr><td><strong>Windows + E</strong></td><td>Abre el Explorador de archivos</td></tr>
<tr><td><strong>Windows + D</strong></td><td>Muestra el escritorio (y lo vuelve a ocultar)</td></tr>
<tr><td><strong>Windows + L</strong></td><td>Bloquea el ordenador</td></tr>
<tr><td><strong>Windows + I</strong></td><td>Abre los Ajustes de Windows</td></tr>
<tr><td><strong>Windows + R</strong></td><td>Abre la ventana Ejecutar</td></tr>
<tr><td><strong>Windows + S</strong></td><td>Abre la búsqueda</td></tr>
<tr><td><strong>Windows + X</strong></td><td>Menú de administrador (sistema)</td></tr>
<tr><td><strong>Windows + V</strong></td><td>Historial del portapapeles</td></tr>
<tr><td><strong>Windows + Shift + S</strong></td><td>Captura de una zona</td></tr>
<tr><td><strong>Windows + Impresión de pantalla</strong></td><td>Captura completa guardada en Imágenes</td></tr>
<tr><td><strong>Windows + P</strong></td><td>Proyectar o duplicar pantalla</td></tr>
<tr><td><strong>Windows + flecha ← / →</strong></td><td>Coloca la ventana a la izquierda o a la derecha</td></tr>
<tr><td><strong>Windows + Z</strong></td><td>Diseños de acoplamiento (dividir pantalla)</td></tr>
<tr><td><strong>Alt + Tab</strong></td><td>Cambia de ventana abierta</td></tr>
</table>
<h3>Atajos universales de cualquier programa</h3>
<table>
<tr><th>Atajo</th><th>Acción</th></tr>
<tr><td><strong>Ctrl + C</strong></td><td>Copiar</td></tr>
<tr><td><strong>Ctrl + X</strong></td><td>Cortar</td></tr>
<tr><td><strong>Ctrl + V</strong></td><td>Pegar</td></tr>
<tr><td><strong>Ctrl + Z</strong></td><td>Deshacer</td></tr>
<tr><td><strong>Ctrl + Y</strong></td><td>Rehacer</td></tr>
<tr><td><strong>Ctrl + A</strong></td><td>Seleccionar todo</td></tr>
<tr><td><strong>Ctrl + S</strong></td><td>Guardar</td></tr>
<tr><td><strong>Ctrl + F</strong></td><td>Buscar</td></tr>
<tr><td><strong>Ctrl + H</strong></td><td>Buscar y reemplazar</td></tr>
<tr><td><strong>Ctrl + P</strong></td><td>Imprimir</td></tr>
<tr><td><strong>Esc</strong></td><td>Cancelar o cerrar</td></tr>
</table>
""",
    },
    {
        "titulo": "La tecla Windows y el menú Inicio",
        "categoria": "Teclado y atajos",
        "tags": "tecla windows, inicio, menu, buscar, atajos",
        "fuente": "",
        "cuerpo": """
<p>La <strong>tecla Windows</strong> es la tecla con el dibujito de una ventana cuadrada, situada entre Ctrl y Alt. Es la tecla más importante de Windows 11.</p>
<h3>Qué hace</h3>
<ul>
<li> Pulsada sola: abre el menú Inicio. Si el menú ya está abierto, lo cierra.</li>
<li>Con <strong>Ctrl</strong>: abre el menú Inicio directamente (comodidad).</li>
<li>Con <strong>Esc</strong>: abre el menú Inicio.</li>
</ul>
<h3>El menú Inicio por zonas</h3>
<ol>
<li><strong>Botón Inicio</strong> (centro de la barra de tareas).</li>
<li><strong>Anclados</strong>: programas que has fijado tú.</li>
<li><strong>Recomendados</strong>: archivos recientes.</li>
<li><strong>Todas las aplicaciones</strong>: lista completa, ordenada por letra.</li>
<li><strong>Perfil y cuenta</strong> (esquina superior izquierda): cambiar contraseña, cerrar sesión, ajustes de cuenta.</li>
<li><strong>Botón de encendido</strong> (esquina inferior izquierda): apagar, reiniciar, suspender.</li>
</ol>
<div class="caja aviso"><strong>Para las que no saben dónde está el botón de encendido:</strong> Inicio → botón de energía (abajo a la izquierda) → <em>Apagar</em>. Y para reiniciar, <em>Reiniciar</em>. Si el equipo está congelado, pulsa <strong>Ctrl + Alt + Supr</strong>.</div>
""",
    },
    {
        "titulo": "Cambiar, crear y personalizar la contraseña de Windows",
        "categoria": "Seguridad",
        "tags": "contraseña, password, cambiar clave, inicio de sesion, usuario",
        "fuente": "",
        "cuerpo": """
<h3>Cambiar tu contraseña de Windows</h3>
<ol>
<li>Pulsa <strong>Windows + I</strong> para abrir Ajustes.</li>
<li>Ve a <em>Cuenta → Inicio de sesión</em> (o <em>Cuentas → Opciones de inicio de sesión</em>).</li>
<li>En <em>Contraseña</em>, pulsa <strong>Cambiar</strong>.</li>
<li>Escribe la contraseña actual, la nueva y repítela.</li>
</ol>
<h3>Crear una contraseña PIN (más cómoda para el móvil)</h3>
<p>En <em>Inicio de sesión → PIN de Windows</em> puedes crear un PIN numérico. Se combina con el inicio de sesión de la cuenta y es más rápido de escribir. Ojo: el PIN protege el equipo, la contraseña de la cuenta es la que protege tus datos en la nube.</p>
<h3>Si has olvidado la contraseña</h3>
<ol>
<li>En la pantalla de inicio de sesión, haz clic en <em>Opciones de cuenta</em> → <em>Iniciar sesión con una cuenta de empresa</em> o escribe <em>Microsoft</em> en el usuario.</li>
<li>Si tienes otro equipo con tu cuenta iniciada, puedes cambiar la contraseña desde <em>account.microsoft.com</em>.</li>
<li>Si no, hay que llamar al servicio de sistemas de la empresa. No hay forma de recuperar una contraseña de Windows sin esa cuenta.</li>
</ol>
<div class="caja aviso"><strong>Requisitos de una contraseña aceptable en esta aplicación:</strong> mínimo 6 caracteres, al menos una letra y al menos un número.</div>
""",
    },
    {
        "titulo": "No encuentro un archivo: cómo buscarlo y recuperarlo",
        "categoria": "Archivos y carpetas",
        "tags": "archivo, no encuentro, perdido, buscar, papelera, restaurar",
        "fuente": "",
        "cuerpo": """
<p>Es el problema más frecuente. Sigue este orden:</p>
<ol>
<li><strong>Comprueba dónde lo guardaste.</strong> En Word o Excel, el documento aparece en <em>Archivo → Información</em> o en <em>Archivo → Recientes</em>, con la ruta completa.</li>
<li><strong>Busca en el Explorador</strong> con <strong>Ctrl + F</strong>. Escribe parte del nombre (no el nombre entero).</li>
<li><strong>Busca en todo el equipo</strong>: en el Explorador, clic en <em>Este equipo</em> y busca ahí (es más lento pero completo).</li>
<li><strong>Busca por contenido</strong>: en el menú de búsqueda de la esquina superior derecha del Explorador, elige <em>Buscar en el contenido</em> y pon una frase que recuerdes del documento.</li>
<li><strong>Revisa la Papelera de reciclaje</strong>: puede que lo borraras sin querer. Selecciona el archivo y pulsa <em>Restaurar</em>.</li>
<li><strong>Revisa OneDrive</strong>: si trabajabas en la nube, el archivo está en la nube, no en el ordenador.</li>
<li><strong>Busca por fecha de modificación</strong>: en la vista de detalles, ordena por «Fecha de modificación» para ver lo último que tocaste.</li>
</ol>
<h3>Si el archivo tiene el candado</h3>
<p>Una carpeta de la red puede pedirte usuario y contraseña: es normal. Si no te la recuerdan, pídesela a tu responsable. <strong>Nunca pruebes contraseñas de otras personas.</strong></p>
<div class="caja aviso"><strong>Si acabas de guardarlo y no lo ves</strong>, ten en cuenta que a veces el archivo se guarda en la carpeta <em>OneDrive</em> en lugar de <em>Este equipo</em>. Mira la ruta en la barra del título del programa.</div>
""",
    },
    {
        "titulo": "La Papelera de reciclaje: recuperar y vaciar",
        "categoria": "Archivos y carpetas",
        "tags": "papelera, reciclaje, borrar, eliminar, restaurar, vaciar",
        "fuente": "",
        "cuerpo": """
<p>Cuando borras un archivo con la tecla <strong>Supr</strong>, no desaparece: va a la <strong>Papelera de reciclaje</strong>.</p>
<h3>Restaurar un archivo</h3>
<ol>
<li>Abre el Explorador (Windows + E).</li>
<li>Clic en <em>Papelera de reciclaje</em> en el panel izquierdo.</li>
<li>Selecciona el archivo y pulsa <em>Restaurar</em> (o clic derecho → Restaurar).</li>
</ol>
<h3>Vaciar la papelera</h3>
<p>En la parte superior de la papelera, <em>Vaciar la papelera de reciclaje</em>. Esto borra para siempre: no hay vuelta atrás. Hazlo solo cuando tengas la seguridad de que no necesitas nada de lo que hay dentro.</p>
<div class="caja aviso"><strong>Atajo peligroso:</strong> <strong>Mayús + Supr</strong> borra el archivo directamente, sin pasar por la papelera. Úsalo solo con archivos que acabas de crear y de los que estás segura. Para el trabajo diario, usa siempre <strong>Supr</strong>.</div>
<h3>Si la papelera aparece vacía</h3>
<ul>
<li>La papelera se vacía automáticamente a los <strong>30 días</strong>.</li>
<li>Puede que estés viendo la papelera de otro disco o de otra cuenta de Windows.</li>
<li>Si has borrado un archivo de la red, es posible que no pase por tu papelera.</li>
</ul>
""",
    },
    {
        "titulo": "Guardar documentos: Ctrl+S, Guardar como y formatos",
        "categoria": "Archivos y carpetas",
        "tags": "guardar, guardar como, docx, pdf, formato, extension",
        "fuente": "",
        "cuerpo": """
<h3>Guardar (Ctrl + S) y Guardar como (F12)</h3>
<ul>
<li><strong>Ctrl + S</strong>: guarda los cambios en el archivo abierto, en su carpeta y con su nombre.</li>
<li><strong>F12</strong>: abre el panel para cambiar nombre, ubicación o formato. Úsalo la primera vez y cuando quieras crear una copia.</li>
</ul>
<h3>Los formatos más habituales</h3>
<table>
<tr><th>Extensión</th><th>Para qué sirve</th></tr>
<tr><td><strong>.docx</strong></td><td>Documento de Word editable</td></tr>
<tr><td><strong>.xlsx</strong></td><td>Libro de Excel editable</td></tr>
<tr><td><strong>.pptx</strong></td><td>Presentación de PowerPoint</td></tr>
<tr><td><strong>.pdf</strong></td><td>Documento final que no se puede modificar (ideal para enviar)</td></tr>
<tr><td><strong>.zip</strong></td><td>Carpeta comprimida (reduce el tamaño)</td></tr>
<tr><td><strong>.jpg / .png</strong></td><td>Imágenes</td></tr>
</table>
<h3>El aviso «Guardado en este equipo»</h3>
<p>Es normal. Significa que el archivo está en el disco duro del equipo. Si quieres que esté disponible desde cualquier ordenador y se sincronice con tus compañeras, guárdalo en <em>OneDrive</em>.</p>
<div class="caja aviso"><strong>Hábito clave:</strong> pulsa <strong>Ctrl + S</strong> cada pocos minutos. El programa puede cerrarse por un corte de luz, una actualización o un fallo, y lo que no se ha guardado se pierde.</div>
""",
    },
    {
        "titulo": "OneDrive: guardar en la nube y compartir con el equipo",
        "categoria": "Nube y equipo",
        "tags": "onedrive, nube, cloud, compartir, sincronizar, carpeta compartida, equipo",
        "fuente": "",
        "cuerpo": """
<h3>¿Qué es OneDrive?</h3>
<p>Es el espacio de almacenamiento de Microsoft en Internet. Los archivos que guardas en la carpeta OneDrive se sincronizan automáticamente: los ves igual en el ordenador, en el móvil y en el navegador.</p>
<h3>Activar OneDrive</h3>
<ol>
<li>Haz clic en el icono de la nube en la bandeja (abajo a la derecha).</li>
<li>Si pone «Iniciar sesión», haz clic y entra con tu cuenta de empresa.</li>
<li>La carpeta OneDrive aparecerá en el Explorador de archivos.</li>
</ol>
<h3>Indicadores de estado</h3>
<ul>
<li><strong>Nube con check verde</strong>: guardado y sincronizado.</li>
<li><strong>Nube con flechas</strong>: se está subiendo (espera antes de apagar el equipo).</li>
<li><strong>Nube tachada con alerta</strong>: problema de sesión o falta de espacio.</li>
</ul>
<h3>Compartir un archivo con el equipo</h3>
<ol>
<li>Haz clic derecho sobre el archivo → <strong>Compartir</strong>.</li>
<li>Añade a las personas o al grupo de la oficina.</li>
<li>Elige el permiso: <em>Puede editar</em> o <em>Puede ver</em>.</li>
</ol>
<h3>El error más común</h3>
<div class="caja aviso">Un archivo guardado en <em>OneDrive - Personal</em> NO lo ven tus compañeras de la oficina. Para compartirlo, muévelo a <em>OneDrive - Empresa</em> o a la carpeta compartida del equipo.</div>
""",
    },
    {
        "titulo": "Formatear texto en Word: fuente, tamaño, color y estilos",
        "categoria": "Word",
        "tags": "word, negrita, cursiva, fuente, tamano, color, estilo, formatear",
        "fuente": "",
        "cuerpo": """
<h3>Los atajos de formato más usados</h3>
<ul>
<li><strong>Ctrl + N</strong>: negrita</li>
<li><strong>Ctrl + K</strong>: cursiva</li>
<li><strong>Ctrl + U</strong>: subrayado</li>
<li><strong>Ctrl + E</strong>: centrar</li>
<li><strong>Ctrl + Q</strong>: alinear a la izquierda</li>
<li><strong>Ctrl + J</strong>: justificar</li>
<li><strong>Ctrl + Mayús + > / <</strong>: aumentar o reducir el tamaño</li>
</ul>
<h3>Los estilos, la forma "correcta"</h3>
<p>En lugar de dar formato a mano, usa los <strong>estilos</strong> de la galería (Título 1, Título 2, Normal, Énfasis...). Ventajas:</p>
<ul>
<li>Todos los títulos de un documento se ven iguales y se pueden cambiar de golpe.</li>
<li>Al generar la tabla de contenido, Word los reconoce automáticamente.</li>
<li>El documento queda limpio y profesional.</li>
</ul>
<h3>Copiar formato</h3>
<p>Si un texto te ha quedado perfecto: selecciónalo, <strong>Ctrl + Mayús + C</strong> (copiar formato) y luego en el otro texto <strong>Ctrl + Mayús + V</strong>.</p>
<h3>Problemas habituales</h3>
<ul>
<li><strong>El formato no se aplica a todo el párrafo</strong>: porque solo habías seleccionado una frase.</li>
<li><strong>Las letras salen en mayúsculas</strong>: tecla <em>Bloq Mayús</em> activada. Púlsala para desactivarlo.</li>
<li><strong>El texto sale en dos columnas</strong>: <em>Diseño → Columnas → Una</em>.</li>
</ul>
""",
    },
    {
        "titulo": "Tablas en Word: insertar, mover y dar formato",
        "categoria": "Word",
        "tags": "word, tabla, celdas, filas, columnas, formato tabla",
        "fuente": "",
        "cuerpo": """
<h3>Insertar una tabla</h3>
<ol>
<li>Haz clic en el punto donde debe aparecer.</li>
<li><strong>Insertar → Tabla</strong> y elige el número de filas y columnas (o <em>Insertar tabla…</em> para escribir el tamaño).</li>
<li>Escribe y usa <strong>Tab</strong> para pasar a la siguiente celda.</li>
</ol>
<p>Atajo: <strong>Ctrl + T</strong>.</p>
<h3>Las pestañas de tabla</h3>
<ul>
<li><strong>Diseño</strong>: estilo de tabla, colores, bordes, sombreado, encabezado repetido.</li>
<li><strong>Disposición</strong>: insertar o eliminar filas y columnas, ajustar ancho, alinear verticalmente, mover la tabla.</li>
</ul>
<h3>Mover una tabla</h3>
<p>Selecciona la tabla y usa el icono de la flecha (↖) que aparece arriba a la izquierda, o ve a <em>Disposición → Mover tabla</em>.</p>
<h3>Repetir la cabecera en cada página</h3>
<p>En <em>Diseño → Encabezado → Repetir filas de encabezado</em>. Imprescindible en tablas que ocupan varias páginas.</p>
<div class="caja aviso"><strong>No uses la tecla Tab en la última celda de una tabla</strong>: crea una fila nueva unintentionally. Para salir de la tabla, pulsa la flecha abajo que aparece en el margen.</div>
""",
    },
    {
        "titulo": "Exportar a PDF y revisar documentos de Word",
        "categoria": "Word",
        "tags": "word, pdf, exportar, guardar como, imprimir, ortografia, revision",
        "fuente": "",
        "cuerpo": """
<h3>Guardar en PDF</h3>
<ol>
<li><strong>Archivo → Guardar como</strong> (o <strong>F12</strong>).</li>
<li>Elige la carpeta y el nombre.</li>
<li>En <strong>Tipo</strong>, selecciona <strong>PDF (*.pdf)</strong>.</li>
<li><strong>Guardar</strong>.</li>
</ol>
<p>También: <em>Archivo → Exportar → Crear documento PDF/XPS</em>.</p>
<h3>Revisar la ortografía</h3>
<p><strong>F7</strong> revisa todo el documento y propone correcciones. Las palabras dudosas aparecen subrayadas; clic derecho para ver las opciones. En <em>Revisar</em> también puedes usar el corrector de Word, que detecta errores de estilo y mayúsculas.</p>
<h3>Contar palabras</h3>
<p><em>Revisar → Contar palabras</em>: muestra palabras, caracteres, páginas y líneas.</p>
<h3>Imprimir</h3>
<p><strong>Ctrl + P</strong>. Antes de imprimir, mira la vista previa y comprueba el número de páginas. En <em>Más ajustes</em> activa <strong>Imprimir en dos caras</strong> y elige la calidad en escala de grises si no hay color.</p>
<div class="caja aviso"><strong>¿Cuándo enviar PDF y cuándo Word?</strong> Si lo va a editar otra persona, envíale el <em>.docx</em>. Si lo va a leer o imprimir sin tocarlo, envíale el <em>.pdf</em>: se ve igual en todos los equipos.</div>
""",
    },
    {
        "titulo": "Fórmulas de Excel: SUMA, PROMEDIO, SI y SUMAR.SI",
        "categoria": "Excel",
        "tags": "excel, formula, suma, promedio, media, si, sumar.si, contar, max, min, calcular",
        "fuente": "",
        "cuerpo": """
<p>Toda fórmula empieza por <strong>=</strong>. Ejemplo: <code>=A1+B2</code></p>
<table>
<tr><th>Fórmula</th><th>Qué hace</th></tr>
<tr><td><code>=SUMA(A1:A10)</code></td><td>Suma un rango</td></tr>
<tr><td><code>=PROMEDIO(A1:A10)</code></td><td>Media aritmética</td></tr>
<tr><td><code>=MAX(A1:A10)</code> / <code>=MIN(A1:A10)</code></td><td>Máximo y mínimo</td></tr>
<tr><td><code>=CONTAR(A1:A10)</code></td><td>Cuántas celdas tienen números</td></tr>
<tr><td><code>=CONTARA(A1:A10)</code></td><td>Cuántas celdas tienen algo</td></tr>
<tr><td><code>=SI(prueba;valor_si;valor_no)</code></td><td>Decisión condicional</td></tr>
<tr><td><code>=SUMAR.SI(rango;criterio;suma)</code></td><td>Suma solo lo que cumple una condición</td></tr>
<tr><td><code>=CONTAR.SI(rango;criterio)</code></td><td>Cuenta los que cumplen una condición</td></tr>
<tr><td><code>=REDONDEAR(número;decimales)</code></td><td>Redondea</td></tr>
<tr><td><code>=HOY()</code></td><td>Fecha de hoy</td></tr>
</table>
<h3>Copiar fórmulas hacia abajo</h3>
<p>Escribe la fórmula en la primera celda, cópiala y pégala en el resto del rango: las referencias se ajustan solas.</p>
<h3>Referencias absolutas</h3>
<p>Si una celda fija (por ejemplo el IVA en H1) debe staying igual en todas las filas, escribe <code>$H$1</code> o pulsa <strong>F4</strong> al escribir la referencia.</p>
<h3>Errores</h3>
<ul>
<li><strong>#¡VALOR!</strong>: se está multiplicando texto por número.</li>
<li><strong>#¡DIV/0!</strong>: división entre cero o celda vacía.</li>
<li><strong>#¡REF!</strong>: se borró una fila o columna usada por la fórmula.</li>
<li><strong>#¿NOMBRE?</strong>: nombre de función mal escrito.</li>
</ul>
<div class="caja aviso"><strong>Separador de argumentos:</strong> con teclado español suele ser el punto y coma (<code>=SI(A1&gt;0;"Sí";"No")</code>). Si tu Excel usa coma, cambia el signo. Si aparece error al escribir la fórmula, prueba el otro.</div>
""",
    },
    {
        "titulo": "Referencias de celda, rangos y mover fórmulas en Excel",
        "categoria": "Excel",
        "tags": "excel, referencia, celda, rango, copiar, pegar, absoluto, relativo",
        "fuente": "",
        "cuerpo": """
<h3>Cómo se escribe una referencia</h3>
<ul>
<li><strong>Celda relativa</strong>: <code>B4</code>. Si copias la fórmula, se ajusta.</li>
<li><strong>Rango</strong>: <code>B2:D7</code> (dos puntos = hasta).</li>
<li><strong>Referencia absoluta</strong>: <code>$B$4</code>. No se ajusta al copiar.</li>
<li><strong>Referencia mixta</strong>: <code>$B4</code> o <code>B$4</code>: fija solo una parte.</li>
</ul>
<h3>Ejemplo práctico con IVA</h3>
<ol>
<li>En H1 escribe 21 (el tipo de IVA).</li>
<li>En D2 escribe <code>=B2*C2</code> y en D3 <code>=B3*C3</code>.</li>
<li>En E2 escribe <code>=D2*$H$1</code>. Al copiarlo hacia abajo, el 21 % sigue siendo H1.</li>
</ol>
<h3>Copiar fórmulas</h3>
<ul>
<li><strong>Ctrl + C</strong> y <strong>Ctrl + V</strong>: se ajusta todo.</li>
<li><strong>Ctrl + Alt + V</strong> (pegar especial) → <em>Valores</em>: pega solo el resultado, no la fórmula. Útil para convertir el resultado final en un dato fijo.</li>
<li>Arrastrar el tirador de la esquina inferior derecha de la celda es la forma más rápida de rellenar.</li>
</ul>
<h3>Errores al mover o borrar</h3>
<p>Si borras una celda que usaba una fórmula, aparece <strong>#¡REF!</strong>. La solución: <strong>Ctrl + Z</strong> para deshacer, o rehacer la fórmula.</p>
""",
    },
    {
        "titulo": "Ordenar, filtrar y buscar en los datos de Excel",
        "categoria": "Excel",
        "tags": "excel, ordenar, filtrar, filtro, buscar, tabla, duplicados",
        "fuente": "",
        "cuerpo": """
<h3>Ordenar</h3>
<ol>
<li>Haz clic dentro de los datos.</li>
<li><strong>Datos → Ordenar y filtrar</strong>.</li>
<li>Elige <em>De mayor a menor</em> o <em>De menor a mayor</em>.</li>
<li>Si aparece el aviso de selección, responde <strong>Sí</strong> para ampliar la selección a todos los datos.</li>
</ol>
<h3>Filtrar</h3>
<ul>
<li><strong>Ctrl + Mayús + L</strong>: activa los filtros (iconos de embudo en la cabecera).</li>
<li>Clic en el embudo de la columna: marca los valores que quieres ver.</li>
<li>Para limpiar: vuelve al embudo y desmarca <em>(Todo)</em>.</li>
</ul>
<h3>Buscar y reemplazar</h3>
<p><strong>Ctrl + F</strong> para buscar; <strong>Ctrl + H</strong> para reemplazar. En Excel, comprueba la opción <em>Buscar en: Valores / Fórmulas</em> antes de reemplazar todo.</p>
<h3>Quitar duplicados</h3>
<p><strong>Datos → Eliminar duplicados</strong>. Haz una copia del archivo antes: esta operación no se puede deshacer de forma fiable.</p>
<div class="caja aviso"><strong>Antes de ordenar o filtrar, ten en cuenta que las filas ocultas siguen ahí.</strong> Antes de imprimir o copiar, quita el filtro: si no, solo se imprimirá lo visible.</div>
""",
    },
    {
        "titulo": "Gráficos en Excel: crearlos y ajustarlos",
        "categoria": "Excel",
        "tags": "excel, grafico, graficos, columnas, circular, eje, exportar imagen",
        "fuente": "",
        "cuerpo": """
<h3>Crear un gráfico</h3>
<ol>
<li>Selecciona los datos, <strong>incluidos los títulos</strong> de las columnas.</li>
<li><strong>Insertar → Insertar gráfico</strong>.</li>
<li>Elige el tipo (columnas, líneas, circular, área...).</li>
</ol>
<p>Atajo: <strong>F11</strong> crea el gráfico en una hoja nueva.</p>
<h3>Problemas frecuentes</h3>
<ul>
<li><strong>El gráfico sale vacío</strong>: la selección no incluía los datos o los títulos.</li>
<li><strong>El eje vertical muestra 0, 2, 4</strong> en vez de 0, 500, 1000: clic derecho en el eje → <em>Formato de eje</em> → fija el mínimo en 500.</li>
<li><strong>Las series están mal</strong>: clic derecho → <em>Seleccionar datos</em> y corrige el rango.</li>
<li><strong>Las etiquetas se solapan</strong>: activa <em>Etiquetas de datos</em> desde el botón <em>+</em> o reduce el tamaño de la letra.</li>
</ul>
<h3>Tipos de gráfico según el objetivo</h3>
<ul>
<li><strong>Columnas</strong>: comparar cantidades entre categorías.</li>
<li><strong>Líneas</strong>: evolución en el tiempo.</li>
<li><strong>Circular</strong>: porcentajes de un total (con pocas categorías).</li>
<li><strong>Dispersión</strong>: relación entre dos variables.</li>
</ul>
<h3>Guardar el gráfico como imagen</h3>
<p>Clic derecho sobre el gráfico → <strong>Guardar como imagen</strong> (PNG). Se puede pegar en un correo o en un documento.</p>
""",
    },
    {
        "titulo": "Abrir y crear documentos de Word: la pantalla y la cinta de opciones",
        "categoria": "Word",
        "tags": "word, abrir, nuevo, cinta, ribbon, pestañas, guardar, autosave",
        "fuente": "",
        "cuerpo": """
<h3>Las pestañas de la cinta de opciones</h3>
<ul>
<li><strong>Archivo</strong>: nuevo, abrir, guardar, imprimir, opciones (cambia la cinta a un menú).</li>
<li><strong>Inicio</strong>: fuente, tamaño, formato de párrafo, estilos, portapapeles.</li>
<li><strong>Insertar</strong>: tablas, imágenes, formas, encabezados, vínculos, comentarios.</li>
<li><strong>Diseño</strong>: márgenes, orientación, tamaño de página, marca de agua.</li>
<li><strong>Formato</strong>: estilos, colores, fuentes, fondo.</li>
<li><strong>Referencias</strong>: tabla de contenido, notas al pie, citas, índice.</li>
<li><strong>Revisar</strong>: ortografía, comentarios, comparar, proteger.</li>
<li><strong>Vista</strong>: zoom, borrador, modo lectura, rulers.</li>
</ul>
<h3>Teclas de acceso rápido (tecla Alt)</h3>
<p>Pulsa <strong>Alt</strong> y aparecen letras sobre los botones. Por ejemplo <strong>Alt + N</strong> = Insertar, <strong>Alt + G</strong> = Diseño. Si te pierdes, pulsa <strong>Esc</strong>.</p>
<h3>Crear un documento</h3>
<p><strong>Ctrl + N</strong> (nuevo) o <strong>Ctrl + Mayús + N</strong> (documento en blanco). Word ofrece plantillas: informe, carta, currículum...</p>
<h3>Modos de vista</h3>
<ul>
<li><strong>Diseño de impresión</strong>: tal como se imprimirá (es el normal).</li>
<li><strong>Lectura</strong>: pantalla sin distracciones. Si aparece y no puedes escribir, cambia a Diseño de impresión.</li>
<li><strong>Esquema</strong>: ver la estructura del documento con títulos y apartados.</li>
</ul>
""",
    },
    {
        "titulo": "Correo: Outlook o Thunderbird, ¿cuál uso?",
        "categoria": "Correo electrónico",
        "tags": "outlook, thunderbird, elegir, diferencia, cliente de correo, thunderbird o outlook",
        "fuente": "",
        "cuerpo": """
<p>Los dos hacen lo mismo: escribir, recibir, adjuntar, buscar y organizar correos. La diferencia está en
quién los paga y en qué te viene de serie.</p>
<table>
<tr><th></th><th>Outlook</th><th>Thunderbird</th></tr>
<tr><td>Precio</td><td>Incluido con Microsoft 365</td><td>Gratis</td></tr>
<tr><td>Instalación</td><td>Ya está en el equipo</td><td>Hay que instalarlo (una vez, 5 minutos)</td></tr>
<tr><td>Con Microsoft 365</td><td>Correo + calendario + contactos + Teams en un solo programa</td><td>Solo correo</td></tr>
<tr><td>Reuniones y citas</td><td>Sí, completo</td><td>No (usa el calendario web o el de Teams)</td></tr>
<tr><td>Consumo de recursos</td><td>Algo más pesado</td><td>Más ligero</td></tr>
</table>
<h3>Mi recomendación según el caso</h3>
<ul>
<li><strong>Si tu empresa usa Microsoft 365</strong> y además de correo hacéis reuniones o agendas:
<strong>Outlook</strong>. Todo funciona junto y con un clic.</li>
<li><strong>Si queréis algo ligero, gratuito y no os importa el calendario</strong>:
<strong>Thunderbird</strong>. Además se puede instalar en un equipo viejo sin problemas.</li>
<li><strong>Si dudáis</strong>: probad Thunderbird. Es gratis y, si os convence el calendario de Outlook web,
no perdéis nada.</li>
</ul>
<h3>Puedo usar los dos a la vez</h3>
<p>Sí. De hecho es lo normal: Thunderbird en el ordenador de casa y Outlook en el de la oficina.
<i>Ojo:</i> si sincronizáis el correo con el móvil, no conectéis la misma cuenta con IMAP en dos programas
a la vez, porque se duplican los mensajes. Para el móvil, usad la app oficial de correo de cada sistema.</p>
<div class="caja aviso"><strong>En el curso</strong> puedes elegir tu programa en <em>Ajustes → Mi programa de correo</em>
o en la página del módulo de correo. Si eliges «ambos», verás las lecciones de Outlook y de Thunderbird.</div>
""",
    },
    {
        "titulo": "Correo: qué es IMAP, POP3 y SMTP (sin tecnicismos)",
        "categoria": "Correo electrónico",
        "tags": "imap, pop3, smtp, servidor, puerto, configuracion, ssl, tls, 465, 587, 993",
        "fuente": "",
        "cuerpo": """
<p>Cuando configuras el correo en un programa (o en el móvil) te piden cuatro cosas: un <strong>servidor de
entrada</strong>, un <strong>servidor de salida</strong>, un <strong>puerto</strong> y una <strong>seguridad</strong>.
Esto es lo que significan:</p>
<h3>Los servidores</h3>
<ul>
<li><strong>IMAP</strong> (entrada): el buzón se queda en el servidor y tú ves una copia. Lo que ves en el
ordenador y en el móvil es lo mismo. <strong>Úsalo siempre.</strong></li>
<li><strong>POP3</strong> (entrada, antiguo): te descargas el buzón al ordenador y en el servidor se vacía.
Solo tiene sentido si trabajas siempre en el mismo equipo y sin conexión.</li>
<li><strong>SMTP</strong> (salida): el «correo de salida». Es el mismo en todos los programas.</li>
</ul>
<h3>Los puertos y la seguridad</h3>
<table>
<tr><th>Protocolo</th><th>Puerto</th><th>Seguridad</th></tr>
<tr><td>IMAP</td><td><strong>993</strong></td><td>SSL/TLS</td></tr>
<tr><td>IMAP (alternativo)</td><td><strong>143</strong></td><td>STARTTLS</td></tr>
<tr><td>POP3</td><td><strong>995</strong></td><td>SSL/TLS</td></tr>
<tr><td>SMTP</td><td><strong>587</strong></td><td>STARTTLS</td></tr>
<tr><td>SMTP (alternativo)</td><td><strong>465</strong></td><td>SSL/TLS</td></tr>
</table>
<p>La diferencia entre 465 y 587: el 465 cifra desde el principio (SSL/TLS) y el 587 empieza sin cifrar y
se cifra después (STARTTLS). Si tu empresa usa uno, usa ese.</p>
<h3>Para Microsoft 365</h3>
<table>
<tr><th></th><th>Servidor</th><th>Puerto</th><th>Seguridad</th><th>Autenticación</th></tr>
<tr><td>Entrada (IMAP)</td><td>outlook.office365.com</td><td>993</td><td>SSL/TLS</td><td>OAuth2</td></tr>
<tr><td>Salida (SMTP)</td><td>smtp.office365.com</td><td>587</td><td>STARTTLS</td><td>OAuth2</td></tr>
</table>
<p>El <strong>nombre de usuario</strong> es siempre tu dirección de correo completa.</p>
""",
    },
    {
        "titulo": "Thunderbird: instalar y conectar tu cuenta de correo",
        "categoria": "Correo electrónico",
        "tags": "thunderbird, instalar, configurar cuenta, imap, smtp, mozilla, primer arranque",
        "fuente": "https://support.mozilla.org/es/kb/configuracion-manual-de-una-cuenta-de-correo",
        "cuerpo": """
<h3>Instalación</h3>
<ol>
<li>Entra en <strong>thunderbird.net</strong> y descarga la versión de Windows.</li>
<li>Ejecuta el instalador y deja que termine. Se abre solo con la pantalla de configuración de cuenta.</li>
</ol>
<h3>Añadir la cuenta (automático)</h3>
<ol>
<li>Escribe tu <strong>nombre</strong> y tu <strong>dirección de correo</strong>.</li>
<li>Escribe la contraseña y pulsa <strong>Continuar</strong>.</li>
<li>Si encuentra la configuración, marca <strong>Hecho</strong>.</li>
</ol>
<h3>Añadir la cuenta (manual)</h3>
<ol>
<li>Pulsa <strong>Configurar manualmente</strong>.</li>
<li><strong>Entrada:</strong> protocolo IMAP, servidor <code>outlook.office365.com</code> (o el de tu empresa),
puerto <code>993</code>, seguridad SSL/TLS, método de autenticación OAuth2 (o contraseña normal).</li>
<li><strong>Salida (SMTP):</strong> servidor <code>smtp.office365.com</code>, puerto <code>587</code>,
seguridad STARTTLS, autenticación OAuth2.</li>
<li>Nombre de usuario: tu dirección de correo completa.</li>
<li>Pulsa <strong>Hecho</strong>.</li>
</ol>
<h3>Si te pide verificación en dos pasos</h3>
<p>Con Microsoft 365 se abrirá una ventana del navegador para identificarte (OAuth2): es el comportamiento
correcto, no un error. Si tu servidor no admite OAuth2, pídele al servicio de sistemas una
<em>contraseña de aplicación</em>.</p>
<h3>Comprobar que funciona</h3>
<p>Pulsa <strong>F5</strong> (Obtener mensajes). Si la bandeja de entrada se llena, está bien configurado.
Envía un correo a ti misma para probar también la salida.</p>
""",
    },
    {
        "titulo": "Thunderbird: la ventana, carpetas y atajos",
        "categoria": "Correo electrónico",
        "tags": "thunderbird, ventana, carpetas, interfaz, atajos, espacio, space bar, 115",
        "fuente": "https://support.mozilla.org/es/kb/accesos-directos-de-teclado",
        "cuerpo": """
<h3>Las tres zonas</h3>
<ul>
<li><strong>Izquierda:</strong> las cuentas y sus carpetas (Bandeja de entrada, Enviados, Borradores, Papelera...).</li>
<li><strong>Centro:</strong> la lista de mensajes de la carpeta seleccionada, con el filtro rápido encima.</li>
<li><strong>Derecha:</strong> el mensaje abierto.</li>
</ul>
<div class="caja aviso"><strong>Thunderbird 115+ tiene interfaz nueva</strong> (se la llama «Space bar»):
las carpetas están a la izquierda y hay una barra de herramientas arriba. Las versiones anteriores
mostraban la interfaz clásica de tres columnas. En las dos, lo que te cuento aquí funciona igual.</div>
<h3>Atajos útiles</h3>
<table>
<tr><th>Atajo</th><th>Acción</th></tr>
<tr><td><strong>Ctrl + N</strong></td><td>Nuevo mensaje</td></tr>
<tr><td><strong>Ctrl + R</strong></td><td>Responder</td></tr>
<tr><td><strong>Ctrl + Mayús + R</strong></td><td>Responder a todos</td></tr>
<tr><td><strong>Ctrl + L</strong></td><td>Reenviar</td></tr>
<tr><td><strong>Ctrl + E</strong></td><td>Editar como nuevo</td></tr>
<tr><td><strong>Ctrl + K</strong></td><td>Búsqueda global (todas las cuentas)</td></tr>
<tr><td><strong>Ctrl + Mayús + K</strong></td><td>Filtro rápido de la carpeta actual</td></tr>
<tr><td><strong>Ctrl + Mayús + F</strong></td><td>Buscar mensajes (búsqueda avanzada)</td></tr>
<tr><td><strong>Ctrl + F</strong></td><td>Buscar texto en el mensaje abierto</td></tr>
<tr><td><strong>F5</strong></td><td>Obtener mensajes nuevos</td></tr>
<tr><td><strong>Mayús + F5</strong></td><td>Obtener mensajes de todas las cuentas</td></tr>
<tr><td><strong>Alt + Inicio</strong></td><td>Volver a la vista de correo</td></tr>
<tr><td><strong>E</strong></td><td>Archivar</td></tr>
<tr><td><strong>U</strong></td><td>Marcar como leído</td></tr>
<tr><td><strong>S</strong></td><td>Estrella</td></tr>
<tr><td><strong>Supr</strong></td><td>Mover a la papelera</td></tr>
</table>
<div class="caja aviso"><strong>Ojo con las diferencias con Outlook:</strong> en Thunderbird, <em>Reenviar</em> es
<strong>Ctrl + L</strong> (en Outlook es Ctrl + F) y <em>Buscar</em> es <strong>Ctrl + K</strong>
(en Outlook, Ctrl + F). No te agobies: cada programa tiene sus reglas, y las de Thunderbird son las de arriba.</div>
""",
    },
    {
        "titulo": "Thunderbird: adjuntar archivos y poner la firma",
        "categoria": "Correo electrónico",
        "tags": "thunderbird, adjuntar, archivo, firma, redactar, clip, nuevo mensaje",
        "fuente": "",
        "cuerpo": """
<h3>Adjuntar un archivo</h3>
<ol>
<li>En la ventana de redacción, pulsa el icono del <strong>clip 📎</strong>.</li>
<li>Elige <strong>Adjuntar archivos…</strong>, busca el archivo y pulsa <strong>Adjuntar</strong>.</li>
<li>Comprueba el nombre que aparece junto al icono antes de enviar.</li>
</ol>
<p>Para adjuntar una captura recién hecha: en la ventana de redacción, arrastra la imagen desde la
notificación de Windows directamente sobre el mensaje.</p>
<h3>La firma automática</h3>
<ol>
<li>Menú <strong>≡ (hamburguesa)</strong> → <strong>Configuración</strong>.</li>
<li>Sección <strong>General</strong> → campo <strong>Firma</strong> (abajo del todo).</li>
<li>Escribe tu firma y marca la casilla <em>Adjuntar la firma a todos los mensajes</em>.</li>
</ol>
<h3>Texto con formato o texto plano</h3>
<p>En <em>Configuración → Composición</em> puedes elegir el formato de los mensajes nuevos. Para escribir a
proveedores externos, el texto plano evita que se muestren colores y letras raras.</p>
<h3>Problemas con los adjuntos</h3>
<table>
<tr><th>Problema</th><th>Solución</th></tr>
<tr><td>No puedo adjuntar</td><td>El archivo está abierto en otro programa: ciérralo.</td></tr>
<tr><td>Es demasiado grande</td><td>Comprímelo en ZIP o compártelo como enlace de OneDrive.</td></tr>
<tr><td>El destinatario no lo abre</td><td>Envíalo en PDF.</td></tr>
</table>
""",
    },
    {
        "titulo": "Thunderbird: filtros de mensajes y búsqueda global",
        "categoria": "Correo electrónico",
        "tags": "thunderbird, filtro, regla, busqueda global, mover correo, bandeja, limpiar",
        "fuente": "",
        "cuerpo": """
<h3>Crear un filtro (regla automática)</h3>
<ol>
<li>Menú <strong>≡ (hamburguesa)</strong> → <strong>Herramientas → Filtros de mensajes</strong>.</li>
<li>Pulsa <strong>Nuevo…</strong>.</li>
<li>Condición: <em>El asunto contiene</em>, <em>El remitente es</em>, <em>El cuerpo contiene</em>…</li>
<li>Acción: <em>Mover mensaje a la carpeta X</em>, <em>Marcar como leído</em>, <em>Marcar con estrella</em>…</li>
<li>OK.</li>
</ol>
<div class="caja ejemplo"><strong>Ejemplo:</strong> todo lo que venga de <em>facturacion@empresa.es</em> con la
palabra «factura» en el asunto cae automáticamente en la carpeta <em>Facturas</em>.</div>
<h3>Buscar en todo</h3>
<ul>
<li><strong>Ctrl + K</strong>: búsqueda global en todas las cuentas y en el texto de los mensajes.</li>
<li><strong>Ctrl + Mayús + K</strong>: filtro rápido de la carpeta que tienes abierta (por remitente, fecha, leído...).</li>
<li><strong>Ctrl + Mayús + F</strong>: búsqueda avanzada (fechas, De, Para, asunto, cuerpo...).</li>
</ul>
<h3>Dejar la bandeja limpia</h3>
<ul>
<li>Arrastra los correos archivados a la carpeta <em>Archivos</em>.</li>
<li>Vacía la papelera de vez en cuando: clic derecho → <em>Vaciar papelera</em>.</li>
<li>Usa <strong>Mayús + Supr</strong> con reservations: borra sin pasar por la papelera.</li>
</ul>
""",
    },
    {
        "titulo": "Outlook: adjuntar archivos y resolver problemas",
        "categoria": "Correo electrónico",
        "tags": "outlook, correo, adjuntar, adjunto, archivo grande, zip, adjuntos",
        "fuente": "",
        "cuerpo": """
<h3>Adjuntar un archivo</h3>
<ol>
<li>En el mensaje: <strong>Insertar → Adjuntar</strong> (icono del clip).</li>
<li>Elige <strong>Este equipo</strong>, <strong>Archivos recientes</strong> o <strong>OneDrive</strong>.</li>
<li>Selecciona el archivo → <strong>Insertar</strong>.</li>
<li>Comprueba el nombre que aparece junto al clip.</li>
</ol>
<h3>Problemas y soluciones</h3>
<table>
<tr><th>Problema</th><th>Solución</th></tr>
<tr><td>No puedo adjuntar</td><td>El archivo está abierto en otro programa. Ciérralo y vuelve a intentarlo.</td></tr>
<tr><td>El archivo es demasiado grande</td><td>El límite habitual es 25 MB. Comprímelo en ZIP o compártelo como enlace de OneDrive.</td></tr>
<tr><td>Envié el archivo y no llega</td><td>Revisa la carpeta <em>Enviados</em>: si el envío falló, Outlook te lo avisa con un aviso rojo.</td></tr>
<tr><td>El destinatario no lo abre</td><td>Envíalo en PDF o comprímelo.</td></tr>
<tr><td>Adjunté el archivo equivocado</td><td>No hay vuelta atrás: reenvía el mensaje con el archivo correcto.</td></tr>
</table>
<h3>Adjuntar sin subir el archivo (recomendado)</h3>
<p>Con OneDrive: <em>Insertar → OneDrive → Compartir</em>. Envia un enlace y el destinatario ve siempre la última versión. Recuerda: quien tenga el enlace puede ver el archivo.</p>
<div class="caja aviso"><strong>Nunca reenvíes un correo con datos confidenciales a una dirección externa sin comprobarlo.</strong> Usa <em>Responder</em> en lugar de <em>Reenviar</em> cuando la respuesta solo es para quien te escribió.</div>
""",
    },
    {
        "titulo": "Organizar el correo: carpetas, reglas y búsqueda avanzada",
        "categoria": "Correo electrónico",
        "tags": "outlook, correo, regla, carpeta, buscar, bandeja, archivar, adjuntar",
        "fuente": "",
        "cuerpo": """
<h3>Las carpetas principales</h3>
<p>Bandeja de entrada · Elementos enviados · Borradores · Elementos eliminados · Papelera · Archivados. Crea subcarpetas con clic derecho → <em>Nueva carpeta</em>.</p>
<h3>Crear una regla automática</h3>
<ol>
<li><strong>Archivo → Reglas y alertas → Nueva regla…</strong></li>
<li>Elige la acción (mover a otra carpeta, marcar, reenviar...).</li>
<li>Define la condición: «contiene la palabra factura», «de la gestoría», «tiene adjunto».</li>
<li>Elige la carpeta de destino y pon nombre a la regla.</li>
<li>Listo: se aplica a los correos nuevos a partir de ese momento.</li>
</ol>
<p>Para aplicar una regla a correos antiguos: selecciónalos, <strong>Archivo → Reglas y alertas → Nueva regla → Aplicar a los elementos seleccionados</strong>.</p>
<h3>Búsqueda avanzada</h3>
<p>Escribe en el cuadro de búsqueda de arriba:</p>
<ul>
<li><code>from:jefa</code> — de una persona</li>
<li><code>subject:factura</code> — por asunto</li>
<li><code>hasattachment:yes</code> — solo los que llevan archivo</li>
<li><code>received:01/10/2026..31/10/2026</code> — por fechas</li>
</ul>
<h3>Atajos de Outlook</h3>
<table>
<tr><th>Atajo</th><th>Acción</th></tr>
<tr><td><strong>Ctrl + Shift + N</strong></td><td>Nuevo mensaje</td></tr>
<tr><td><strong>Ctrl + R</strong></td><td>Responder</td></tr>
<tr><td><strong>Ctrl + Mayús + R</strong></td><td>Responder a todos</td></tr>
<tr><td><strong>Ctrl + F</strong></td><td>Reenviar</td></tr>
<tr><td><strong>Ctrl + K</strong></td><td>Buscar</td></tr>
<tr><td><strong>Ctrl + Enter</strong></td><td>Enviar</td></tr>
<tr><td><strong>E</strong></td><td>Archivar</td></tr>
<tr><td><strong>U</strong></td><td>Marcar como leído</td></tr>
<tr><td><strong>Ctrl + 1</strong></td><td>Marcar con banderín</td></tr>
</table>
""",
    },
    {
        "titulo": "Imprimir: elegir impresora, copias, páginas y dúplex",
        "categoria": "Impresión y PDF",
        "tags": "imprimir, impresora, copias, duplex, dos caras, papel, vista previa",
        "fuente": "",
        "cuerpo": """
<h2>Imprimir paso a paso</h2>
<ol>
<li><strong>Ctrl + P</strong> en cualquier programa.</li>
<li>Mira la <strong>vista previa</strong> y el número de páginas (abajo a la izquierda).</li>
<li>Elige la <strong>impresora</strong> (arriba).</li>
<li>Ajusta <strong>copias</strong> y el rango de <strong>páginas</strong> (todas / Actual / 1-3).</li>
<li>Haz clic en <strong>Imprimir</strong>.</li>
</ol>
<h2>Opciones que ahorran tiempo y papel</h2>
<ul>
<li><strong>Imprimir en dos caras</strong>: en <em>Más ajustes</em> o con <strong>Ctrl + Mayús + P</strong>.</li>
<li><strong>Hojas por página</strong>: 2 o 4 páginas en una hoja.</li>
<li><strong>Escala → Ajustar a la página</strong>: evita que las columnas salgan cortadas.</li>
<li><strong>Ordenación</strong>: <em>Por copia</em> o <em>Por trabajo</em>.</li>
<li><strong>Propiedades de la impresora → Calidad</strong>: elige blanco y negro si no hace falta el color.</li>
</ul>
<h2>Guardar en PDF en lugar de imprimir</h2>
<p>En la lista de impresoras elige <strong>Microsoft Print to PDF</strong> y el documento se guardará como PDF en el disco. Se puede abrir con doble clic en cualquier equipo.</p>
<h2>La impresora no funciona</h2>
<ol>
<li>Comprueba que tenga papel y que no haya un error en su pantalla.</li>
<li><strong>Win + I → Bluetooth y dispositivos → Impresoras y escáneres</strong>: mira el estado.</li>
<li>Si es una impresora de red, comprueba que estás en la wifi de la oficina.</li>
<li>Haz un pantallazo del error y avisa al servicio de sistemas. No desmontes la impresora.</li>
</ol>
""",
    },
    {
        "titulo": "Escanear documentos a PDF con el escáner de Windows",
        "categoria": "Impresión y PDF",
        "tags": "escanear, escaner, pdf, digitalizar, oki, hp,|imprimir",
        "fuente": "",
        "cuerpo": """
<h3>Desde la aplicación Escáner de Windows</h3>
<ol>
<li><strong>Win + S</strong> → escribe <em>Escáner</em> → abre <em>Escáner de Windows</em>.</li>
<li>Pulsa <strong>Agregar</strong> y elige tu multifunción.</li>
<li>Coloca el documento en el cristal, cara abajo, con la esquina superior izquierda hacia el borde del cristal.</li>
<li>Elige el tipo (Documento o Foto) y la resolución (200-300 dpi es suficiente para texto).</li>
<li>Pulsa <strong>Escanear</strong> y elige la carpeta de destino.</li>
</ol>
<h3>Desde el Explorador de archivos</h3>
<p>Clic derecho en una carpeta → <strong>Nuevo</strong> → el nombre de tu escáner. Se escanea y se guarda ahí.</p>
<h3>Escanear a PDF de varios lados</h3>
<p>En el menú de configuración de la aplicación, elige <em>Escanear → Cambiar configuración → Modo de archivo PDF</em> y activa <em>Agregar páginas</em>.</p>
<div class="caja aviso"><strong>Escanear a PDF crea un PDF con imagen</strong>: el texto no se puede editar ni buscar. Si necesitas texto editable, escanea a Word (elijiendo <em>Documento de Microsoft Word</em>) o usa OCR en Recortes.</div>
""",
    },
    {
        "titulo": "PDF: unir, dividir, firmar y pasar a Word",
        "categoria": "Impresión y PDF",
        "tags": "pdf, unir, combinar, dividir, firmar, ocr, texto, word",
        "fuente": "",
        "cuerpo": """
<h3>Ver un PDF</h3>
<p>Doble clic: se abre con el visor de Windows o con Edge (que ya lo trae). No hace falta instalar nada.</p>
<h3>Unir varios PDF en uno (Windows 11)</h3>
<ol>
<li>En el Explorador, selecciona los archivos PDF (Ctrl + clic).</li>
<li>Clic derecho → <strong>Combinar en un PDF</strong>.</li>
<li>Ordena los archivos y guarda.</li>
</ol>
<h3>Pasar un PDF a Word para editarlo</h3>
<p>Abre el PDF en Edge o en el visor de Microsoft y usa el botón <em>Editar</em> / <em>Guardar como Word</em>. Si el PDF es un escaneado (imagen), el texto no se reconocerá: usa <em>OCR</em> en Recortes o escanéalo de nuevo como documento de texto.</p>
<h3>Firmar un PDF</h3>
<p>En Edge: abre el PDF, haz clic en el icono del lápiz (<em>Editar</em>), dibuja la firma y guarda. También puedes pegar una imagen de tu firma.</p>
<h3>Ocultar datos antes de enviarlo</h3>
<p>En Recortes puedes tapar un dato con el efecto <em>Pixelar</em> o con un rectángulo de color antes de guardar la imagen.</p>
""",
    },
    {
        "titulo": "Phishing y estafas por correo: cómo reconocerlas",
        "categoria": "Seguridad",
        "tags": "phishing, estafa, correo, scam, suplantacion, fraude, contraseña, banco",
        "fuente": "",
        "cuerpo": """
<h3>Señales de alarma</h3>
<ul>
<li><strong>Urgencia artificial</strong>: «tu cuenta se bloqueará en 24 horas», «actúa ahora».</li>
<li><strong>Remitente parecido pero no igual</strong>: <code>seguridad@miempresa-actualiza.com</code> en lugar de <code>seguridad@miempresa.com</code>.</li>
<li><strong>Enlace que no lleva a donde dice</strong>: pasa el ratón por encima (sin hacer clic) y mira la URL real abajo.</li>
<li><strong>Petición de datos confidenciales</strong>: contraseñas, números de tarjeta, claves de acceso. Ningún servicio legítimo te los pide por correo.</li>
<li><strong>Adjunto inesperado</strong> con extensión ejecutable (<code>.exe</code>, <code>.bat</code>, <code>.scr</code>).</li>
<li><strong>Errores de redacción</strong> y falta de coherencia en el texto.</li>
</ul>
<h3>Qué hacer</h3>
<ol>
<li>No pulses nada.</li>
<li>Comprueba la dirección real del remitente.</li>
<li>Si dudas, llama a la empresa por el teléfono que ya tienes en la tarjeta (no uses el del correo).</li>
<li>Denúncialo con el botón <em>Denunciar phishing</em> de Outlook.</li>
<li>Bórralo tras avisar al responsable.</li>
</ol>
<div class="caja aviso"><strong>Regla de la empresa:</strong> ante una duda de seguridad, verifica por otra vía (teléfono o en persona). Ninguna Blocks interna pide contraseñas por correo.</div>
""",
    },
    {
        "titulo": "Copias de seguridad: la regla 3-2-1 y dónde guardar",
        "categoria": "Seguridad",
        "tags": "copia, seguridad, backup, respaldo, 3-2-1,onedrive, datos",
        "fuente": "",
        "cuerpo": """
<h3>La regla 3-2-1</h3>
<ul>
<li><strong>3</strong> copias de los datos importantes.</li>
<li>En <strong>2</strong> sitios distintos (por ejemplo, el equipo y OneDrive).</li>
<li><strong>1</strong> copia fuera de la oficina (la nube ya cumple esto).</li>
</ul>
<h3>¿Qué hay que respaldar?</h3>
<p>Todo lo que no puedas volver a crear: documentos del trabajo, listados de clientes, actas, plantillas propias. Lo que puedes rehacer (un texto que se puede volver a escribir) no necesita copia.</p>
<h3>La sincronización no es una copia</h3>
<p>Si borras un archivo en OneDrive y está sincronizado, se borra también en todos los equipos. OneDrive guarda el historial de versiones: clic derecho → <em>Versiones</em> → <em>Restaurar</em>.</p>
<div class="caja aviso"><strong>Antes de un trabajo importante</strong> (un informe anual, un mailing de clientes), guarda una copia con fecha en la carpeta del proyecto: <em>Informes 2026 - copia 27-10</em>. Cuesta 10 segundos y te salva un día.</div>
""",
    },
    {
        "titulo": "Microsoft Teams: reuniones, compartir pantalla y chat",
        "categoria": "Nube y equipo",
        "tags": "teams, reunion, videollamada, compartir pantalla, camara, microfono, chat",
        "fuente": "",
        "cuerpo": """
<h3>Antes de la reunión</h3>
<ul>
<li><strong>Ctrl + Mayús + M</strong>: silenciar el micrófono.</li>
<li><strong>Ctrl + Mayús + O</strong>: encender o apagar la cámara.</li>
<li>Usa auriculares: evitan el eco.</li>
</ul>
<h3>Compartir pantalla con seguridad</h3>
<ol>
<li>Pulsa <strong>Compartir pantalla</strong>.</li>
<li>Elige <strong>Pestaña</strong> (lo más seguro) en lugar de Pantalla completa.</li>
<li>Selecciona solo la pestaña que vas a enseñar.</li>
<li>Para terminar: <strong>Dejar de compartir</strong>.</li>
</ol>
<div class="caja aviso"><strong>Antes de compartir, cierra el correo, el chat privado y cualquier documento de otro compañero.</strong> Todo lo que hay en tu escritorio se ve, y es el error más habitual.</div>
<h3>Chat de Teams</h3>
<p>Escribe con <strong>Intro</strong> y usa <strong>Mayús + Intro</strong> para una línea nueva. Menciona con <strong>@nombre</strong> para que la persona reciba un aviso.</p>
<h3>Canales frente a chats</h3>
<table>
<tr><th></th><th>Chat</th><th>Canal</th></tr>
<tr><td>Quién lo ve</td><td>Solo los participantes del chat</td><td>Todo el equipo del canal</td></tr>
<tr><td>Para qué</td><td>Conversaciones rápidas</td><td>Información que debe quedar guardada</td></tr>
</table>
""",
    },
    {
        "titulo": "Copilot e IA generativa en el trabajo",
        "categoria": "Inteligencia artificial",
        "tags": "copilot, ia, chatgpt, inteligencia artificial, prompt, redactar, resumir",
        "fuente": "",
        "cuerpo": """
<h3>Dónde está la IA</h3>
<ul>
<li><strong>Windows + C</strong>: abre Copilot en Windows 11.</li>
<li><strong>Microsoft 365 Copilot</strong>: dentro de Word, Excel, Outlook y Teams.</li>
<li><strong>ChatGPT</strong> u otras: en el navegador, en su web o como aplicación.</li>
</ul>
<h3>Ejemplos de uso en la oficina</h3>
<ul>
<li>«Reescribe este correo para que sea más cordial pero firme».</li>
<li>«Resume este informe en 5 puntos con los datos más importantes».</li>
<li>«Crea una agenda de reunión de 30 minutos sobre estos temas».</li>
<li>«¿Cómo hago en Excel para contar las ventas que superan 1000 €?»</li>
<li>«Traduce al español este texto».</li>
</ul>
<h3>Cómo escribir una buena petición</h3>
<p>Usa la estructura: <strong>tarea + contexto + formato</strong>.</p>
<div class="caja ejemplo">«Actúa como asistente administrativo. Escribe un correo al cliente que ha pedido aplazar la entrega: 3 frases, tono cordial, e incluye una propuesta de nueva fecha (15 de noviembre).»</div>
<h3>Reglas de seguridad con la IA</h3>
<ul>
<li>No pegues datos personales o confidenciales en una IA no autorizada por la empresa.</li>
<li><strong>Verifica siempre</strong>: las IAs pueden inventar datos, cifras o referencias.</li>
<li>La responsabilidad del documento final es tuya.</li>
<li>Usa el texto de la IA como borrador y revísalo siempre.</li>
</ul>
""",
    },
    {
        "titulo": "Cuando el ordenador va lento o se cuelga",
        "categoria": "Windows 11",
        "tags": "lento, cuelga, va lento, rendimiento, bloqueado, reiniciar, task manager, proceso",
        "fuente": "",
        "cuerpo": """
<h3>El ordenador está lento pero no colgado</h3>
<ol>
<li>Espera un momento: muchas veces es el antivirus o una actualización en segundo plano.</li>
<li>Cierra las ventanas y programas que no estés usando.</li>
<li><strong>Ctrl + Mayús + Esc</strong> abre el <em>Administrador de tareas</em>: mira qué programa consume más CPU o memoria. Si es uno que no necesitas, ciérralo.</li>
<li>Reinicia el equipo: la memoria se libera por completo.</li>
</ol>
<h3>El ratón se mueve pero no responde</h3>
<ol>
<li>Pulsa <strong>Ctrl + Mayús + Esc</strong> y busca el programa que no responde en el <em>Administrador de tareas</em>.</li>
<li>Selecciona la tarea que no responde y pulsa <strong>Finalizar tarea</strong>.</li>
<li>Si no funciona, reinicia con <strong>Ctrl + Alt + Supr</strong>.</li>
</ol>
<h3>Todo congelado, ni el ratón se mueve</h3>
<p>Mantén pulsado el botón de encendido durante 10 segundos para apagar. Se perderá lo que no esté guardado (de ahí la importancia de <strong>Ctrl + S</strong>).</p>
<h3>El equipo va lento después de un tiempo</h3>
<ul>
<li>Reinicia cada cierto tiempo: los programas abiertos van comiendo memoria.</li>
<li>Revisa el espacio en disco: <em>Win + I → Sistema → Almacenamiento</em>. Si el disco está al 100 %, el equipo va lento.</li>
<li>Instala las actualizaciones pendientes (<em>Win + I → Windows Update</em>).</li>
</ul>
""",
    },
    {
        "titulo": "Ajustes de Windows que conviene conocer",
        "categoria": "Windows 11",
        "tags": "ajustes, settings, configuración, personalization, cuentas, sistema, actualizar",
        "fuente": "",
        "cuerpo": """
<p>Se abren con <strong>Windows + I</strong>. Las secciones más útiles:</p>
<ul>
<li><strong>Sistema → pantalla</strong>: brillo, escala, multiprocesamiento (si las letras se ven muy pequeñas, sube la escala al 125 %).</li>
<li><strong>Sistema → notificaciones</strong>: qué avisos pueden aparecer. Puedes silenciar los de las apps que te distraen.</li>
<li><strong>Personalización → Colores</strong>: modo claro/oscuro.</li>
<li><strong>Personalización → Barra de tareas</strong>: donde se alinean los iconos, y para ocultar los que no uses.</li>
<li><strong>Personalización → Barra de tareas → Comportamiento de la barra de tareas</strong>: ocultar automáticamente (para despejar el escritorio).</li>
<li><strong>Accesibilidad → Teclado</strong>: comportamiento de la tecla de impresión de pantalla y del filtro de teclas.</li>
<li><strong>Accesibilidad → Visión</strong>: lupa, contraste, tamaño del texto. Muy útil si lees poco.</li>
<li><strong>Cuentas → Inicio de sesión</strong>: cambiar contraseña, configurar el PIN.</li>
<li><strong>Windows Update</strong>: actualizaciones pendientes.</li>
<li><strong>Privacidad y seguridad</strong>: permisos de cámara y micrófono, y búsqueda de Windows.</li>
</ul>
<div class="caja aviso"><strong>Consejo para la ofimática:</strong> si el ratón va justo al borde de la pantalla y cuesta moverlo, ajusta la velocidad del puntero en <em>Bluetooth y dispositivos → Mouse</em>.</div>
""",
    },
    {
        "titulo": "Copiar texto e imágenes entre programas y aplicaciones",
        "categoria": "Teclado y atajos",
        "tags": "copiar, pegar, portapapeles, texto, imagen, sin formato, arrastrar",
        "fuente": "",
        "cuerpo": """
<h3>Métodos para seleccionar</h3>
<ul>
<li><strong>Doble clic</strong>: una palabra.</li>
<li><strong>Triple clic</strong>: un párrafo.</li>
<li><strong>Arrastrar</strong>: una zona exacta.</li>
<li><strong>Mayús + clic</strong>: ampliar la selección.</li>
<li><strong>Ctrl + A</strong>: todo.</li>
</ul>
<h3>Copiar y pegar</h3>
<ul>
<li><strong>Ctrl + C</strong> / <strong>Ctrl + V</strong>: método universal.</li>
<li><strong>Ctrl + Mayús + V</strong>: pegar solo texto (sin formatos). Perfecto cuando pegas de una web.</li>
<li><strong>Windows + V</strong>: historial del portapapeles. Puedes recuperar lo que copiaste hace un rato y fijar elementos.</li>
<li><strong>Arrastrar y soltar</strong>: copia entre ventanas (manteniendo <strong>Ctrl</strong> pulsado) o mueve (sin <strong>Ctrl</strong>).</li>
</ul>
<h3>Copiar una imagen de la web</h3>
<ol>
<li>Clic derecho sobre la imagen → <em>Guardar imagen como…</em> o <em>Copiar imagen</em>.</li>
<li>En Word o en un correo: <strong>Ctrl + V</strong>.</li>
</ol>
<h3>Copiar una celda de Excel como imagen</h3>
<p>En Excel: <em>Inicio → Copiar → Pegar como imagen</em>. Se pega como imagen y no se desajusta al copiar.</p>
""",
    },
    {
        "titulo": "Buscar y reemplazar texto en cualquier documento",
        "categoria": "Teclado y atajos",
        "tags": "buscar, reemplazar, ctrl+f, ctrl+h, texto, corregir, cambiar",
        "fuente": "",
        "cuerpo": """
<h3>Buscar (Ctrl + F)</h3>
<ol>
<li>Pulsa <strong>Ctrl + F</strong>.</li>
<li>Escribe la palabra. Se resaltan todas las apariciones.</li>
<li><strong>Intro</strong>: siguiente aparición. <strong>Esc</strong>: cerrar la búsqueda.</li>
</ol>
<h3>Reemplazar (Ctrl + H)</h3>
<ol>
<li>Pulsa <strong>Ctrl + H</strong>.</li>
<li>Escribe el texto antiguo en <em>Buscar</em> y el nuevo en <em>Reemplazar con</em>.</li>
<li>Pulsa <strong>Reemplazar todo</strong>.</li>
</ol>
<p>Es la forma más rápida de cambiar un nombre, una fecha o un código repetido en un documento largo.</p>
<h3>En Excel, ojo</h3>
<p>Antes de reemplazar todo, comprueba el desplegable <em>Buscar en</em>: <em>Valores</em> o <em>Fórmulas</em>. Y ten una copia del archivo: un reemplazo mal hecho puede cambiar 500 celdas de golpe.</p>
<h3>En el Explorador de archivos</h3>
<p>Con <strong>Ctrl + F</strong> buscas por <em>nombre</em>. Con la opción <em>Buscar en el contenido</em> buscas por el <em>texto que hay dentro</em> de los documentos.</p>
""",
    },
    {
        "titulo": "Instalar y usar la aplicación de ofimática en el escritorio",
        "categoria": "Windows 11",
        "tags": "acceso directo, escritorio, pwa, instalar, inicio, anclar, app, empezar menu, url",
        "fuente": "",
        "cuerpo": """
<h3>Opción 1: acceso directo en el escritorio y en el menú Inicio</h3>
<p>En el equipo donde se instala el curso, hay un archivo <em>instalador</em> que crea:</p>
<ul>
<li>Un icono en el <strong>Escritorio</strong>.</li>
<li>Una entrada en el <strong>menú Inicio</strong> (búsqueda: «Ofimática»).</li>
</ul>
<p>El acceso directo apunta a la dirección del curso en la red de la oficina.</p>
<h3>Opción 2: instalarla como aplicación (PWA) con Microsoft Edge</h3>
<ol>
<li>Abre Edge y ve a la dirección del curso.</li>
<li>Haz clic en el icono de <em>App disponible</em> (en la barra de direcciones) o ve a <em>… → Más herramientas → Aplicaciones → Instalar este sitio como una aplicación</em>.</li>
<li>En el diálogo, marca <strong>Anclar a la barra de tareas</strong>, <strong>Anclar al inicio</strong> y <strong>Crear acceso directo al escritorio</strong>.</li>
<li>Pulsa <strong>Instalar</strong>.</li>
</ol>
<p>Desde entonces la aplicación se abre en su propia ventana, sin barra de navegador, y aparece en Inicio y en la barra de tareas.</p>
<h3>Opción 3: anclar el acceso directo a la barra de tareas</h3>
<p>En <em>edge://apps</em> (escribe esa dirección en Edge) verás las aplicaciones instaladas; desde <em>Detalles</em> puedes <strong>Anclar a la barra de tareas</strong> o <strong>Crear acceso directo al escritorio</strong>.</p>
<div class="caja aviso"><strong>Consejo:</strong> pedid a la empresa que añada el acceso directo al <em>Inicio</em> mediante un script de inicio de sesión: así aparece solo en los equipos de la oficina y desaparece si alguien se lleva el equipo.</div>
""",
    },
    {
        "titulo": "Excel: formato de celdas, fechas, moneda y porcentajes",
        "categoria": "Excel",
        "tags": "excel, formato, celdas, moneda, euros, porcentaje, fecha, decimales, columnas",
        "fuente": "",
        "cuerpo": """
<h3>El cuadro Formato de celdas</h3>
<p>Selecciona las celdas y pulsa <strong>Ctrl + 1</strong>. Pestañas: Número, Alineación, Fuente, Borde, Relleno, Protección.</p>
<h3>Acciones rápidas (pestaña Inicio)</h3>
<ul>
<li><strong>€</strong>: formato de moneda con euros.</li>
<li><strong>%</strong>: convierte 0,21 en 21 %.</li>
<li><strong>Aumentar / Reducir decimales</strong>: botones con la flecha hacia la izquierda o la derecha.</li>
<li><strong>Formato de fecha</strong>: estilos rápidos (14/03/2026, 14-mar-2026...).</li>
<li><strong>Ajustar al ancho</strong>: doble clic en el borde entre columnas.</li>
</ul>
<h3>Problemas típicos</h3>
<ul>
<li><strong>Las celdas muestran #####</strong>: la columna es demasiado estrecha. Amplíala.</li>
<li><strong>Las fechas salen como números</strong>: la celda no tiene formato de fecha. Aplica <em>Formato de celdas → Fecha</em>.</li>
<li><strong>El euro sale como €12,00</strong> cuando quieres 12 €: en <em>Formato de celdas → Moneda</em> puedes poner los decimales a 0.</li>
<li><strong>El texto se convierte en fecha al pegar</strong>: Excel lo interpreta. Formatea la columna como <em>Texto</em> antes de pegar.</li>
</ul>
""",
    },
    {
        "titulo": "Immovilizar paneles, zoom y vista en Excel",
        "categoria": "Excel",
        "tags": "excel, inmovilizar, paneles, zoom, vista, cabecera, scrolls",
        "fuente": "",
        "cuerpo": """
<h3>Inmovilizar la fila de cabecera</h3>
<ol>
<li>Colócate en la celda <strong>A2</strong> (justo debajo de la fila de títulos).</li>
<li><strong>Vista → Inmovilizar paneles → Inmovilizar paneles</strong>.</li>
</ol>
<p>Para quitarlo: <em>Vista → Inmovilizar paneles → Desinmovilizar paneles</em>.</p>
<h3>Cambiar el zoom</h3>
<ul>
<li>En la esquina inferior derecha, arrastra el control de zoom o haz clic en el porcentaje.</li>
<li><strong>Ctrl + rueda del ratón</strong>: zoom rápido.</li>
<li><strong>Ctrl + Mayús + L</strong>: alterna entre vista normal y vista de página completa.</li>
</ul>
<h3>Otros atajos de vista</h3>
<ul>
<li><strong>Ctrl + flechas</strong>: salta al final de la región de datos.</li>
<li><strong>Ctrl + Inicio / Ctrl + Fin</strong>: primera / última celda con datos.</li>
<li><strong>F11</strong>: gráfico en una hoja nueva.</li>
</ul>
""",
    },
    {
        "titulo": "Tablas dinámicas: resumen rápido de una lista de datos",
        "categoria": "Excel",
        "tags": "excel, tabla dinamica, pivot, resumen, agrupar, cruces, analisis",
        "fuente": "",
        "cuerpo": """
<h3>Crear una tabla dinámica</h3>
<ol>
<li>Colócate dentro de los datos (una tabla con encabezados).</li>
<li><strong>Insertar → Tabla dinámica</strong>.</li>
<li>Elige si la quieres en una hoja nueva o en la misma.</li>
<li>Arrastra los campos: <em>Filas</em> (por ejemplo, cliente), <em>Valores</em> (por ejemplo, importe, con la función SUMA) y <em>Columnas</em> (por ejemplo, mes).</li>
</ol>
<h3>Ejemplo clásico</h3>
<p>Filas = <em>Cliente</em>, Valores = <em>Suma de Importe</em>, Columnas = <em>Mes</em>. En una celda tienes la matriz de ventas por cliente y mes, sin tocar ninguna fórmula.</p>
<h3>Filtrar los datos</h3>
<p>Arrastra un campo a <em>Filtros</em> y elige un valor. Todo el resumen se actualiza al instante.</p>
<div class="caja aviso"><strong>Requisito:</strong> los datos deben tener encabezados y no tener filas vacías en medio. Si las celdas combinadas dan error, <strong>Insertar → Tabla</strong> (Ctrl + T) primero para limpiar la estructura.</div>
""",
    },
    {
        "titulo": "Correo electrónico: basics de escritura profesional",
        "categoria": "Correo electrónico",
        "tags": "correo, email, escribir, asunto, redactar, adjuntar, professionalism, firma",
        "fuente": "",
        "cuerpo": """
<h3>Las 5 partes de un correo</h3>
<ol>
<li><strong>Para</strong>: destinatario.</li>
<li><strong>CC</strong>: copia visible. <strong>CCO</strong>: copia oculta (nadie ve quién la recibe).</li>
<li><strong>Asunto</strong>: una frase que explique el motivo. Sin asunto, el correo se pierde.</li>
<li><strong>Cuerpo</strong>: el mensaje.</li>
<li><strong>Firma</strong>: tu nombre, cargo y teléfono.</li>
</ol>
<h3>Responder bien</h3>
<p>Contesta <strong>arriba</strong> y deja el texto original debajo, en gris. Así la otra persona ve tu respuesta sin tener que leer el hilo entero.</p>
<h3>Programar un envío</h3>
<p><em>Enviar → Programar envío</em>: útil para comunicaciones fuera de horario o para recordatorios discretos.</p>
<h3>Errores que debes evitar</h3>
<ul>
<li>Pulsar <em>Responder a todos</em> por costumbre (puede haber 200 destinatarios).</li>
<li>Enviar sin revisar el adjunto (el clásico «adjunto que no iba»).</li>
<li>Escribir en mayúsculas: en el correo se lee como gritar.</li>
</ul>
""",
    },
    {
        "titulo": "Windows 11: el menú Inicio, los widgets y las ventanas virtuales",
        "categoria": "Windows 11",
        "tags": "inicio, widgets, windows 11, escritorio virtual, multitasking, task view, areas de trabajo",
        "fuente": "",
        "cuerpo": """
<h3>Widgets</h3>
<p>El panel de widgets (Windows + W) muestra el tiempo, las noticias o tu calendario en el lateral. Puedes desactivarlo en <em>Ajustes → Personalización → Barra de tareas → Widgets</em>. Si molesta mucho, es el primer ajuste que conviene hacer.</p>
<h3>Escritorios virtuales</h3>
<ul>
<li><strong>Windows + Ctrl + D</strong>: crea un escritorio virtual nuevo.</li>
<li><strong>Windows + Ctrl + flecha ←/→</strong>: cambia de escritorio virtual.</li>
<li><strong>Windows + Ctrl + F4</strong>: cierra el escritorio virtual actual.</li>
</ul>
<p>Útil para separar el trabajo personal del de la oficina.</p>
<h3>Windows 11 y el menú Inicio</h3>
<ul>
<li><strong>Windows + I</strong>: Ajustes.</li>
<li><strong>Windows + X</strong>: menú de administrador (Administrador de tareas, PowerShell, Terminal, Configuración de Windows).</li>
<li><strong>Windows + N</strong>: notificaciones y calendario.</li>
<li><strong>Windows + A</strong>: ajustes rápidos (wifi, volumen, batería).</li>
<li><strong>Windows + G</strong>: barra de juegos (útil para grabar con el Game Bar).</li>
</ul>
""",
    },
    {
        "titulo": "Problemas con el Wi-Fi de la oficina",
        "categoria": "Windows 11",
        "tags": "wifi, internet, conexion, red, no funciona, desconecta, dns",
        "fuente": "",
        "cuerpo": """
<h3>Comprobaciones rápidas</h3>
<ol>
<li>Haz clic en <strong>Windows + A</strong> (ajustes rápidos) y comprueba que el wifi está encendido y que aparece la red de la oficina.</li>
<li>Si estás conectada pero no navegas, abre el navegador y prueba a entrar en una página. Si no funciona: <em>Win + R</em>, escribe <code>cmd</code>, pulsa Intro y escribe <code>ping 8.8.8.8</code>. Si responde, el problema es de DNS.</li>
<li>Desconecta y vuelve a conectar la red.</li>
</ol>
<h3>Restablecer el adaptador de red</h3>
<ol>
<li><strong>Win + I → Red e Internet → Wi-Fi → Propiedades del adaptador</em>.</li>
<li>Haz clic en <strong>Desinstalar</strong> y espera unos segundos: Windows lo reinstala automáticamente.</li>
</ol>
<h3>Red con icono de globo</h3>
<p>Un globo terráqueo en la barra de tareas significa «sin acceso a Internet». Reinicia el equipo y el router de la oficina (apágalo 10 segundos y enciéndelo). Si sigue igual, avisa al servicio de sistemas.</p>
<div class="caja aviso"><strong>No modifiques la configuración de red o DNS por tu cuenta</strong> sin avisar: en una oficina con equipos configurados por el servicio de sistemas, un cambio puede romper la conexión para todo el equipo.</div>
""",
    },
    {
        "titulo": "Atajos de Excel que cosyran cada día",
        "categoria": "Excel",
        "tags": "excel, atajos, shift, ctrl, f2, f4, buscar, referencia, sumas",
        "fuente": "",
        "cuerpo": """
<table>
<tr><th>Atajo</th><th>Acción</th></tr>
<tr><td><strong>Ctrl + C / X / V</strong></td><td>Copiar / cortar / pegar</td></tr>
<tr><td><strong>Ctrl + Z / Y</strong></td><td>Deshacer / rehacer</td></tr>
<tr><td><strong>Ctrl + S</strong></td><td>Guardar</td></tr>
<tr><td><strong>Ctrl + F / H</strong></td><td>Buscar / reemplazar</td></tr>
<tr><td><strong>Ctrl + A</strong></td><td>Seleccionar todo (o la región de datos)</td></tr>
<tr><td><strong>Ctrl + 1</strong></td><td>Formato de celdas</td></tr>
<tr><td><strong>Alt + =</strong></td><td>AutoSuma</td></tr>
<tr><td><strong>F2</strong></td><td>Editar la celda</td></tr>
<tr><td><strong>F4</strong></td><td>Referencia absoluta ($) o repetir la última acción</td></tr>
<tr><td><strong>Ctrl + `</strong></td><td>Ver las fórmulas en lugar de los valores</td></tr>
<tr><td><strong>Ctrl + ;</strong></td><td>Fecha de hoy</td></tr>
<tr><td><strong>Ctrl + Mayús + ;</strong></td><td>Hora actual</td></tr>
<tr><td><strong>Ctrl + T</strong></td><td>Convertir el rango en tabla</td></tr>
<tr><td><strong>Ctrl + Shift + L</strong></td><td>Filtros</td></tr>
<tr><td><strong>Mayús + espacio</strong></td><td>Seleccionar la fila entera</td></tr>
<tr><td><strong>Ctrl + espacio</strong></td><td>Seleccionar la columna entera</td></tr>
<tr><td><strong>Ctrl + Inicio / Fin</strong></td><td>Primera / última celda con datos</td></tr>
</table>
""",
    },
    {
        "titulo": "Word: interlineado, márgenes, paginación y pie de página",
        "categoria": "Word",
        "tags": "word, interlineado, margenes, paginas, pie, pie de pagina, numeracion, portada",
        "fuente": "",
        "cuerpo": """
<h3>Márgenes</h3>
<p><strong>Diseño → Márgenes</strong>: Normal, Estrecho, etc. Para márgenes personalizados, <em>Diseño → Márgenes → Márgenes personalizados</em> (en centímetros).</p>
<h3>Interlineado y espaciado</h3>
<p>En el grupo Párrafo de <em>Inicio</em>: <em>Interlineado</em> (1,15 es lo más cómodo de leer) y <em>Espaciado antes/después</em> (6-12 pt entre párrafos).</p>
<h3>Numerar páginas y pie de página</h3>
<ol>
<li><strong>Insertar → Número de página</strong>.</li>
<li>Elige la posición (inferior, superior).</li>
<li>Si quieres el número a partir de la página 2 (sin numerar la portada): en <em>Insertar → Número de página → Formato de números de página</em>, marca <em>Empezar en 2</em>.</li>
</ol>
<h3>Encabezado y pie</h3>
<p><em>Insertar → Encabezado</em> o <em>Insertar → Pie de página</em>. Lo que escribas se repite en todas las páginas. Ideal para el logo y el nombre del documento.</p>
<h3>Portada</h3>
<p><em>Insertar → Portada</em>: hay plantillas con título y diseño. Para quitarla, borra el contenido del cuadro de texto, no el elemento.</p>
""",
    },
    {
        "titulo": "Cómo pedir ayuda y reportar un problema en la oficina",
        "categoria": "Windows 11",
        "tags": "ayuda, soporte, error, problema, informar, reportar, ticket, servicio",
        "fuente": "",
        "cuerpo": """
<h3>Antes de pedir ayuda, ten preparado</h3>
<ol>
<li>Un <strong>pantallazo del error</strong> (Windows + Shift + S).</li>
<li>Los <strong>pasos que has seguido</strong>, en orden.</li>
<li>El <strong>nombre del archivo</strong> y el <strong>programa</strong> que usabas.</li>
<li>Si el problema es del ordenador: <strong>la hora exacta</strong> en la que ocurrió.</li>
</ol>
<h3>Dónde preguntar</h3>
<ul>
<li>Primero, la <strong>ayudante de esta aplicación</strong> (esquina inferior derecha): responde a las dudas más habituales al instante.</li>
<li>Después, el <strong>manual</strong>: busca tu duda en el buscador.</li>
<li>Y si sigue sin resolverse, a tu <strong>responsable de formación</strong> o al <strong>servicio de sistemas</strong>.</li>
</ul>
<h3>Cómo escribir el mensaje de aviso</h3>
<div class="caja ejemplo">Asunto: Error al abrir el Excel de facturas (27-10)<br><br>Hola,<br>Cuando abro el archivo «Facturas octubre.xlsx» desde la carpeta compartida aparece el mensaje de error que ves en el pantallazo adjunto.<br>He probado a abrirlo en local (copiándolo a Documentos) y funciona, por lo que parece que es la carpeta de red.<br>Un saludo</div>
<div class="caja aviso"><strong>No borres nada</strong> ni reinicies el equipo para "probar": si el problema es de red o de un archivo bloqueado, puedes perder datos. Anota y pregunta.</div>
""",
    },
]
