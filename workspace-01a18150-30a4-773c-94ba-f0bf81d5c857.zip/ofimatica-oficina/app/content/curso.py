"""Agrega los módulos del curso en una única lista."""
from .p1_basico import MODULOS_1_4
from .p2_ofimatica import MODULOS_5_6
from .p3_comunicacion import MODULOS_7_10
from .p4_correo import MODULO_CORREO

# El orden importa: el módulo de correo va entre Excel y Teams.
MODULOS = MODULOS_1_4 + MODULOS_5_6 + [MODULO_CORREO] + MODULOS_7_10

NIVELES = ["Básico", "Intermedio", "Avanzado"]
