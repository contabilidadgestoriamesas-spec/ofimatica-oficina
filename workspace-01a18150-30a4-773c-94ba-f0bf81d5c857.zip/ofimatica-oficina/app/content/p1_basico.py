"""PARTE 1 · Módulos 1-4: Windows 11, teclado, archivos y capturas."""

MODULOS_1_4 = [
    # ------------------------------------------------------------------ #
    {
        "slug": "fundamentos",
        "titulo": "Primeros pasos con Windows 11",
        "nivel": "Básico",
        "icono": "🖥️",
        "duracion": 75,
        "descripcion": "Tu primer contacto serio con el ordenador: el escritorio, las ventanas, el ratón y el menú de Inicio.",
        "lecciones": [
            {
                "slug": "que-es-windows-11",
                "titulo": "Qué es Windows 11 y qué hay en la pantalla",
                "objetivo": "Saber nombrar las zonas de la pantalla y moverte por ella sin miedo.",
                "duracion": 10,
                "contenido": """
<p>Windows 11 es el <strong>sistema operativo</strong> de los ordenadores de la oficina: es el programa que se enciende al arrancar el equipo y que te da acceso a todo lo demás (escritorio, archivos, programas, Internet).</p>
<h2>Las cuatro zonas de la pantalla</h2>
<ol class="pasos">
<li><strong>El escritorio</strong>: es la imagen de fondo. Sirve para colocar los iconos de los programas y archivos que usas a diario.</li>
<li><strong>La barra de tareas</strong>: la franja horizontal que está en el centro de la pantalla, abajo. Ahí ves los programas que tienes abiertos y los botones <em>Inicio</em>, <em>Buscar</em>, <em>Chat</em> y <em>Widgets</em>.</li>
<li><strong>El área de notificación</strong>: la esquina inferior derecha. Muestra la hora, la fecha, el wifi, el volumen, la batería y los avisos.</li>
<li><strong>El menú Inicio</strong>: se abre con el botón central de la barra de tareas o con la <strong>tecla Windows</strong>. Desde aquí se abre cualquier programa instalado.</li>
</ol>
<h2>Primer contacto: enciende y apaga bien</h2>
<ol class="pasos">
<li>Enciende el equipo y espera a que aparezca el escritorio. No pulses botones: el arranque puede tardar 1-2 minutos.</li>
<li>Para <strong>apagar</strong>: ve a <em>Inicio → Apagar</em> y elige <em>Apagar</em>. Espera a que la pantalla se apague sola; no la apagues a la fuerza.</li>
<li>Nunca apagues el equipo mientras estés trabajando: puedes perder lo que estabas escribiendo.</li>
</ol>
<div class="caja aviso"><strong>Consejo:</strong> la tecla <strong>Windows</strong> (la que lleva el dibujito de la ventana, ⌘-cuadrada) es la tecla más importante de Windows 11. Con ella sola se abre y se cierra el menú Inicio. Si solo te aprendes una tecla hoy, que sea esa.</div>
""",
                "atajos": [
                    {"teclas": "Windows", "accion": "Abre o cierra el menú Inicio"},
                    {"teclas": "Windows + D", "accion": "Muestra el escritorio (esconde las ventanas)"},
                    {"teclas": "Windows + L", "accion": "Bloquea el ordenador"},
                    {"teclas": "Windows + I", "accion": "Abre los Ajustes de Windows"},
                ],
                "trampas": [
                    "Si el ordenador está apagado del todo, no se enciende con el ratón: hay que pulsar el botón físico de encendido.",
                    "El botón físico de encendido y el de reinicio están casi juntos. Reiniciar = apagar y volver a encender.",
                ],
                "practica": "",
            },
            {
                "slug": "el-raton",
                "titulo": "El ratón: clics, doble clic y botón derecho",
                "objetivo": "Dominar el ratón, que es la herramienta con la que más vas a trabajar.",
                "duracion": 12,
                "contenido": """
<h2>Las tres cosas que hace el ratón</h2>
<ol class="pasos">
<li><strong>Clic izquierdo</strong>: seleccionar. Un clic selecciona un elemento; sobre un icono, un clic lo marca.</li>
<li><strong>Doble clic</strong>: abrir. Dos clics rápidos con el botón izquierdo abren un archivo o una carpeta.</li>
<li><strong>Clic derecho</strong>: el menú de opciones. Al hacer clic derecho aparece un menú contextual con todo lo que puedes hacer con el elemento seleccionado (abrir, copiar, eliminar...).</li>
</ol>
<h2>También sirve para</h2>
<ul>
<li><strong>Arrastrar</strong>: mantener pulsado el botón izquierdo mientras mueves el ratón y soltar donde quieras. Sirve para mover archivos, seleccionar varias cosas o mover una ventana.</li>
<li><strong>Rueda</strong>: desplazar el contenido hacia arriba y abajo.</li>
</ul>
<h2>La rueda y el zoom</h2>
<p>Si tienes un ratón con rueda gris en medio, al <strong>girarla</strong> haces scroll. Si esa misma rueda se puede pulsar hacia dentro y hacia fuera, controlas el zoom: úsalo en los documentos de Word para leer mejor la letra.</p>
<div class="caja aviso"><strong>Error frecuente:</strong> hacer dos clics muy separados en lugar de un doble clic rápido. Si el archivo no se abre, es que has hecho dos clics simples: selecciona el icono y pulsa <strong>Intro</strong>, o haz el doble clic más rápido.</div>
<h2>Cuando no funciona el ratón</h2>
<p>Prueba estos atajos, que funcionan siempre:</p>
<ul>
<li><strong>Tab</strong>: mueve el foco al siguiente elemento.</li>
<li><strong>Intro</strong>: activa el elemento que tiene el foco (equivale al doble clic).</li>
<li><strong>Ctrl + Tab</strong>: cambia de ventana abierta.</li>
</ul>
""",
                "atajos": [
                    {"teclas": "Tab", "accion": "Mueve el foco al siguiente elemento"},
                    {"teclas": "Intro", "accion": "Abre el elemento seleccionado"},
                    {"teclas": "Ctrl + Tab", "accion": "Cambia entre ventanas abiertas"},
                ],
                "trampas": [
                    "El doble clic debe ser rápido. Si tardas mucho, el sistema lo interpreta como dos clics simples.",
                    "La rueda del ratón a la izquierda/right sirve para el scroll lateral si el programa lo permite.",
                ],
                "practica": "ej-raton-basico",
            },
            {
                "slug": "las-ventanas",
                "titulo": "Las ventanas: mover, maximizar y cerrar",
                "objetivo": "Entender los botones de una ventana y aprender a tener siempre todo a la vista.",
                "duracion": 12,
                "contenido": """
<p>Cada programa abierto en el ordenador es una <strong>ventana</strong>. Todas las ventanas de Windows 11 tienen los mismos botones en la esquina superior derecha:</p>
<ul>
<li><strong>— (minimizar)</strong>: la ventana desaparece de la pantalla pero sigue abierta. Sigue trabajando en la barra de tareas.</li>
<li><strong>□ (maximizar / restaurar)</strong>: la ventana ocupa toda la pantalla. Vuelve a pulsarlo para devolverla a su tamaño.</li>
<li><strong>✕ (cerrar)</strong>: cierra la ventana y el programa.</li>
</ul>
<h2>Cómo mover una ventana</h2>
<ol class="pasos">
<li>Sitúa el puntero sobre la <strong>barra de título</strong> (la franja superior con el nombre del programa).</li>
<li>Mantén pulsado el botón izquierdo, mueve el ratón y suelta. La ventana se queda donde la dejes.</li>
<li>Si la ventana se sale de la pantalla, no te preocupes: <strong>Windows + flecha izquierda</strong> la pega en la mitad izquierda, <strong>Windows + flecha derecha</strong> en la derecha y <strong>Windows + flecha arriba</strong> la maximiza.</li>
</ol>
<h2>Organizar dos ventanas a la vez</h2>
<p>Con dos ventanas abiertas puedes colocarlas en paralelo:</p>
<ol class="pasos">
<li>Abre la primera ventana y pulsa <strong>Windows + flecha izquierda</strong> (o derecha).</li>
<li>Abre la segunda y pulsa <strong>Windows + flecha derecha</strong> (o izquierda).</li>
<li>Ambas quedan en mitad de pantalla. ¡Perfecto para copiar un dato de un documento a otro!</li>
</ol>
<div class="caja aviso"><strong>Atajo estrella:</strong> <strong>Windows + Z</strong> abre los <em>Diseños de acoplamiento</em>: eliges de un clic cómo colocar la ventana (mitad, cuadrante, etc.).</div>
<h2>Cambiar de ventana rápidamente</h2>
<ul>
<li><strong>Alt + Tab</strong>: mantén pulsado Alt y ve pulsando Tab hasta elegir la ventana; suelta Alt para cambiar.</li>
<li><strong>Windows + Tab</strong>: muestra todas las ventanas abiertas (Vista de tareas).</li>
<li>Clic en el icono de la barra de tareas: si el programa ya estaba abierto, vuelve a esa ventana.</li>
</ul>
""",
                "atajos": [
                    {"teclas": "Windows + flecha izquierda", "accion": "Pega la ventana en la mitad izquierda"},
                    {"teclas": "Windows + Z", "accion": "Diseños de acoplamiento (dividir pantalla)"},
                    {"teclas": "Alt + Tab", "accion": "Cambia de ventana abierta"},
                    {"teclas": "Windows + Tab", "accion": "Muestra todas las ventanas"},
                    {"teclas": "Alt + F4", "accion": "Cierra la ventana activa"},
                ],
                "trampas": [
                    "Si minimized la ventana y luego la cierras desde la barra de tareas (menú derecho), el programa se cierra de verdad.",
                    "Alt + Tab con las dos manos: una mantiene Alt, la otra pulsa Tab.",
                ],
                "practica": "",
            },
            {
                "slug": "menu-inicio-y-busqueda",
                "titulo": "El menú Inicio y la búsqueda de Windows",
                "objetivo": "Abrir cualquier programa escribiendo su nombre, sin buscarlo con el ratón.",
                "duracion": 11,
                "contenido": """
<h2>El menú Inicio</h2>
<p>Pulsa el botón central de la barra de tareas o la <strong>tecla Windows</strong>. Verás tres zonas:</p>
<ul>
<li><strong>Anclados</strong>: los programas que ya tienes fijados (Word, Excel, el navegador...).</li>
<li><strong>Recomendados</strong>: los archivos con los que trabajas últimamente.</li>
<li><strong>Todos las aplicaciones</strong>: la lista completa de programas instalados.</li>
</ul>
<h2>Buscar es más rápido que buscar con el ratón</h2>
<ol class="pasos">
<li>Pulsa la <strong>tecla Windows</strong> (o haz clic en el botón Buscar).</li>
<li>Escribe el nombre de lo que buscas: por ejemplo <em>word</em>, <em>excel</em>, <em>explorador</em>, <em>configuración</em>.</li>
<li>Windows te va mostrando resultados mientras escribes. Pulsa <strong>Intro</strong> para abrir el primero.</li>
</ol>
<div class="caja aviso"><strong>Consejo:</strong> escribe solo las primeras letras. <em>exc</em> ya es suficiente para que aparezca Excel. Y si escribes <em>?</em> (interrogación) en la búsqueda, Windows busca ayuda y te lleva al soporte del sistema.</div>
<h2>Buscar dentro de Windows o dentro de un archivo</h2>
<ul>
<li><strong>Windows + S</strong>: abre la búsqueda de Windows.</li>
<li>En un documento de Word: <strong>Ctrl + F</strong> busca texto dentro del documento.</li>
<li>En una carpeta: <strong>Ctrl + F</strong> busca archivos por nombre dentro de esa carpeta.</li>
</ul>
<h2>Fijar y quitar programas del menú Inicio</h2>
<ol class="pasos">
<li>Clic derecho sobre el programa en la lista <em>Todos las aplicaciones</em>.</li>
<li>Elige <strong>Anclar al inicio</strong>. Aparecerá en la zona de anclados.</li>
<li>Para quitarlo: clic derecho sobre el anclado → <strong>Desanclar del inicio</strong>.</li>
</ol>
""",
                "atajos": [
                    {"teclas": "Windows", "accion": "Abre el menú Inicio"},
                    {"teclas": "Windows + S", "accion": "Abre la búsqueda de Windows"},
                    {"teclas": "Ctrl + F", "accion": "Busca texto o archivos"},
                    {"teclas": "Ctrl + Esc", "accion": "Abre el menú Inicio (alternativa)"},
                ],
                "trampas": [
                    "La búsqueda busca por nombre, no por contenido de texto (salvo que uses 'Buscar en el contenido' en el Explorador).",
                ],
                "practica": "",
            },
            {
                "slug": "barra-de-tareas-y-notificaciones",
                "titulo": "Barra de tareas, bandeja y notificaciones",
                "objetivo": "Saber qué programa está abierto y controlar volumen, wifi y avisos.",
                "duracion": 12,
                "contenido": """
<h2>La barra de tareas</h2>
<p>Windows 11 coloca los iconos de los programas <strong>en el centro</strong>. Hay dos tipos de iconos:</p>
<ul>
<li><strong>Iconos anclados</strong>: siempre visibles (pueden no estar ejecutados).</li>
<li><strong>Ventanas abiertas</strong>: los programas que estás usando ahora. Llevan una línea o un cuadrado debajo indicando que están activos.</li>
</ul>
<p>Si abres muchos programas, la barra se llena. Click derecho en un icono vacío de la barra → <strong>Barra de tareas</strong> → elige <em>Effecto de barra de tareas</em> o activa <em>Combinar automáticamente las barras de tareas</em> para ver solo los íconos agrupados.</p>
<h2>La esquina inferior derecha</h2>
<ul>
<li><strong>Fecha y hora</strong>: clic para ver el calendario y las notificaciones.</li>
<li><strong>Wifi / Ethernet</strong>: clic para ver las redes disponibles.</li>
<li><strong>Volumen</strong>: clic para subir o bajar el sonido; el clic en el icono de altavoz silencia.</li>
<li><strong>Batería</strong>: porcentaje y estado de carga (en portátiles).</li>
</ul>
<h2>El panel de ajustes rápidos</h2>
<p>Haz clic en la fila de la <strong>wifi, volumen y batería</strong> (no en los iconos pequeños, sino en la zona de abajo). Se abre el <em>Panel de configuración rápida</em> con los botones grandes: wifi, bluetooth, modo avión, iluminación nocturna, rotación, energy saver...</p>
<div class="caja aviso"><strong>No te asustes con los avisos.</strong> Windows 11 avisa de cosas como "Windows ha protegido tu PC" o "actualizaciones pendientes". Si no sabes qué hacer, anota el mensaje y pregunta a tu formador antes de hacer clic.</div>
<h2>Centro de notificaciones</h2>
<p>Junto a la fecha y la hora hay un aviso de "Notificaciones". Desde ahí ves los mensajes de Outlook, las alertas de Windows y las invitaciones de Teams.</p>
""",
                "atajos": [
                    {"teclas": "Windows + A", "accion": "Abre los ajustes rápidos (wifi, volumen, batería)"},
                    {"teclas": "Windows + N", "accion": "Notificaciones y calendario"},
                    {"teclas": "Windows + B", "accion": "Va al primer icono de la bandeja"},
                ],
                "trampas": [
                    "Clic en el «engranaje» abre Ajustes, pero para cosas rápidas usa el panel de ajustes rápidos.",
                ],
                "practica": "",
            },
        ],
    },
    # ------------------------------------------------------------------ #
    {
        "slug": "teclado",
        "titulo": "Teclado y atajos esenciales",
        "nivel": "Básico",
        "icono": "⌨️",
        "duracion": 80,
        "descripcion": "La parte que más tiempo te ahorra: teclas que debes conocer, atajos de Windows y atajos de Office.",
        "lecciones": [
            {
                "slug": "partes-del-teclado",
                "titulo": "Las partes del teclado y las teclas que hay que conocer",
                "objetivo": "Saber dónde está cada tecla y qué hace la tecla de Windows.",
                "duracion": 12,
                "contenido": """
<h2>Reparto del teclado</h2>
<ul>
<li><strong>Fila de números</strong>: 1 2 3 4 5 6 7 8 9 0 y los símbolos (¡ ¿ ° « »).</li>
<li><strong>Fila de letras</strong>: ASDFGHJKLÑ.</li>
<li><strong>Fila inferior</strong>: ZXCVBNM.</li>
<li><strong>Espaciadora</strong>: la barra larga del centro. Space = espacio.</li>
</ul>
<h2>Las teclas "de control" (las que se pulsan con otra tecla)</h2>
<ul>
<li><strong>Ctrl</strong> (Control): la tecla de los atajos más usados: copiar, pegar, guardar...</li>
<li><strong>Shift</strong> (Mayúsculas): también se llama <em>Shift</em>. Con ella pasas a mayúsculas y cambias símbolos.</li>
<li><strong>Alt</strong> (Alternar): da acceso a opciones alternativas de los menús.</li>
<li><strong>Windows</strong> (⊞): la tecla con el dibujito de una ventana. Está entre Ctrl y Alt. Abre el menú Inicio y da acceso a muchos atajos.</li>
<li><strong>Intro</strong> (Enter): acepta, confirma o salta de línea.</li>
<li><strong>Supr / Suprimir</strong>: borra hacia la derecha. <strong>Retroceso</strong> borra hacia la izquierda.</li>
<li><strong>Esc</strong>: cancela la operación o cierra un menú. ¡Tu tecla de emergencia!</li>
<li><strong>F1 a F12</strong>: teclas de función. <strong>F1</strong> abre la ayuda; <strong>F2</strong> edita la celda en Excel; <strong>F11</strong> crea un gráfico rápido en Excel.</li>
<li><strong>AvPág / RePág</strong>:(Page Up / Page Down): saltan una pantalla arriba o abajo.</li>
</ul>
<h2>¿Qué hace la tecla Windows exactamente?</h2>
<p>Sola: abre el menú Inicio. Con otras teclas hace cosas muy útiles:</p>
<ul>
<li><strong>Windows + E</strong>: Explorador de archivos.</li>
<li><strong>Windows + D</strong>: mostrar el escritorio.</li>
<li><strong>Windows + L</strong>: bloquear el ordenador (úsalo siempre al salir).</li>
<li><strong>Windows + I</strong>: Ajustes.</li>
<li><strong>Windows + R</strong>: ejecutar un comando.</li>
<li><strong>Windows + Impresión de pantalla</strong>: captura toda la pantalla y la guarda.</li>
</ul>
<div class="caja aviso"><strong>Truco para escribirlo en el ordenador:</strong> la tecla Windows se escribe «Windows» o «Win». Cuando busquemos un atajo, te lo diré como «Win + E».</div>
""",
                "atajos": [
                    {"teclas": "Ctrl", "accion": "Tecla de control (se usa con otras)"},
                    {"teclas": "Shift", "accion": "Mayúsculas / símbolos alternativos"},
                    {"teclas": "Alt", "accion": "Opciones alternativas de los menús"},
                    {"teclas": "Windows", "accion": "Abre el menú Inicio"},
                    {"teclas": "Esc", "accion": "Cancela / cierra (tecla de emergencia)"},
                ],
                "trampas": [
                    "Si el teclado tiene la luz de «Bloq Mayús» encendida, las letras salen en mayúsculas. Se apaga con la tecla Bloq Mayús.",
                ],
                "practica": "ej-teclado-basico",
            },
            {
                "slug": "atajos-windows-11",
                "titulo": "Los 15 atajos de Windows 11 que más vas a usar",
                "objetivo": "Memorizar un pequeño grupo de atajos que te ahorran horas.",
                "duracion": 15,
                "contenido": """
<p>No intentes memorizarlos todos de golpe. Estos 15 se usan el 90 % del tiempo:</p>
<table class="tabla-atajos">
<tr><th>Atajo</th><th>Qué hace</th></tr>
<tr><td><strong>Windows</strong></td><td>Abre el menú Inicio</td></tr>
<tr><td><strong>Windows + E</strong></td><td>Abre el Explorador de archivos</td></tr>
<tr><td><strong>Windows + D</strong></td><td>Muestra el escritorio</td></tr>
<tr><td><strong>Windows + L</strong></td><td>Bloquea el ordenador</td></tr>
<tr><td><strong>Windows + I</strong></td><td>Abre los Ajustes</td></tr>
<tr><td><strong>Windows + R</strong></td><td>Abre la ventana Ejecutar</td></tr>
<tr><td><strong>Windows + S</strong></td><td>Búsqueda de Windows</td></tr>
<tr><td><strong>Windows + X</strong></td><td>Menú de administrador (sistema)</td></tr>
<tr><td><strong>Windows + V</strong></td><td>Historial del portapapeles</td></tr>
<tr><td><strong>Windows + Shift + S</strong></td><td>Captura de una zona de la pantalla</td></tr>
<tr><td><strong>Windows + Impresión de pantalla</strong></td><td>Captura completa guardada en Imágenes</td></tr>
<tr><td><strong>Windows + P</strong></td><td>Proyectar / duplicar pantalla</td></tr>
<tr><td><strong>Windows + flecha ←/→</strong></td><td>Coloca la ventana a la izquierda o derecha</td></tr>
<tr><td><strong>Windows + Z</strong></td><td>Diseños de acoplamiento</td></tr>
<tr><td><strong>Alt + Tab</strong></td><td>Cambia entre ventanas</td></tr>
</table>
<h2>La ventana Ejecutar (Windows + R)</h2>
<p>Es la caja de comandos de Windows. Escribe ahí:</p>
<ul>
<li><code>control</code> → Panel de control.</li>
<li><code>cmd</code> o <code>powershell</code> → línea de comandos (no la uses salvo que te lo indiquen).</li>
<li><code>explorer</code> → abre el Explorador.</li>
</ul>
<div class="caja aviso"><strong>Atajo universal en cualquier programa:</strong> <strong>Ctrl + C</strong> copia, <strong>Ctrl + V</strong> pega, <strong>Ctrl + Z</strong> deshace, <strong>Ctrl + A</strong> selecciona todo, <strong>Ctrl + S</strong> guarda, <strong>Ctrl + F</strong> busca, <strong>Ctrl + P</strong> imprime. Memorízalos como un bloque: son los mismos en Word, Excel, Outlook y en casi todo.</div>
""",
                "atajos": [
                    {"teclas": "Windows + E", "accion": "Abre el Explorador de archivos"},
                    {"teclas": "Windows + R", "accion": "Abre la ventana Ejecutar"},
                    {"teclas": "Windows + X", "accion": "Menú de administrador del sistema"},
                    {"teclas": "Windows + V", "accion": "Historial del portapapeles"},
                    {"teclas": "Ctrl + C", "accion": "Copiar"},
                    {"teclas": "Ctrl + V", "accion": "Pegar"},
                    {"teclas": "Ctrl + Z", "accion": "Deshacer"},
                    {"teclas": "Ctrl + A", "accion": "Seleccionar todo"},
                    {"teclas": "Ctrl + S", "accion": "Guardar"},
                ],
                "trampas": [
                    "Ctrl + Z deshace; para rehacer, Ctrl + Y. Si cierras el documento, se pierde el historial de deshacer.",
                ],
                "practica": "ej-atajos-teclado",
            },
            {
                "slug": "portapapeles-y-buscar-texto",
                "titulo": "Portapapeles, buscar y reemplazar texto",
                "objetivo": "Copiar, pegar, buscar palabras y cambiar un texto repetido en segundos.",
                "duracion": 12,
                "contenido": """
<h2>El portapapeles</h2>
<p>El portapapeles es un almacén temporal: lo que copias queda ahí hasta que copies otra cosa.</p>
<ul>
<li><strong>Ctrl + C</strong> copiar · <strong>Ctrl + X</strong> cortar · <strong>Ctrl + V</strong> pegar.</li>
<li><strong>Ctrl + Shift + V</strong> pega <em>solo como texto sin formato</em>: muy útil cuando pegas de la web y sale todo con colores y tamaños raros.</li>
<li><strong>Windows + V</strong> muestra el <em>historial del portapapeles</em>: puedes recuperar lo que copiaste hace un rato e incluso fijar un elemento (pin).</li>
</ul>
<h2>Buscar dentro de un documento</h2>
<ol class="pasos">
<li>Pulsa <strong>Ctrl + F</strong>. Aparece una barra de búsqueda en la parte superior.</li>
<li>Escribe la palabra. Se irán resaltando todas las apariciones.</li>
<li>Pulsa <strong>Enter</strong> para ir a la siguiente y <strong>Esc</strong> para cerrar la búsqueda.</li>
</ol>
<h2>Reemplazar texto (el superpoder)</h2>
<p>Sirve para cambiar un nombre, una dirección o una fecha repetida en un documento largo:</p>
<ol class="pasos">
<li>Pulsa <strong>Ctrl + H</strong>.</li>
<li>En <em>Buscar</em> escribe el texto antiguo; en <em>Reemplazar con</em>, el nuevo.</li>
<li>Pulsa <strong>Reemplazar todo</strong>. En 2 segundos habrás cambiado 200 párrafos.</li>
</ol>
<div class="caja aviso"><strong>Ejercicio mental rápido:</strong> si te llega un documento con el nombre de otra persona en 12 sitios, ¿qué haces? <em>Ctrl + H</em>, no «buscar y reemplazar a mano».</div>
<h2>Copiar un texto solo con el ratón</h2>
<ol class="pasos">
<li>Selecciona el texto arrastrando con el botón izquierdo (de la letra inicial a la final).</li>
<li>Doble clic en una palabra: selecciona esa palabra. Triple clic en un párrafo: selecciona el párrafo entero.</li>
<li>Ctrl + C y listo.</li>
</ol>
""",
                "atajos": [
                    {"teclas": "Ctrl + C", "accion": "Copiar"},
                    {"teclas": "Ctrl + X", "accion": "Cortar"},
                    {"teclas": "Ctrl + V", "accion": "Pegar"},
                    {"teclas": "Ctrl + Shift + V", "accion": "Pegar solo texto"},
                    {"teclas": "Windows + V", "accion": "Historial del portapapeles"},
                    {"teclas": "Ctrl + F", "accion": "Buscar"},
                    {"teclas": "Ctrl + H", "accion": "Buscar y reemplazar"},
                ],
                "trampas": [
                    "Al pegar desde una web, el formato puede traerte letra de colores y tamaños dispares. Usa Ctrl + Shift + V.",
                ],
                "practica": "",
            },
            {
                "slug": "ayuda-y-f1",
                "titulo": "Ayuda de Windows, el menú mystery y los emerged",
                "objetivo": "Saber encontrar ayuda cuando estás atascada, sin quedarte bloqueada.",
                "duracion": 10,
                "contenido": """
<h2>La ayuda está dentro del programa</h2>
<ul>
<li><strong>F1</strong> abre la ayuda contextual del programa que estés usando (en Word, Excel, Outlook).</li>
<li>En Word y Excel: <strong>Ctrl + F1</strong> abre el panel de <em>Referencias</em>, con enlaces a la ayuda oficial de Microsoft.</li>
<li>En Windows 11: escribe <strong>?</strong> en la búsqueda del menú Inicio y se abrirá la ayuda del sistema.</li>
</ul>
<h2>El «mystery menu»</h2>
<p>Con el botón derecho sobre casi cualquier elemento aparece un menú con verbos: <em>Abrir</em>, <em>Copiar</em>, <em>Renombrar</em>, <em>Eliminar</em>, <em>Propiedades</em>, <em>Enviar a</em>, <em>Imprimir</em>...</p>
<p>Si no sabes cómo hacer algo con un archivo, haz clic derecho sobre él. Es la vía más rápida y siempre está disponible.</p>
<h2>Los mensajes emergentes (emergentes)</h2>
<p>Windows y los programas muestran avisos en pequeño. Los más habituales:</p>
<ul>
<li><em>¿Desea guardar los cambios?</em> → <strong>Sí</strong> / <strong>No</strong>.</li>
<li><em>Este archivo está en uso</em> → el archivo está abierto por otra persona o en otro equipo.</li>
<li><em>El archivo está en solo lectura</em> → no puedes escribir; busca <em>Guardar como</em> y crea una copia.</li>
<li><em>Windows ha protegido tu PC</em> → aviso del antivirus. No lo pulses sin más: anótalo y avisa.</li>
</ul>
<div class="caja aviso"><strong>Regla de oro:</strong> cuando te aparezca un mensaje que no entiendes, <strong>no pulses nada</strong>. Léelo, hazle una foto si hace falta y pregunta en el chat del curso. No hay ninguna prisa.</div>
""",
                "atajos": [
                    {"teclas": "F1", "accion": "Abre la ayuda del programa"},
                    {"teclas": "Shift + F10", "accion": "Abre el menú contextual (equivale al clic derecho)"},
                    {"teclas": "Ctrl + F1", "accion": "Panel de referencias y ayuda en Office"},
                ],
                "trampas": [
                    "Shift + F10 es el clic derecho de teclado: útil si el ratón falla.",
                ],
                "practica": "",
            },
        ],
    },
    # ------------------------------------------------------------------ #
    {
        "slug": "archivos",
        "titulo": "Archivos y carpetas: el Explorador de Windows",
        "nivel": "Básico",
        "icono": "📁",
        "duracion": 75,
        "descripcion": "Dónde están mis cosas, cómo se ordenan, cómo se copian y cómo se recuperan de la papelera.",
        "lecciones": [
            {
                "slug": "explorador-de-archivos",
                "titulo": "El Explorador de archivos y las carpetas",
                "objetivo": "Moverte por las carpetas y entender la barra de direcciones.",
                "duracion": 12,
                "contenido": """
<p>El <strong>Explorador de archivos</strong> es la carpeta grande de Windows. Se abre con <strong>Windows + E</strong> o con el icono de la carpeta amarilla de la barra de tareas.</p>
<h2>Las zonas del Explorador</h2>
<ul>
<li><strong>Barra de direcciones</strong> (arriba): te dice dónde estás. Clic en una parte de la ruta para retroceder.</li>
<li><strong>Barra de búsqueda</strong>: busca dentro de la carpeta actual.</li>
<li><strong>Panel izquierdo</strong>: accesos rápidos, Este equipo, OneDrive, Red.</li>
<li><strong>Área central</strong>: los archivos y carpetas. Iconos grandes o vista de lista (mira arriba a la derecha para cambiar).</li>
<li><strong>Barra de estado</strong> (abajo): indica cuántos elementos hay y cuántos elementos tienes seleccionados.</li>
</ul>
<h2>Las carpetas que vas a usar todos los días</h2>
<ul>
<li><strong>Escritorio</strong>: lo que ves en el escritorio.</li>
<li><strong>Documentos</strong>: tus documentos guardados.</li>
<li><strong>Descargas</strong>: lo que descargas de Internet (¡y lo que casi nadie ordena!).</li>
<li><strong>Imágenes</strong>: fotos y, en Windows 11, las <em>capturas de pantalla</em> en la subcarpeta <em>Screenshots</em>.</li>
<li><strong>Papelera de reciclaje</strong>: lo que has borrado (se vacía sola a los 30 días).</li>
</ul>
<h2>Crear una carpeta</h2>
<ol class="pasos">
<li>Sitúate en la carpeta donde la quieres (por ejemplo, Documentos).</li>
<li>Clic derecho en un espacio vacío → <strong>Nueva</strong> → <strong>Carpeta</strong>.</li>
<li>Escribe el nombre y pulsa <strong>Intro</strong>.</li>
</ol>
<div class="caja aviso"><strong>Nombra bien las carpetas.</strong> Usa nombres claros y con fecha: <em>Informes 2026 - cliente Acero</em>. En seis meses tú (y tus compañeras) agradecerás esta decisión.</div>
""",
                "atajos": [
                    {"teclas": "Windows + E", "accion": "Abre el Explorador de archivos"},
                    {"teclas": "Ctrl + Shift + N", "accion": "Crea una carpeta nueva"},
                    {"teclas": "Ctrl + Shift + E", "accion": "Muestra las carpetas superiores"},
                    {"teclas": "Alt + flecha izquierda", "accion": "Atrás"},
                    {"teclas": "Alt + flecha arriba", "accion": "Carpeta superior"},
                ],
                "trampas": [
                    "Las carpetas de la barra de direcciones (Escritorio, Documentos...) son accesos rápidos; no son el lugar real del archivo.",
                ],
                "practica": "",
            },
            {
                "slug": "copiar-mover-renombrar",
                "titulo": "Copiar, mover, renombrar y eliminar",
                "objetivo": "Gestionar archivos sin miedo a perderlos.",
                "duracion": 14,
                "contenido": """
<h2>Copiar y pegar</h2>
<ol class="pasos">
<li>Selecciona el archivo (un clic).</li>
<li><strong>Ctrl + C</strong> para copiar (deja el original donde está).</li>
<li>Ve a la carpeta de destino y pulsa <strong>Ctrl + V</strong> para pegar.</li>
</ol>
<p>Alternativa con el ratón: clic derecho → <em>Copiar</em>, ve a la carpeta de destino, clic derecho → <em>Pegar</em>.</p>
<h2>Cortar y mover</h2>
<ol class="pasos">
<li>Selecciona el archivo → <strong>Ctrl + X</strong> (cortar: desaparece de ahí, pero aún está en el portapapeles).</li>
<li>Ve a la carpeta de destino → <strong>Ctrl + V</strong>.</li>
</ol>
<p>O más fácil: <strong>arrastra</strong> el archivo con el ratón de una carpeta a otra. Si lo sueltas dentro de la misma carpeta, lo mueves de sitio.</p>
<h2>Renombrar</h2>
<ol class="pasos">
<li>Haz un solo clic en el archivo para seleccionarlo.</li>
<li>Pulsa <strong>F2</strong> (funciona en el Explorador y en el escritorio).</li>
<li>Escribe el nombre nuevo y pulsa <strong>Intro</strong>.</li>
</ol>
<h2>Eliminar y la papelera</h2>
<ol class="pasos">
<li>Selecciona el archivo y pulsa la <strong>tecla Supr</strong> (o clic derecho → Eliminar).</li>
<li>El archivo no se borra: va a la <strong>Papelera de reciclaje</strong>.</li>
<li>Para recuperarlo: doble clic en <em>Papelera de reciclaje</em> en el panel izquierdo, selecciona el archivo y pulsa <em>Restaurar</em>.</li>
</ol>
<div class="caja aviso"><strong>Shift + Supr borra directamente</strong>, sin pasar por la papelera. Úsalo solo cuando estés 100 % segura. En la ofimática, borrar con <strong>Supr</strong> es siempre más seguro.</div>
<h2>Duplicar un archivo</h2>
<p>Ctrl + C y luego Ctrl + V sobre la misma carpeta: crear una copia con el nombre «... - Copia». Sirve para trabajar sobre una versión sin tocar el original.</p>
""",
                "atajos": [
                    {"teclas": "Ctrl + C", "accion": "Copiar"},
                    {"teclas": "Ctrl + X", "accion": "Cortar"},
                    {"teclas": "Ctrl + V", "accion": "Pegar"},
                    {"teclas": "F2", "accion": "Renombrar el archivo seleccionado"},
                    {"teclas": "Supr", "accion": "Enviar a la papelera"},
                ],
                "trampas": [
                    "Si copias un archivo y abres otra aplicación, el portapapeles puede perderse (a veces). Copia justo antes de pegar.",
                ],
                "practica": "ej-archivos",
            },
            {
                "slug": "buscar-archivos",
                "titulo": "Buscar archivos y buscar por contenido",
                "objetivo": "Encontrar en segundos un archivo que sabes que existe.",
                "duracion": 12,
                "contenido": """
<h2>Buscar por nombre (dentro de una carpeta)</h2>
<ol class="pasos">
<li>Sitúate en la carpeta donde debería estar el archivo (por ejemplo, Documentos).</li>
<li>Pulsa <strong>Ctrl + F</strong> (aparece el cuadro de búsqueda arriba a la derecha) o <strong>Ctrl + E</strong> (en el centro de la ventana).</li>
<li>Escribe parte del nombre. Espera un momento: la búsqueda se actualiza sola.</li>
<li>Clic en el resultado para abrirlo. <strong>Ctrl + clic</strong> para seleccionar varios.</li>
</ol>
<h2>Buscar en TODO el ordenador</h2>
<p>Haz clic en <strong>Este equipo</strong> (panel izquierdo) y busca ahí. Es más lento, pero encuentra archivos en todo el disco, incluidas unidades USB.</p>
<div class="caja aviso"><strong>Consejo:</strong> busca por una parte del nombre, no por el nombre entero. Si el archivo se llama <em>Informe Ventas Trimestral Final.docx</em>, busca <em>Ventas</em>.</div>
<h2>Buscar por contenido (en Windows 11)</h2>
<ol class="pasos">
<li>En el Explorador, arriba a la derecha, abre el menú de búsqueda y elige <strong>Buscar en el contenido</strong> (icono del documento con lupa).</li>
<li>Escribe una frase que recuerdes del contenido del documento.</li>
</ol>
<h2>Buscar en Google desde la barra de direcciones</h2>
<p>Escribe directamente en la barra de direcciones del navegador una frase y pulsa Intro: el navegador busca en Internet. Si lo que quieres es buscar en el ordenador, usa el Explorador.</p>
<h2>Wildcards</h2>
<p>En la búsqueda del Explorador puedes usar <code>*</code> (cualquier cosa) y <code>?</code> (un carácter). Por ejemplo <code>informe*.pdf</code> encuentra cualquier informe en PDF.</p>
""",
                "atajos": [
                    {"teclas": "Ctrl + F", "accion": "Buscar en la carpeta actual"},
                    {"teclas": "Ctrl + E", "accion": "Buscar en el Explorador"},
                    {"teclas": "Windows + S", "accion": "Buscar en todo Windows"},
                ],
                "trampas": [
                    "La búsqueda dentro de «Este equipo» puede tardar bastante. Ten paciencia o acota la carpeta.",
                ],
                "practica": "",
            },
            {
                "slug": "guardar-y-nube",
                "titulo": "Guardar, guardar como y la nube (OneDrive)",
                "objetivo": "No perder nunca un documento y saber trabajar desde cualquier equipo.",
                "duracion": 15,
                "contenido": """
<h2>Guardar (Ctrl + S) frente a Guardar como (F12)</h2>
<ul>
<li><strong>Guardar</strong>: actualiza el archivo que ya tenías abierto, en la misma carpeta y con el mismo nombre.</li>
<li><strong>Guardar como</strong>: te deja elegir nombre, carpeta y formato. Úsalo la primera vez que creas un documento.</li>
</ul>
<div class="caja aviso"><strong>El error nº1 en las oficinas:</strong> trabajar 2 horas y que la aplicación se cierre, con todo el trabajo dentro de un archivo que nunca habías guardado. <strong>Pulsa Ctrl + S cada pocos minutos.</strong> Es el hábito que más tiempo te va a ahorrar.</div>
<h2>El cuadro Guardar como</h2>
<ul>
<li><strong>Nombre</strong>: lo primero que debes elegir.</li>
<li><strong>Ubicación</strong>: la carpeta. Si no te aparece, usa <em>Más opciones</em> o la barra de direcciones.</li>
<li><strong>Tipo</strong>: el formato. <em>Documento de Word (*.docx)</em> para editar; <em>PDF (*.pdf)</em> para enviar sin que se pueda modificar.</li>
</ul>
<h2>La nube: OneDrive</h2>
<p>OneDrive es el espacio de almacenamiento de Microsoft en Internet. Ventajas para la oficina:</p>
<ul>
<li>Puedes abrir tus documentos desde cualquier equipo (incluso desde el móvil).</li>
<li>Dos personas pueden editar el mismo documento a la vez.</li>
<li>Si el ordenador se rompe, los archivos siguen intactos.</li>
</ul>
<p>En el Explorador verás <strong>OneDrive</strong> en el panel izquierdo y, junto a cada archivo, un icono de nube (guardado) o de flechas (sincronizando).</p>
<h2>Estados del archivo en la nube</h2>
<ul>
<li><strong>Icono de nube con check verde</strong>: guardado y disponible en cualquier sitio.</li>
<li><strong>Icono de flechas</strong>: se está subiendo; espera antes de apagar el equipo.</li>
<li><strong>Icono de cruz / alerta</strong>: hay un problema (normalmente, has superado el espacio de almacenamiento).</li>
</ul>
<h2>¿Trabajo en local o en la nube?</h2>
<p>Si el equipo es compartido o quieres acceso desde cualquier sitio, trabaja en OneDrive. Si trabajas con datos sensibles de la oficina, consulta la política interna antes de subir nada.</p>
""",
                "atajos": [
                    {"teclas": "Ctrl + S", "accion": "Guardar (hazlo a menudo)"},
                    {"teclas": "F12", "accion": "Guardar como"},
                    {"teclas": "Ctrl + Shift + S", "accion": "Guardar como (alternativa)"},
                ],
                "trampas": [
                    "Word a veces guarda en un archivo oculto «.asd» si se cierra de golpe. No lo borres: son copias de seguridad.",
                ],
                "practica": "",
            },
        ],
    },
    # ------------------------------------------------------------------ #
    {
        "slug": "capturas",
        "titulo": "Capturas de pantalla y vortices de vídeo",
        "nivel": "Básico",
        "icono": "📸",
        "duracion": 45,
        "descripcion": "Los pantallazos: cómo se hacen, dónde se guardan y cómo se comparten.",
        "lecciones": [
            {
                "slug": "pantallazos-rapidos",
                "titulo": "Hacer pantallazos en Windows 11",
                "objetivo": "Capturar la pantalla completa, una ventana o una zona concreta.",
                "duracion": 14,
                "contenido": """
<h2>Las cuatro formas de hacer una captura</h2>
<table class="tabla-atajos">
<tr><th>Atajo</th><th>Qué captura</th><th>Dónde va</th></tr>
<tr><td><strong>Windows + Shift + S</strong></td><td>La zona que elijas (rectángulo, forma libre, ventana o pantalla completa)</td><td>Al portapapeles + aviso para guardar o editar</td></tr>
<tr><td><strong>Impresión de pantalla (PrtSc)</strong></td><td>Toda la pantalla</td><td>Al portapapeles (y puede abrir Recortes)</td></tr>
<tr><td><strong>Windows + Impresión de pantalla</strong></td><td>Toda la pantalla</td><td>Se guarda sola en Imágenes → Capturas de pantalla</td></tr>
<tr><td><strong>Alt + Impresión de pantalla</strong></td><td>Solo la ventana activa</td><td>Al portapapeles</td></tr>
</table>
<h2>La forma más completa: Windows + Shift + S</h2>
<ol class="pasos">
<li>Pulsa <strong>Windows + Shift + S</strong>. La pantalla se atenúa y aparece una barra con 4 iconos.</li>
<li>Elige el modo: <strong>Rectangular</strong> (lo normal), <strong>Forma libre</strong> (dibujar a mano), <strong>Ventana</strong> (toda la ventana de la app) o <strong>Pantalla completa</strong>.</li>
<li>Arrastra el ratón para marcar la zona (o haz clic en la ventana que quieras).</li>
<li>La captura se copia al portapapeles y aparece una notificación abajo a la derecha.</li>
<li>Haz clic en esa notificación para abrir el <strong>editor de Recortes</strong>, donde puedes marcar con un flecha o un recuadro rojo y luego guardar.</li>
</ol>
<h2>Recortes (la aplicación)</h2>
<p>También puedes abrirla escribiendo <em>Recortes</em> en la búsqueda de Windows. Desde ahí puedes hacer capturas y grabarte a ti misma en vídeo.</p>
<h2>Dónde se guardan</h2>
<ul>
<li><strong>Windows + Impresión de pantalla</strong> → archivo automático en <em>Imágenes → Capturas de pantalla (Screenshots)</em>.</li>
<li>Las demás → portapapeles. Para guardarlas: abre Recortes desde la notificación y pulsa <strong>Guardar</strong> (o Ctrl + S).</li>
</ul>
<div class="caja aviso"><strong>Cambio en Windows 11:</strong> desde hace tiempo, la tecla <em>Impresión de pantalla</em> abre directamente la herramienta Recortes en lugar de copiar en silencio. Si prefieres el comportamiento antiguo, ve a <em>Ajustes → Accesibilidad → Teclado</em> y desactiva <em>Usar la tecla de impresión de pantalla para abrir la captura de pantalla</em>.</div>
""",
                "atajos": [
                    {"teclas": "Windows + Shift + S", "accion": "Captura de una zona (Recortes)"},
                    {"teclas": "Windows + Impresión de pantalla", "accion": "Captura completa guardada en Imágenes"},
                    {"teclas": "Alt + Impresión de pantalla", "accion": "Captura de la ventana activa"},
                    {"teclas": "Windows + Shift + R", "accion": "Grabar un vídeo de la pantalla"},
                    {"teclas": "Ctrl + S", "accion": "Guardar la captura en Recortes"},
                ],
                "trampas": [
                    "Si haces la captura y luego abres otra cosa, el portapapeles puede cambiar. Guarda la captura antes de seguir.",
                ],
                "practica": "ej-capturas",
            },
            {
                "slug": "grabar-pantalla-y-editar",
                "titulo": "Grabar la pantalla y editar la captura",
                "objetivo": "Grabar un vídeo corto y anotar las capturas antes de enviarlas.",
                "duracion": 14,
                "contenido": """
<h2>Grabar la pantalla</h2>
<ol class="pasos">
<li>Pulsa <strong>Windows + Shift + R</strong> (o abre <em>Recortes</em> → <em>Grabar vídeo</em>).</li>
<li>Elige la zona (o toda la pantalla) y decide si incluyes el micrófono.</li>
<li>Haz clic en <strong>Iniciar</strong>. Los controles aparecen en la parte superior.</li>
<li>Pulsa <strong>Detener</strong> cuando termines. El vídeo se guarda en <em>Vídeos → Capturas de pantalla</em>.</li>
</ol>
<h2>Anotar la captura (muy útil para explicar un problema)</h2>
<p>En el editor de Recortes, arriba tienes un <em>lapiz</em> (dibujar a mano), un <em>marcador</em> (flechas y formas) y un <em>rectángulo</em>.</p>
<ol class="pasos">
<li>Haz clic en la flecha y arrastra sobre la parte que quieres señalar.</li>
<li>Puedes escribir texto con el icono <em>A</em>.</li>
<li>Pulsa <strong>Guardar</strong> (Ctrl + S) o el icono de compartir para enviarlo por Outlook o Teams.</li>
</ol>
<h2>Copiar solo una parte de la pantalla</h2>
<p>Si solo quieres copiar un texto de una web o de un PDF:</p>
<ol class="pasos">
<li><strong>Windows + Shift + S</strong> y selecciona el rectángulo justo sobre el texto.</li>
<li>La captura va al portapapeles como imagen.</li>
<li>Pega en el destino. Word a veces la pega con el texto reconocido (OCR), pero no siempre. Si necesitas el texto exacto, selecciónalo con el ratón y cópialo.</li>
</ol>
<h2>Cómo compartir una captura por Outlook</h2>
<ol class="pasos">
<li>En Outlook, redacta el mensaje y haz clic en <strong>Adjuntar</strong> (icono del clip).</li>
<li>Elige <strong>Capturas de pantalla</strong> o <strong>Este equipo</strong> y elige la imagen.</li>
<li>Añade un texto breve: «Pantallazo del error que me aparece».</li>
</ol>
""",
                "atajos": [
                    {"teclas": "Windows + Shift + R", "accion": "Grabar un vídeo de la pantalla"},
                    {"teclas": "Ctrl + S", "accion": "Guardar la captura"},
                    {"teclas": "Ctrl + C", "accion": "Copiar la captura"},
                ],
                "trampas": [
                    "Grabar la pantalla graba también las notificaciones y puede contener datos personales. Cierra antes las apps privadas.",
                ],
                "practica": "",
            },
            {
                "slug": "capturas-en-el-trabajo",
                "titulo": "Pantallazos en el trabajo diario: buenas prácticas",
                "objetivo": "Enviar pantallazos útiles que se entiendan a la primera.",
                "duracion": 12,
                "contenido": """
<h2>Un pantallazo útil tiene 4 cosas</h2>
<ol class="pasos">
<li><strong>El contexto</strong>: que se vea la aplicación (no solo el error recortado).</li>
<li><strong>Una marca</strong> (flecha o círculo) señalando dónde está el problema.</li>
<li><strong>Un texto explicativo</strong> en el correo: qué estabas haciendo y qué esperabas.</li>
<li><strong>Nada sensible</strong>: oculta los datos personales o confidenciales de compañeros o clientes.</li>
</ol>
<h2>Plantilla de correo para enviar un pantallazo</h2>
<div class="caja ejemplo">Asunto: Problema al guardar el informe<br><br>Hola [nombre],<br>Cuando intento guardar el informe de ventas en la carpeta compartida me aparece el siguiente error (pantallazo adjunto).<br>Lo he intentado con Ctrl + S y con Guardar como y me sigue pasando.<br>¿Me puedes ayudar?<br>Un saludo,<br>[tu nombre]</div>
<h2>Errores a los que te vas a enfrentar</h2>
<table class="tabla-atajos">
<tr><th>Mensaje</th><th>Qué hacer</th></tr>
<tr><td>«El archivo está en uso»</td><td>Está abierto en otro equipo. Pide que lo cierren o guárdalo con otro nombre.</td></tr>
<tr><td>«Solo lectura»</td><td>Guarda una copia con otro nombre (Guardar como).</td></tr>
<tr><td>«No hay espacio suficiente»</td><td>Avisa al responsable. Nunca borres cosas de la red para hacer sitio.</td></tr>
<tr><td>«La ruta no existe»</td><td>El archivo se movió o está en otra carpeta. Búscalo en el Explorador.</td></tr>
</table>
<div class="caja aviso"><strong>Antes de llamar al servicio técnico</strong>, ten a mano: un pantallazo del error, los pasos que has seguido y el nombre del archivo. Ahorrarás mucho tiempo.</div>
""",
                "atajos": [
                    {"teclas": "Windows + Shift + S", "accion": "Captura con anotaciones"},
                    {"teclas": "Ctrl + V", "accion": "Pegar la captura en el correo"},
                ],
                "trampas": [
                    "No incluyas nunca la contraseña de nadie en un pantallazo ni en un correo.",
                ],
                "practica": "",
            },
        ],
    },
]
