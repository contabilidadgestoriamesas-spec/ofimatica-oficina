"""Lógica compartida del programa de correo (Outlook / Thunderbird / los dos).

Lo usan las vistas del alumno, la API de ejercicios y el panel de administración
para que una alumna de Thunderbird nunca vea atajos de Outlook (ni al revés).
"""

CLIENTES_CORREO = {
    "ambos": "Los dos (Outlook y Thunderbird)",
    "outlook": "Solo Outlook",
    "thunderbird": "Solo Thunderbird",
}

NOMBRES_PROGRAMA = {
    "outlook": "Outlook",
    "thunderbird": "Thunderbird",
}


def cliente_de(usuario):
    """Programa de correo elegido por la persona (outlook/thunderbird/ambos)."""
    if usuario is None:
        return "ambos"
    try:
        valor = usuario["email_client"]
    except (TypeError, KeyError, IndexError):
        valor = ""
    valor = (valor or "ambos").strip().lower()
    return valor if valor in CLIENTES_CORREO else "ambos"


def leccion_visible(leccion, cliente):
    """Las lecciones 'comun' siempre; las de Outlook/Thunderbird según lo elegido."""
    try:
        ruta = leccion["ruta"]
    except (TypeError, KeyError, IndexError):
        ruta = "comun"
    ruta = (ruta or "comun").strip().lower()
    if ruta in ("", "comun"):
        return True
    if ruta == "outlook":
        return cliente in ("outlook", "ambos")
    if ruta == "thunderbird":
        return cliente in ("thunderbird", "ambos")
    return True


def preguntas_ejercicio(cfg, cliente):
    """Elige las preguntas del ejercicio según el programa de la alumna."""
    comunes = list(cfg.get("preguntas") or [])
    if not cfg.get("preguntas_outlook") and not cfg.get("preguntas_thunderbird"):
        return comunes
    salida = list(comunes)
    if cliente in ("outlook", "ambos"):
        salida += list(cfg.get("preguntas_outlook") or [])
    if cliente in ("thunderbird", "ambos"):
        salida += list(cfg.get("preguntas_thunderbird") or [])
    return salida


def preguntas_examen(preguntas, cliente, es_correo=True):
    """Filtra y adapta las preguntas del examen de correo al programa elegido."""
    if not es_correo:
        return list(preguntas)
    salida = []
    for p in preguntas:
        programa = p.get("programa", "ambos")
        texto = p["pregunta"]
        if programa == "ambos":
            salida.append(p)
        elif cliente == "ambos":
            salida.append(dict(p, pregunta="En %s: %s" % (NOMBRES_PROGRAMA[programa], texto)))
        elif programa == cliente:
            salida.append(p)
    return salida
