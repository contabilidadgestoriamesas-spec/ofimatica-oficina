"""Capa de datos (SQLite) de la aplicación de ofimática."""
import os
import sqlite3
import datetime
from contextlib import contextmanager

from .config import DB_PATH


def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    return conn


@contextmanager
def db():
    conn = get_db()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def q(sql, args=(), one=False):
    with db() as conn:
        cur = conn.execute(sql, args)
        rows = cur.fetchall()
        cur.close()
    if one:
        return rows[0] if rows else None
    return rows


def q1(sql, args=()):
    return q(sql, args, one=True)


def execute(sql, args=()):
    with db() as conn:
        cur = conn.execute(sql, args)
        conn.commit()
        last = cur.lastrowid
        cur.close()
    return last


def hoy():
    return datetime.date.today().isoformat()


def ahora():
    return datetime.datetime.now().isoformat(timespec="seconds")


ESQUEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    nombre TEXT NOT NULL DEFAULT '',
    email TEXT DEFAULT '',
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'alumno',
    activo INTEGER NOT NULL DEFAULT 1,
    assistant TEXT DEFAULT 'chispita',
    modulos TEXT DEFAULT 'todos',
    email_client TEXT DEFAULT 'ambos',
    debe_cambiar INTEGER NOT NULL DEFAULT 0,
    intentos_fallidos INTEGER NOT NULL DEFAULT 0,
    bloqueado_hasta TEXT DEFAULT '',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    last_login TEXT
);

CREATE TABLE IF NOT EXISTS modules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    slug TEXT UNIQUE NOT NULL,
    titulo TEXT NOT NULL,
    nivel TEXT NOT NULL DEFAULT 'basico',
    orden INTEGER NOT NULL DEFAULT 0,
    descripcion TEXT DEFAULT '',
    icono TEXT DEFAULT '📘',
    duracion INTEGER DEFAULT 20,
    publicado INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS lessons (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    slug TEXT UNIQUE NOT NULL,
    module_id INTEGER NOT NULL REFERENCES modules(id) ON DELETE CASCADE,
    titulo TEXT NOT NULL,
    objetivo TEXT DEFAULT '',
    duracion INTEGER DEFAULT 10,
    contenido TEXT DEFAULT '',
    atajos TEXT DEFAULT '[]',
    trampas TEXT DEFAULT '[]',
    practica TEXT DEFAULT '',
    ruta TEXT DEFAULT 'comun',
    orden INTEGER NOT NULL DEFAULT 0,
    publicado INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS progress (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    lesson_id INTEGER NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
    completado INTEGER NOT NULL DEFAULT 0,
    en_curso INTEGER NOT NULL DEFAULT 0,
    score INTEGER NOT NULL DEFAULT 0,
    tiempo_seg INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, lesson_id)
);

CREATE TABLE IF NOT EXISTS exercises (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    slug TEXT UNIQUE NOT NULL,
    module_id INTEGER REFERENCES modules(id) ON DELETE SET NULL,
    titulo TEXT NOT NULL,
    tipo TEXT NOT NULL DEFAULT 'opcion',
    descripcion TEXT DEFAULT '',
    nivel INTEGER NOT NULL DEFAULT 1,
    config TEXT DEFAULT '{}',
    publicado INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS exercise_progress (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    exercise_id INTEGER NOT NULL REFERENCES exercises(id) ON DELETE CASCADE,
    intentos INTEGER NOT NULL DEFAULT 0,
    superado INTEGER NOT NULL DEFAULT 0,
    mejor_pct INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, exercise_id)
);

CREATE TABLE IF NOT EXISTS exams (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    module_id INTEGER NOT NULL REFERENCES modules(id) ON DELETE CASCADE,
    titulo TEXT NOT NULL,
    preguntas TEXT DEFAULT '[]',
    aprobado INTEGER NOT NULL DEFAULT 70,
    intentos_max INTEGER NOT NULL DEFAULT 5
);

CREATE TABLE IF NOT EXISTS exam_attempts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    exam_id INTEGER NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
    score INTEGER NOT NULL DEFAULT 0,
    aprobado INTEGER NOT NULL DEFAULT 0,
    respuestas TEXT DEFAULT '[]',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS user_stats (
    user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    puntos INTEGER NOT NULL DEFAULT 0,
    racha INTEGER NOT NULL DEFAULT 0,
    ultimo_dia TEXT DEFAULT '',
    insignias TEXT DEFAULT '[]'
);

CREATE TABLE IF NOT EXISTS articles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    slug TEXT UNIQUE NOT NULL,
    titulo TEXT NOT NULL,
    categoria TEXT NOT NULL DEFAULT 'General',
    tags TEXT DEFAULT '',
    cuerpo TEXT DEFAULT '',
    excelente INTEGER NOT NULL DEFAULT 0,
    fuente TEXT DEFAULT '',
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS activity (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    usuario TEXT DEFAULT '',
    accion TEXT NOT NULL,
    detalle TEXT DEFAULT '',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS drafts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    clave TEXT NOT NULL,
    datos TEXT DEFAULT '',
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, clave)
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
);
"""


def init_db():
    with db() as conn:
        conn.executescript(ESQUEMA)
    _migrar()


def _migrar():
    """Añade las columnas nuevas a bases de datos ya existentes (sin perder datos)."""
    cambios = [
        ("users", "email_client", "TEXT DEFAULT 'ambos'"),
        ("progress", "en_curso", "INTEGER NOT NULL DEFAULT 0"),
        ("lessons", "ruta", "TEXT DEFAULT 'comun'"),
    ]
    for tabla, columna, definicion in cambios:
        try:
            columnas = {c["name"] for c in q("PRAGMA table_info(%s)" % tabla)}
        except Exception:
            continue
        if columna not in columnas:
            try:
                execute("ALTER TABLE %s ADD COLUMN %s %s" % (tabla, columna, definicion))
            except Exception:
                pass
    # La tabla de borradores puede no existir en instalaciones antiguas
    try:
        execute(
            """CREATE TABLE IF NOT EXISTS drafts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                clave TEXT NOT NULL,
                datos TEXT DEFAULT '',
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(user_id, clave))"""
        )
    except Exception:
        pass


def get_setting(key, default=""):
    row = q1("SELECT value FROM settings WHERE key = ?", (key,))
    return row["value"] if row else default


def set_setting(key, value):
    execute(
        "INSERT INTO settings(key, value) VALUES(?,?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (key, str(value)),
    )


def log(user_id, usuario, accion, detalle=""):
    execute(
        "INSERT INTO activity(user_id, usuario, accion, detalle, created_at) "
        "VALUES(?,?,?,?,?)",
        (user_id, usuario, accion, detalle, ahora()),
    )
