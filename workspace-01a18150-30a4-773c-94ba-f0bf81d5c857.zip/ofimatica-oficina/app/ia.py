"""Puente con la IA generativa.

Compatible con cualquier servidor que hable la API de OpenAI:
  · Ollama        -> http://localhost:11434/v1   (modelo: llama3.1:8b, qwen2.5, etc.)
  · LM Studio    -> http://localhost:1234/v1
  · llama.cpp     -> http://localhost:8080/v1
  · vLLM / Groq / OpenAI / etc.

Si no hay IA configurada o no responde, la ayudante sigue funcionando con el
motor de reglas y el manual (respuestas deterministas, siempre disponibles).
"""
import json
import urllib.error
import urllib.request

from . import db
from .config import IA_POR_DEFECTO

CLAVE_IA = "config_ia"


def configuracion_ia():
    raw = db.get_setting(CLAVE_IA, "")
    conf = dict(IA_POR_DEFECTO)
    if raw:
        try:
            conf.update(json.loads(raw))
        except Exception:
            pass
    return conf


def guardar_configuracion_ia(datos):
    actual = configuracion_ia()
    for clave in ("activada", "base_url", "modelo", "api_key", "temperatura", "max_tokens", "prompt_sistema"):
        if clave in datos:
            actual[clave] = str(datos[clave]).strip()
    db.set_setting(CLAVE_IA, json.dumps(actual, ensure_ascii=False))
    return actual


def _post_json(url, payload, api_key="", timeout=45):
    datos = json.dumps(payload).encode("utf-8")
    peticion = urllib.request.Request(url, data=datos, method="POST")
    peticion.add_header("Content-Type", "application/json")
    if api_key:
        peticion.add_header("Authorization", "Bearer %s" % api_key)
    with urllib.request.urlopen(peticion, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def probar_conexion():
    """Comprueba si el servidor de IA responde. Devuelve (ok, mensaje)."""
    conf = configuracion_ia()
    if conf.get("activada") != "1":
        return False, "La IA está desactivada. Actívala para poder probarla."
    base = (conf.get("base_url") or "").rstrip("/")
    if not base:
        return False, "Falta la dirección del servidor de IA."
    url = base + "/chat/completions"
    payload = {
        "model": conf.get("modelo") or "llama3.1:8b",
        "messages": [{"role": "user", "content": "Responde solo con la palabra: OK"}],
        "max_tokens": 10,
        "temperature": 0,
    }
    try:
        res = _post_json(url, payload, conf.get("api_key", ""), timeout=25)
        texto = ""
        try:
            texto = res["choices"][0]["message"]["content"]
        except Exception:
            texto = str(res)[:120]
        return True, "Conexión correcta. El modelo responde: %s" % texto.strip()[:60]
    except urllib.error.HTTPError as exc:
        return False, "El servidor respondió con un error %s: %s" % (exc.code, exc.reason)
    except urllib.error.URLError as exc:
        return False, "No se pudo conectar con %s (%s). ¿Está el servicio de IA encendido?" % (base, exc.reason)
    except Exception as exc:  # pragma: no cover
        return False, "Error inesperado: %s" % exc


def llamar_ia(mensaje, personaje="chispita", contexto_manual="", contexto_extra=""):
    """Llama al modelo y devuelve el texto (o None si no hay respuesta)."""
    conf = configuracion_ia()
    if conf.get("activada") != "1":
        return None
    base = (conf.get("base_url") or "").rstrip("/")
    if not base:
        return None

    from .assistant import PERSONAJES

    per = PERSONAJES.get(personaje, PERSONAJES["chispita"])
    sistema = conf.get("prompt_sistema") or IA_POR_DEFECTO["prompt_sistema"]
    sistema += "\n\nTu nombre es %s y tu estilo es: %s." % (per["nombre"], per["tono"])
    if contexto_manual:
        sistema += (
            "\n\nConsulta estos extractos del MANUAL DE LA OFICINA antes de responder. "
            "Da prioridad a esta información y cita los pasos exactos. "
            "Si la consulta no aparece en los extractos, responde con tus conocimientos generales "
            "de Windows 11 y Microsoft Office, sin inventar atajos que no existan:\n\n" + contexto_manual
        )
    if contexto_extra:
        sistema += "\n\n" + contexto_extra

    payload = {
        "model": conf.get("modelo") or "llama3.1:8b",
        "messages": [
            {"role": "system", "content": sistema},
            {"role": "user", "content": mensaje},
        ],
        "temperature": float(conf.get("temperatura") or 0.4),
        "max_tokens": int(conf.get("max_tokens") or 700),
        "stream": False,
    }
    try:
        res = _post_json(base + "/chat/completions", payload, conf.get("api_key", ""), timeout=60)
        contenido = res["choices"][0]["message"]["content"]
        if isinstance(contenido, list):  # algunos modelos devuelven listas de bloques
            contenido = "".join(
                b.get("text", "") for b in contenido if isinstance(b, dict)
            )
        return (contenido or "").strip() or None
    except Exception:
        return None
