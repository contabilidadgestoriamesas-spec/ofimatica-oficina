#!/usr/bin/env python3
"""Prueba de todas las rutas de la aplicación (como alumna y como administradora)."""
import json
import sys
import urllib.parse

import requests

BASE = "http://127.0.0.1:8080"

fallos = []
probadas = 0


def req(ses, ruta, metodo="GET", j=None, datos=None, permitir=(200, 302)):
    global probadas
    probadas += 1
    try:
        if j is not None:
            r = ses.request(metodo, BASE + ruta, json=j, timeout=20, allow_redirects=True)
        elif datos is not None:
            r = ses.request(metodo, BASE + ruta, data=datos, timeout=20, allow_redirects=True)
        else:
            r = ses.request(metodo, BASE + ruta, timeout=20, allow_redirects=True)
    except Exception as e:
        fallos.append((ruta, metodo, "EXCEPCIÓN %s" % e))
        return None
    if r.status_code not in permitir:
        fallos.append((ruta, metodo, "HTTP %s" % r.status_code))
    return r


def main():
    # ---------------- alumna ----------------
    s = requests.Session()
    r = req(s, "/login")
    r = req(s, "/login", "POST", datos={"username": "mgarcia", "password": "Ofi2026"})
    if r is not None and "Mi curso" not in r.text and r.status_code != 200:
        fallos.append(("login mgarcia", "POST", "no entró"))

    modulos = ["fundamentos", "teclado", "archivos", "capturas", "word", "excel",
               "correo", "reuniones", "imprimir", "seguridad"]
    req(s, "/")
    for m in modulos:
        req(s, "/modulo/%s" % m)
    req(s, "/manual")
    req(s, "/manual?q=thunderbird")
    req(s, "/manual?q=outlook")
    req(s, "/manual?q=adjuntar")
    req(s, "/manual?categoria=Correo%20electr%C3%B3nico")
    req(s, "/chuleta")
    req(s, "/ejercicios")
    req(s, "/mi-progreso")
    req(s, "/configuracion")
    req(s, "/pista")
    req(s, "/pista/0")
    req(s, "/sw.js", permitir=(200,))
    req(s, "/static/js/autoguardado.js", permitir=(200,))
    req(s, "/static/manifest.webmanifest", permitir=(200,))

    # lecciones: todas las del curso
    import sqlite3
    con = sqlite3.connect("data/ofimatica.db")
    con.row_factory = sqlite3.Row
    lecciones = [r["slug"] for r in con.execute("SELECT slug FROM lessons ORDER BY id")]
    articulos = [r["slug"] for r in con.execute("SELECT slug FROM articles ORDER BY id")]
    ejercicios = [r["slug"] for r in con.execute("SELECT slug FROM exercises ORDER BY id")]
    con.close()
    for slug in lecciones:
        req(s, "/leccion/%s" % slug)
    for slug in articulos:
        req(s, "/manual/%s" % slug)
    for slug in ejercicios:
        req(s, "/ejercicio/%s" % slug)
    for m in modulos:
        req(s, "/examen/%s" % m)

    # entrega del examen (debe devolver la corrección, no un error 500)
    for m in modulos:
        req(s, "/examen/%s/corregir" % m, "POST",
            datos={"p0": "0", "p1": "1", "p2": "2", "p3": "3", "p4": "0", "p5": "1"})

    # corrección de un ejercicio
    con = sqlite3.connect("data/ofimatica.db")
    con.row_factory = sqlite3.Row
    ej_id = con.execute("SELECT id FROM exercises WHERE tipo='opcion' LIMIT 1").fetchone()["id"]
    con.close()
    req(s, "/api/ejercicio/%d/resultado" % ej_id, "POST", j={"respuestas": {"0": "0"}})

    # API
    req(s, "/api/chat", "POST", j={"mensaje": "como reenvio un correo", "personaje": "chispita"})
    req(s, "/api/chat", "POST", j={"mensaje": "como configuro thunderbird", "personaje": "donatajo"})
    req(s, "/api/chat", "POST", j={"mensaje": "como adjunto un archivo", "personaje": "nubia"})
    req(s, "/api/consejo")
    req(s, "/api/progreso")

    # autoguardado
    req(s, "/api/autoguardado", "POST", j={"clave": "leccion:prueba", "datos": {"posicion": 120}})
    req(s, "/api/autoguardado/leccion:prueba")
    req(s, "/api/leccion/que-es-el-correo/autoguardado", "POST",
        j={"porcentaje": 50, "segundos": 10, "completada": False})
    req(s, "/api/autoguardado/leccion:prueba", "DELETE")

    # elegir programa de correo
    req(s, "/mi-programa-correo", "POST", datos={"email_client": "thunderbird",
                                                 "volver": "/modulo/correo"})
    req(s, "/modulo/correo")
    req(s, "/mi-programa-correo", "POST", datos={"email_client": "outlook",
                                                 "volver": "/modulo/correo"})
    req(s, "/modulo/correo")
    req(s, "/mi-programa-correo", "POST", datos={"email_client": "ambos",
                                                 "volver": "/modulo/correo"})
    req(s, "/configuracion", "POST", datos={"accion": "email_cliente", "email_client": "ambos"})

    # ---------------- administradora ----------------
    a = requests.Session()
    req(a, "/login")
    req(a, "/login", "POST", datos={"username": "admin", "password": "admin"})
    req(a, "/admin")
    req(a, "/admin/usuarios")
    req(a, "/admin/usuarios/nuevo")
    req(a, "/admin/progreso")
    req(a, "/admin/ia")
    req(a, "/admin/contenido")
    req(a, "/admin/actividad")

    # alta con SOLO el nombre
    datos_alta = {
        "nombre": "Josefa Molina Pruebas",
        "email": "",
        "password": "Prueba2026",
        "repetir": "Prueba2026",
        "role": "alumno",
        "assistant": "chispita",
        "email_client": "thunderbird",
        "modulos": ["fundamentos", "correo"],
    }
    r = req(a, "/admin/usuarios/nuevo", "POST", datos=datos_alta)
    ok_alta = r is not None and r.status_code == 200 and "Cuenta creada" in r.text
    if not ok_alta:
        fallos.append(("alta solo con nombre", "POST", "no se creó la cuenta"))

    # la cuenta debe existir con usuario autogenerado
    con = sqlite3.connect("data/ofimatica.db")
    con.row_factory = sqlite3.Row
    fila = con.execute("SELECT * FROM users WHERE nombre = ?", ("Josefa Molina Pruebas",)).fetchone()
    con.close()
    if fila is None:
        fallos.append(("alta solo con nombre", "BD", "no hay fila con ese nombre"))
    else:
        print("  ✓ alta con solo el nombre → usuario '%s', correo '%s', cliente '%s'"
              % (fila["username"], fila["email"] or "(vacío)", fila["email_client"]))
        if fila["email_client"] != "thunderbird":
            fallos.append(("alta", "BD", "no guardó el programa de correo"))
        # la alumna debe poder entrar y ver solo sus lecciones de Thunderbird
        s2 = requests.Session()
        req(s2, "/login")
        req(s2, "/login", "POST", datos={"username": fila["username"], "password": "Prueba2026"})
        r = req(s2, "/modulo/correo")
        if r is not None:
            n_th = r.text.count('pill-thunderbird')
            n_out = r.text.count('pill-outlook')
            print("  ✓ módulo correo de la alumna: %d etiquetas Thunderbird, %d Outlook" % (n_th, n_out))
            if n_out != 0:
                fallos.append(("filtro por ruta", "GET", "vio lecciones de Outlook"))
            if n_th == 0:
                fallos.append(("filtro por ruta", "GET", "no vio lecciones de Thunderbird"))
        # borrar la cuenta de prueba
        req(a, "/admin/usuarios/%d" % fila["id"], "POST", datos={"accion": "eliminar"})

    # edición de usuario
    con = sqlite3.connect("data/ofimatica.db")
    con.row_factory = sqlite3.Row
    mg = con.execute("SELECT * FROM users WHERE username = 'mgarcia'").fetchone()
    con.close()
    if mg:
        req(a, "/admin/usuarios/%d" % mg["id"], "POST",
            datos={"accion": "perfil", "nombre": mg["nombre"], "email": mg["email"],
                   "role": "alumno", "activo": "1", "assistant": mg["assistant"],
                   "email_client": mg["email_client"], "username": "mgarcia"})

    # ---------------- resultado ----------------
    print()
    print("Rutas probadas: %d" % probadas)
    if fallos:
        print("FALLOS: %d" % len(fallos))
        for f in fallos:
            print("   ✗ %-55s %-6s %s" % f)
        return 1
    print("✅ Todas las rutas responden correctamente (0 fallos)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
