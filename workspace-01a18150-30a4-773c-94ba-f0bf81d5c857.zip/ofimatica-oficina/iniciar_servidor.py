#!/usr/bin/env python3
"""Arranque del servidor de la Oficina de Ofimática.

Uso:
    python iniciar_servidor.py                # servidor en 0.0.0.0:8080
    python iniciar_servidor.py --puerto 9000  # otro puerto
    python iniciar_servidor.py --local        # solo accesible desde este equipo
"""
import argparse
import os
import socket
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app                      # noqa: E402
from app import db                             # noqa: E402
from app.auth import crear_admin_inicial        # noqa: E402
from app.seed import seed_todo                  # noqa: E402


def ip_local():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def main():
    parser = argparse.ArgumentParser(description="Servidor del curso de ofimática")
    parser.add_argument("--host", default=os.environ.get("OFIMATICA_HOST", "0.0.0.0"))
    parser.add_argument("--puerto", type=int, default=int(os.environ.get("OFIMATICA_PORT", "8080")))
    parser.add_argument("--local", action="store_true", help="escuchar solo en este equipo")
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()
    host = "127.0.0.1" if args.local else args.host

    app = create_app()
    with app.app_context():
        seed_todo()
        crear_admin_inicial()

    print("=" * 68)
    print("  OFICINA DE OFIMÁTICA · servidor listo")
    print("=" * 68)
    print("  En este equipo :  http://localhost:%d" % args.puerto)
    if host != "127.0.0.1":
        print("  Desde la red    :  http://%s:%d" % (ip_local(), args.puerto))
    print("  Administrador  :  usuario «admin» · contraseña «admin»")
    print("  (cámbiala desde el panel de administración)")
    print("=" * 68)
    print("  Ctrl + C para detener el servidor.")
    print()

    app.run(host=host, port=args.puerto, debug=args.debug, threaded=True, use_reloader=args.debug)


if __name__ == "__main__":
    main()
